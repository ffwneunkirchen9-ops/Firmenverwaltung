# FA Fertigung FIX40

Wear-OS-Kachel mit minimaler Entgraten-Ansicht.

## Entgraten
Nur FA-Nummer, FA-Wechsel ⇄, Tagesmenge und −/+ sind sichtbar.
Die Minus-/Plus-Tasten buchen jeweils −10 bzw. +10 Stück.

## Schneiden
Bleibt gegenüber FIX39 unverändert.

Für FIX40 die WATCH-App neu bauen/installieren. Das FIX39-Script mit `quantity_minus_10` bleibt erforderlich.
