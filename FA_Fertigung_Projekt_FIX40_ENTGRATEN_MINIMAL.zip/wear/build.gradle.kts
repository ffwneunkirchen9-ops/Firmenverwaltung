import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "de.fa.fertigung.wear"
    compileSdk = 36

    defaultConfig {
        /*
         * Muss für die Wearable Data Layer API mit der Handy-App
         * übereinstimmen.
         */
        applicationId = "de.fa.fertigung"
        minSdk = 30
        targetSdk = 35

        val githubRunNumber =
            System.getenv("GITHUB_RUN_NUMBER")
                ?.toIntOrNull()
                ?: 0

        versionCode =
            40000 + githubRunNumber

        versionName =
            "1.40." + githubRunNumber
    }

    signingConfigs {
        create("release") {
            val keystorePath =
                System.getenv("FA_KEYSTORE_PATH")
                    ?: error("FA_KEYSTORE_PATH fehlt")

            val storePasswordValue =
                System.getenv("FA_KEYSTORE_PASSWORD")
                    ?: error("FA_KEYSTORE_PASSWORD fehlt")

            val keyAliasValue =
                System.getenv("FA_KEY_ALIAS")
                    ?: error("FA_KEY_ALIAS fehlt")

            val keyPasswordValue =
                System.getenv("FA_KEY_PASSWORD")
                    ?: error("FA_KEY_PASSWORD fehlt")

            storeFile =
                file(keystorePath)

            storePassword =
                storePasswordValue

            keyAlias =
                keyAliasValue

            keyPassword =
                keyPasswordValue
        }
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            signingConfig =
                signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility =
            JavaVersion.VERSION_17

        targetCompatibility =
            JavaVersion.VERSION_17
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(
            JvmTarget.JVM_17
        )
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")

    implementation(
        "androidx.wear.tiles:tiles:1.6.2"
    )

    implementation(
        "androidx.wear.protolayout:protolayout:1.4.2"
    )

    implementation(
        "androidx.wear.protolayout:protolayout-material:1.4.2"
    )

    implementation(
        "androidx.wear.protolayout:protolayout-material3:1.4.2"
    )

    implementation(
        "com.google.android.gms:play-services-wearable:20.0.1"
    )

    implementation(
        "com.google.guava:guava:33.7.2-android"
    )
}
