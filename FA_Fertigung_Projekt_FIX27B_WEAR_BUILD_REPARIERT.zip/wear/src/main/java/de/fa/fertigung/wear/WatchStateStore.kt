package de.fa.fertigung.wear

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object WatchStateStore {

    private const val PREFS =
        "fa_watch_state"

    private const val KEY_CONTEXT =
        "context_json"

    private const val KEY_POSITION =
        "selected_position"

    private const val KEY_PENDING =
        "pending_events"


    fun contextJson(
        context: Context
    ): String {

        return context
            .getSharedPreferences(
                PREFS,
                Context.MODE_PRIVATE
            )
            .getString(
                KEY_CONTEXT,
                "{}"
            )
            .orEmpty()
    }


    fun saveContext(
        context: Context,
        json: String
    ) {

        context
            .getSharedPreferences(
                PREFS,
                Context.MODE_PRIVATE
            )
            .edit()
            .putString(
                KEY_CONTEXT,
                json
            )
            .apply()

        clampSelectedPosition(
            context
        )
    }


    fun selectedPosition(
        context: Context,
        positionCount: Int
    ): Int {

        if (
            positionCount <=
            0
        ) {
            return 0
        }

        val raw =
            context
                .getSharedPreferences(
                    PREFS,
                    Context.MODE_PRIVATE
                )
                .getInt(
                    KEY_POSITION,
                    0
                )

        return raw
            .coerceIn(
                0,
                positionCount - 1
            )
    }


    fun nextPosition(
        context: Context,
        positionCount: Int
    ) {

        if (
            positionCount <=
            1
        ) {
            return
        }

        val next =
            (
                selectedPosition(
                    context,
                    positionCount
                ) +
                1
            ) %
            positionCount

        context
            .getSharedPreferences(
                PREFS,
                Context.MODE_PRIVATE
            )
            .edit()
            .putInt(
                KEY_POSITION,
                next
            )
            .apply()
    }


    fun addPending(
        context: Context,
        eventId: String,
        type: String
    ) {

        val pending =
            pendingArray(
                context
            )

        pending.put(
            JSONObject()
                .put(
                    "eventId",
                    eventId
                )
                .put(
                    "type",
                    type
                )
        )

        savePending(
            context,
            pending
        )
    }


    fun acknowledge(
        context: Context,
        ids: Set<String>
    ) {

        if (
            ids.isEmpty()
        ) {
            return
        }

        val old =
            pendingArray(
                context
            )

        val fresh =
            JSONArray()

        for (
            index in
            0 until old.length()
        ) {
            val item =
                old.optJSONObject(
                    index
                )
                    ?: continue

            if (
                !ids.contains(
                    item.optString(
                        "eventId"
                    )
                )
            ) {
                fresh.put(
                    item
                )
            }
        }

        savePending(
            context,
            fresh
        )
    }


    fun pendingCount(
        context: Context
    ): Int {

        return pendingArray(
            context
        ).length()
    }


    private fun clampSelectedPosition(
        context: Context
    ) {

        val json =
            runCatching {
                JSONObject(
                    contextJson(
                        context
                    )
                )
            }.getOrNull()
                ?: return

        val count =
            json
                .optJSONArray(
                    "positions"
                )
                ?.length()
                ?: 0

        if (
            count <=
            0
        ) {
            return
        }

        val current =
            selectedPosition(
                context,
                count
            )

        context
            .getSharedPreferences(
                PREFS,
                Context.MODE_PRIVATE
            )
            .edit()
            .putInt(
                KEY_POSITION,
                current
            )
            .apply()
    }


    private fun pendingArray(
        context: Context
    ): JSONArray {

        val raw =
            context
                .getSharedPreferences(
                    PREFS,
                    Context.MODE_PRIVATE
                )
                .getString(
                    KEY_PENDING,
                    "[]"
                )
                .orEmpty()

        return runCatching {
            JSONArray(
                raw
            )
        }.getOrElse {
            JSONArray()
        }
    }


    private fun savePending(
        context: Context,
        array: JSONArray
    ) {

        context
            .getSharedPreferences(
                PREFS,
                Context.MODE_PRIVATE
            )
            .edit()
            .putString(
                KEY_PENDING,
                array.toString()
            )
            .apply()
    }
}
