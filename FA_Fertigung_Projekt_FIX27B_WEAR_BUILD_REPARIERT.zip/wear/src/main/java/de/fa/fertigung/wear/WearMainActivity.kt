package de.fa.fertigung.wear

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

class WearMainActivity :
    Activity() {

    override fun onCreate(
        savedInstanceState: Bundle?
    ) {
        super.onCreate(
            savedInstanceState
        )

        val root =
            LinearLayout(
                this
            )
                .apply {
                    orientation =
                        LinearLayout.VERTICAL

                    gravity =
                        Gravity.CENTER

                    setPadding(
                        28,
                        28,
                        28,
                        28
                    )

                    setBackgroundColor(
                        Color.BLACK
                    )
                }

        val title =
            TextView(
                this
            )
                .apply {
                    text =
                        "FA Fertigung"

                    textSize =
                        22f

                    setTextColor(
                        Color.WHITE
                    )

                    gravity =
                        Gravity.CENTER
                }

        val info =
            TextView(
                this
            )
                .apply {
                    text =
                        "Kachel in der Kachelverwaltung der Uhr hinzufügen.\n\n" +
                        "Platten +1\nAusschuss +1\nRückgängig"

                    textSize =
                        15f

                    setTextColor(
                        Color.LTGRAY
                    )

                    gravity =
                        Gravity.CENTER

                    setPadding(
                        0,
                        20,
                        0,
                        0
                    )
                }

        root.addView(
            title
        )

        root.addView(
            info
        )

        setContentView(
            root
        )
    }
}
