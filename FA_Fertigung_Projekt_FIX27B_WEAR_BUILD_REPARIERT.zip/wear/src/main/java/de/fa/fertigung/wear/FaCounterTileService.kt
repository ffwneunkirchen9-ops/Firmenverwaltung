package de.fa.fertigung.wear

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.wear.protolayout.DimensionBuilders.expand
import androidx.wear.protolayout.DimensionBuilders.weight
import androidx.wear.protolayout.ProtoLayoutScope
import androidx.wear.protolayout.TimelineBuilders.Timeline
import androidx.wear.protolayout.layout.column
import androidx.wear.protolayout.material3.ButtonDefaults.filledButtonColors
import androidx.wear.protolayout.material3.ButtonDefaults.filledTonalButtonColors
import androidx.wear.protolayout.material3.CardDefaults.filledVariantCardColors
import androidx.wear.protolayout.material3.ButtonGroupDefaults.DEFAULT_SPACER_BETWEEN_BUTTON_GROUPS
import androidx.wear.protolayout.material3.MaterialScope
import androidx.wear.protolayout.material3.Typography.BODY_SMALL
import androidx.wear.protolayout.material3.Typography.NUMERAL_SMALL
import androidx.wear.protolayout.material3.buttonGroup
import androidx.wear.protolayout.material3.materialScopeWithResources
import androidx.wear.protolayout.material3.primaryLayout
import androidx.wear.protolayout.material3.text
import androidx.wear.protolayout.material3.textButton
import androidx.wear.protolayout.material3.textDataCard
import androidx.wear.protolayout.modifiers.clickable
import androidx.wear.protolayout.types.layoutString
import androidx.wear.tiles.RequestBuilders
import androidx.wear.tiles.TileService
import androidx.wear.tiles.tile
import com.google.common.util.concurrent.Futures
import org.json.JSONObject

class FaCounterTileService :
    TileService() {

    override fun onTileRequest(
        requestParams:
            RequestBuilders.TileRequest
    ) =
        Futures.immediateFuture(
            tile(
                Timeline.fromLayoutElement(
                    buildTileLayout(
                        this,
                        requestParams.scope,
                        requestParams.deviceConfiguration
                    )
                )
            )
        )


    private fun buildTileLayout(
        context: Context,
        scope: ProtoLayoutScope,
        deviceParameters:
            androidx.wear.protolayout.DeviceParametersBuilders.DeviceParameters
    ) =
        materialScopeWithResources(
            context,
            scope,
            deviceParameters
        ) {

            val raw =
                WatchStateStore
                    .contextJson(
                        context
                    )

            val json =
                runCatching {
                    JSONObject(
                        raw
                    )
                }.getOrElse {
                    JSONObject()
                }

            val active =
                json.optBoolean(
                    "active",
                    false
                )

            val pending =
                WatchStateStore
                    .pendingCount(
                        context
                    )

            if (!active) {

                return@materialScopeWithResources primaryLayout(
                    titleSlot = {
                        text(
                            "FA Fertigung".layoutString
                        )
                    },
                    mainSlot = {
                        text(
                            "Am Handy einen FA öffnen.".layoutString,
                            typography =
                                BODY_SMALL
                        )
                    }
                )
            }


            val positions =
                json.optJSONArray(
                    "positions"
                )

            val positionCount =
                positions?.length()
                    ?: 0

            val selected =
                WatchStateStore
                    .selectedPosition(
                        context,
                        positionCount
                    )

            val selectedPosition =
                positions
                    ?.optJSONObject(
                        selected
                    )
                    ?: JSONObject()

            val plates =
                json.optInt(
                    "plates",
                    0
                )

            val scrap =
                selectedPosition
                    .optInt(
                        "scrap",
                        0
                    )

            val faNo =
                json.optString(
                    "faNo",
                    "?"
                )

            val op =
                json.optString(
                    "op",
                    ""
                )

            val article =
                selectedPosition
                    .optString(
                        "article",
                        ""
                    )

            val title =
                buildString {
                    append(
                        "FA "
                    )

                    append(
                        faNo
                    )

                    if (
                        op.isNotBlank()
                    ) {
                        append(
                            " · "
                        )

                        append(
                            op
                        )
                    }

                    if (
                        pending >
                        0
                    ) {
                        append(
                            " · ⏳"
                        )

                        append(
                            pending
                        )
                    }
                }


            val plateClick =
                actionClickable(
                    context,
                    scope,
                    TileActionReceiver
                        .ACTION_PLATE_PLUS,
                    "plate_plus",
                    10
                )

            val scrapClick =
                actionClickable(
                    context,
                    scope,
                    TileActionReceiver
                        .ACTION_SCRAP_PLUS,
                    "scrap_plus",
                    20
                )

            val nextPositionClick =
                actionClickable(
                    context,
                    scope,
                    TileActionReceiver
                        .ACTION_NEXT_POSITION,
                    "next_position",
                    30
                )

            val undoClick =
                actionClickable(
                    context,
                    scope,
                    TileActionReceiver
                        .ACTION_UNDO,
                    "undo",
                    40
                )


            primaryLayout(
                titleSlot = {
                    text(
                        title.layoutString
                    )
                },

                mainSlot = {

                    column(
                        buttonGroup {

                            buttonGroupItem {

                                textDataCard(
                                    onClick =
                                        plateClick,
                                    width =
                                        weight(
                                            2f
                                        ),
                                    height =
                                        expand(),
                                    colors =
                                        filledVariantCardColors(),
                                    title = {
                                        text(
                                            plates
                                                .toString()
                                                .layoutString,
                                            typography =
                                                NUMERAL_SMALL
                                        )
                                    },
                                    content = {
                                        text(
                                            "Platten".layoutString,
                                            typography =
                                                BODY_SMALL
                                        )
                                    }
                                )
                            }

                            buttonGroupItem {

                                textButton(
                                    width =
                                        weight(
                                            1f
                                        ),
                                    height =
                                        expand(),
                                    onClick =
                                        plateClick,
                                    colors =
                                        filledButtonColors(),
                                    labelContent = {
                                        text(
                                            "+".layoutString,
                                            typography =
                                                NUMERAL_SMALL
                                        )
                                    }
                                )
                            }
                        },

                        DEFAULT_SPACER_BETWEEN_BUTTON_GROUPS,

                        buttonGroup {

                            buttonGroupItem {

                                textDataCard(
                                    onClick =
                                        scrapClick,
                                    width =
                                        weight(
                                            2f
                                        ),
                                    height =
                                        expand(),
                                    colors =
                                        filledVariantCardColors(),
                                    title = {
                                        text(
                                            scrap
                                                .toString()
                                                .layoutString,
                                            typography =
                                                NUMERAL_SMALL
                                        )
                                    },
                                    content = {
                                        text(
                                            "Ausschuss".layoutString,
                                            typography =
                                                BODY_SMALL
                                        )
                                    }
                                )
                            }

                            buttonGroupItem {

                                textButton(
                                    width =
                                        weight(
                                            1f
                                        ),
                                    height =
                                        expand(),
                                    onClick =
                                        scrapClick,
                                    colors =
                                        filledButtonColors(),
                                    labelContent = {
                                        text(
                                            "+".layoutString,
                                            typography =
                                                NUMERAL_SMALL
                                        )
                                    }
                                )
                            }
                        },

                        width =
                            expand(),

                        height =
                            expand()
                    )
                },

                bottomSlot = {

                    buttonGroup {

                        if (
                            positionCount >
                            1
                        ) {

                            buttonGroupItem {

                                textButton(
                                    width =
                                        weight(
                                            2f
                                        ),
                                    height =
                                        expand(),
                                    onClick =
                                        nextPositionClick,
                                    colors =
                                        filledTonalButtonColors(),
                                    labelContent = {
                                        text(
                                            (
                                                "Pos " +
                                                (
                                                    selected +
                                                    1
                                                ) +
                                                "/" +
                                                positionCount +
                                                (
                                                    if (
                                                        article.isNotBlank()
                                                    ) {
                                                        " · " +
                                                        article.take(
                                                            10
                                                        )
                                                    }
                                                    else {
                                                        ""
                                                    }
                                                )
                                            )
                                                .layoutString,
                                            typography =
                                                BODY_SMALL
                                        )
                                    }
                                )
                            }
                        }

                        buttonGroupItem {

                            textButton(
                                width =
                                    weight(
                                        if (
                                            positionCount >
                                            1
                                        ) {
                                            1f
                                        }
                                        else {
                                            3f
                                        }
                                    ),
                                height =
                                    expand(),
                                onClick =
                                    undoClick,
                                colors =
                                    filledTonalButtonColors(),
                                labelContent = {
                                    text(
                                        "↶".layoutString,
                                        typography =
                                            NUMERAL_SMALL
                                    )
                                }
                            )
                        }
                    }
                }
            )
        }


    private fun actionClickable(
        context: Context,
        scope: ProtoLayoutScope,
        action: String,
        id: String,
        requestCode: Int
    ) =
        scope.clickable(
            pendingIntent =
                PendingIntent.getBroadcast(
                    context,
                    requestCode,
                    Intent(
                        context,
                        TileActionReceiver::class.java
                    )
                        .setAction(
                            action
                        ),
                    PendingIntent.FLAG_UPDATE_CURRENT or
                        PendingIntent.FLAG_IMMUTABLE
                ),
            id =
                id
        )
}
