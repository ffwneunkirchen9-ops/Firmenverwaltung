package de.fa.fertigung.watch

import android.content.Context
import android.net.Uri
import com.google.android.gms.wearable.PutDataMapRequest
import com.google.android.gms.wearable.Wearable
import org.json.JSONObject

object WatchSync {

    const val CONTEXT_PATH =
        "/fa/watch/context"

    const val EVENT_PREFIX =
        "/fa/watch/event/"

    const val ACK_PATH =
        "/fa/watch/ack"


    fun publishContext(
        context: Context,
        json: String
    ) {

        val request =
            PutDataMapRequest
                .create(
                    CONTEXT_PATH
                )
                .apply {
                    dataMap.putString(
                        "json",
                        json
                    )

                    dataMap.putLong(
                        "updatedAt",
                        System.currentTimeMillis()
                    )
                }
                .asPutDataRequest()
                .setUrgent()

        Wearable
            .getDataClient(
                context
            )
            .putDataItem(
                request
            )
    }


    fun acknowledgeEvents(
        context: Context,
        eventIds: List<String>,
        eventUris: List<String>
    ) {

        if (
            eventIds.isNotEmpty()
        ) {

            val request =
                PutDataMapRequest
                    .create(
                        ACK_PATH
                    )
                    .apply {
                        dataMap.putStringArrayList(
                            "eventIds",
                            ArrayList(
                                eventIds
                            )
                        )

                        dataMap.putLong(
                            "updatedAt",
                            System.currentTimeMillis()
                        )
                    }
                    .asPutDataRequest()
                    .setUrgent()

            Wearable
                .getDataClient(
                    context
                )
                .putDataItem(
                    request
                )
        }


        /*
         * Bereits sicher in der Web-App bestätigte Event-DataItems
         * können danach entfernt werden.
         */
        eventUris.forEach {
            uriString ->

            runCatching {
                Wearable
                    .getDataClient(
                        context
                    )
                    .deleteDataItems(
                        Uri.parse(
                            uriString
                        )
                    )
            }
        }
    }


    fun statusJson(): String {

        return JSONObject()
            .put(
                "ok",
                true
            )
            .put(
                "wearable",
                true
            )
            .toString()
    }
}
