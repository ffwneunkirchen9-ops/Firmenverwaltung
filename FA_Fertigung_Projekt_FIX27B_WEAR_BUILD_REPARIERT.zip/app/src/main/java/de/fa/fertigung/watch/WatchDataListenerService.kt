package de.fa.fertigung.watch

import com.google.android.gms.wearable.DataEvent
import com.google.android.gms.wearable.DataEventBuffer
import com.google.android.gms.wearable.DataMapItem
import com.google.android.gms.wearable.WearableListenerService
import org.json.JSONObject

class WatchDataListenerService :
    WearableListenerService() {

    override fun onDataChanged(
        dataEvents: DataEventBuffer
    ) {
        var queuedSomething =
            false

        dataEvents.forEach {
            event ->

            if (
                event.type !=
                DataEvent.TYPE_CHANGED
            ) {
                return@forEach
            }

            val item =
                event.dataItem

            val path =
                item.uri.path
                    .orEmpty()

            if (
                !path.startsWith(
                    WatchSync.EVENT_PREFIX
                )
            ) {
                return@forEach
            }

            val map =
                runCatching {
                    DataMapItem
                        .fromDataItem(
                            item
                        )
                        .dataMap
                }.getOrNull()
                    ?: return@forEach

            val eventId =
                map.getString(
                    "eventId"
                )
                    .orEmpty()

            if (
                eventId.isBlank()
            ) {
                return@forEach
            }

            val json =
                JSONObject()
                    .put(
                        "eventId",
                        eventId
                    )
                    .put(
                        "type",
                        map.getString(
                            "type"
                        ).orEmpty()
                    )
                    .put(
                        "faId",
                        map.getString(
                            "faId"
                        ).orEmpty()
                    )
                    .put(
                        "faNo",
                        map.getString(
                            "faNo"
                        ).orEmpty()
                    )
                    .put(
                        "date",
                        map.getString(
                            "date"
                        ).orEmpty()
                    )
                    .put(
                        "positionIndex",
                        map.getInt(
                            "positionIndex",
                            0
                        )
                    )
                    .put(
                        "timestamp",
                        map.getLong(
                            "timestamp",
                            System.currentTimeMillis()
                        )
                    )
                    .put(
                        "dataUri",
                        item.uri.toString()
                    )

            if (
                WatchEventStore.enqueue(
                    this,
                    json
                )
            ) {
                queuedSomething =
                    true
            }
        }

        if (
            queuedSomething
        ) {
            WatchWebBridgeRegistry
                .notifyWatchEvents()
        }
    }
}
