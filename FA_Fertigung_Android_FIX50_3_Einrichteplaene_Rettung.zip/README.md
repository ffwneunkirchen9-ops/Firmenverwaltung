# FA Fertigung FIX49

Gezielter Fix für die Tagesauswahl auf der Watch.

Wenn nach einem Kalendertagwechsel „Heute“ gewählt wird und der zuletzt vom Handy gelieferte Watch-Kontext den neuen Tag noch nicht enthält, legt die Uhr nun sofort einen lokalen Tagesdatensatz für heute an. Dadurch fällt sie nicht mehr auf einen alten Tag zurück.

Unverändert bleiben:
- Layout der Watch-App
- FA-Auswahl
- Auswahl und Korrektur alter Arbeitstage
- Timer nur für Heute
- Tageswert-Synchronisation aus FIX47/FIX48
- Überproduktion und Überschusslogik

Für FIX49 ist keine Änderung an script.html erforderlich. Die FIX48-Webversion kann unverändert bleiben.
