package de.fa.fertigung.ai

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Base64
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.math.min

object SetupPlanArchive {

    fun saveDataUrlAsPdf(
        context: Context,
        customer: String,
        setupNumber: String,
        dataUrl: String
    ): JSONObject {

        val base64 =
            if (
                dataUrl.contains(
                    "base64,"
                )
            ) {
                dataUrl.substringAfter(
                    "base64,"
                )
            } else {
                dataUrl
            }

        val bytes =
            Base64.decode(
                base64,
                Base64.DEFAULT
            )

        val bitmap =
            BitmapFactory
                .decodeByteArray(
                    bytes,
                    0,
                    bytes.size
                )
                ?: throw IllegalArgumentException(
                    "Einrichteplan-Bild konnte nicht gelesen werden."
                )

        return try {
            saveBitmapAsPdf(
                context,
                customer,
                setupNumber,
                bitmap
            )
        } finally {
            runCatching {
                if (
                    !bitmap.isRecycled
                ) {
                    bitmap.recycle()
                }
            }
        }
    }

    fun saveDataUrlsAsPdf(
        context: Context,
        customer: String,
        setupNumber: String,
        dataUrls: List<String>
    ): JSONObject {

        if (
            dataUrls.size <
            2
        ) {
            throw IllegalArgumentException(
                "Für den Einrichteplan werden 2 Seiten benötigt."
            )
        }


        val bitmaps =
            mutableListOf<Bitmap>()


        try {

            dataUrls
                .take(
                    2
                )
                .forEach {
                    dataUrl ->

                    val base64 =
                        if (
                            dataUrl.contains(
                                "base64,"
                            )
                        ) {
                            dataUrl.substringAfter(
                                "base64,"
                            )
                        } else {
                            dataUrl
                        }


                    val bytes =
                        Base64.decode(
                            base64,
                            Base64.DEFAULT
                        )


                    val bitmap =
                        BitmapFactory
                            .decodeByteArray(
                                bytes,
                                0,
                                bytes.size
                            )
                            ?: throw IllegalArgumentException(
                                "Eine Einrichteplan-Seite konnte nicht gelesen werden."
                            )


                    bitmaps.add(
                        bitmap
                    )
                }


            return saveBitmapsAsPdf(
                context,
                customer,
                setupNumber,
                bitmaps
            )

        } finally {

            bitmaps.forEach {
                bitmap ->

                runCatching {
                    if (
                        !bitmap.isRecycled
                    ) {
                        bitmap.recycle()
                    }
                }
            }
        }
    }


    fun saveBitmapsAsPdf(
        context: Context,
        customer: String,
        setupNumber: String,
        bitmaps: List<Bitmap>
    ): JSONObject {

        if (
            bitmaps.size <
            2
        ) {
            throw IllegalArgumentException(
                "Einrichteplan wird erst mit 2 Seiten gespeichert."
            )
        }


        val cleanCustomer =
            safePathPart(
                customer
            )
                .ifBlank {
                    "Unbekannter Kunde"
                }

        val cleanNumber =
            safePathPart(
                setupNumber
            )
                .ifBlank {
                    "Ohne Nummer"
                }

        val pdfBytes =
            bitmapsToPdf(
                bitmaps.take(
                    2
                )
            )

        return savePdfBytes(
            context,
            customer,
            setupNumber,
            cleanCustomer,
            cleanNumber,
            pdfBytes,
            2
        )
    }


    fun saveBitmapAsPdf(
        context: Context,
        customer: String,
        setupNumber: String,
        bitmap: Bitmap
    ): JSONObject {

        val cleanCustomer =
            safePathPart(
                customer
            )
                .ifBlank {
                    "Unbekannter Kunde"
                }

        val cleanNumber =
            safePathPart(
                setupNumber
            )
                .ifBlank {
                    "Ohne Nummer"
                }

        val pdfBytes =
            bitmapsToPdf(
                listOf(
                    bitmap
                )
            )

        return savePdfBytes(
            context,
            customer,
            setupNumber,
            cleanCustomer,
            cleanNumber,
            pdfBytes,
            1
        )
    }


    private fun savePdfBytes(
        context: Context,
        customer: String,
        setupNumber: String,
        cleanCustomer: String,
        cleanNumber: String,
        pdfBytes: ByteArray,
        pageCount: Int
    ): JSONObject {

        /*
         Es wird IMMER eine echte app-interne PDF gespeichert.
         Zusätzlich wird eine öffentliche Kopie unter Dokumente
         angelegt.
        */

        val archiveFolder =
            File(
                context.filesDir,
                "Einrichteplaene/" +
                    "$cleanCustomer/$cleanNumber"
            )
                .apply {
                    mkdirs()
                }

        val privatePdf =
            File(
                archiveFolder,
                "Einrichteplan.pdf"
            )

        privatePdf.writeBytes(
            pdfBytes
        )

        val publicPath =
            "Documents/FA Fertigung/Einrichteplaene/" +
                "$cleanCustomer/$cleanNumber/"

        var publicUri =
            ""

        if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.Q
        ) {

            runCatching {
                val resolver =
                    context.contentResolver

                val collection =
                    MediaStore.Files
                        .getContentUri(
                            MediaStore
                                .VOLUME_EXTERNAL_PRIMARY
                        )

                resolver.delete(
                    collection,
                    "${MediaStore.MediaColumns.RELATIVE_PATH}=? AND " +
                        "${MediaStore.MediaColumns.DISPLAY_NAME}=?",
                    arrayOf(
                        publicPath,
                        "Einrichteplan.pdf"
                    )
                )

                val values =
                    ContentValues()
                        .apply {
                            put(
                                MediaStore.MediaColumns.DISPLAY_NAME,
                                "Einrichteplan.pdf"
                            )

                            put(
                                MediaStore.MediaColumns.MIME_TYPE,
                                "application/pdf"
                            )

                            put(
                                MediaStore.MediaColumns.RELATIVE_PATH,
                                publicPath
                            )

                            put(
                                MediaStore.MediaColumns.IS_PENDING,
                                1
                            )
                        }

                val uri =
                    resolver.insert(
                        collection,
                        values
                    )
                        ?: throw IllegalStateException(
                            "Öffentliche PDF konnte nicht angelegt werden."
                        )

                resolver
                    .openOutputStream(
                        uri,
                        "w"
                    )
                    ?.use {
                        stream ->

                        stream.write(
                            pdfBytes
                        )

                        stream.flush()
                    }
                    ?: throw IllegalStateException(
                        "Öffentliche PDF konnte nicht geschrieben werden."
                    )

                resolver.update(
                    uri,
                    ContentValues()
                        .apply {
                            put(
                                MediaStore.MediaColumns.IS_PENDING,
                                0
                            )
                        },
                    null,
                    null
                )

                publicUri =
                    uri.toString()
            }
        }

        val displayPath =
            publicPath +
                "Einrichteplan.pdf"

        val metadata =
            JSONObject()
                .put(
                    "customer",
                    customer.trim()
                )
                .put(
                    "setupNumber",
                    setupNumber.trim()
                )
                .put(
                    "path",
                    displayPath
                )
                .put(
                    "privatePath",
                    privatePdf.absolutePath
                )
                .put(
                    "publicUri",
                    publicUri
                )
                .put(
                    "pageCount",
                    pageCount
                )
                .put(
                    "savedAt",
                    System.currentTimeMillis()
                )

        File(
            archiveFolder,
            "archive.json"
        )
            .writeText(
                metadata.toString(
                    2
                ),
                Charsets.UTF_8
            )

        return JSONObject()
            .put(
                "ok",
                true
            )
            .put(
                "customer",
                customer.trim()
            )
            .put(
                "setupNumber",
                setupNumber.trim()
            )
            .put(
                "pageCount",
                pageCount
            )
            .put(
                "path",
                displayPath
            )
    }



    /**
     * FIX50.3: Wiederherstellung der bereits vorhandenen öffentlichen PDFs.
     * Das Dokumentenverzeichnis wird ausschließlich mit Leserechten geöffnet.
     * Die Originaldateien werden niemals geändert, verschoben oder gelöscht.
     * App-interne gültige PDFs werden niemals überschrieben.
     */
    fun importPublicPlansFromTree(
        context: Context,
        treeUri: Uri
    ): JSONObject {
        val selected = DocumentFile.fromTreeUri(context, treeUri)
            ?: throw IllegalArgumentException("Der ausgewählte Ordner konnte nicht gelesen werden.")

        val archiveRoot = when (selected.name?.lowercase()) {
            "einrichteplaene" -> selected
            "fa fertigung" -> selected.findFile("Einrichteplaene")
            "documents", "dokumente" -> selected.findFile("FA Fertigung")?.findFile("Einrichteplaene")
            else -> selected.findFile("Einrichteplaene")
        }

        if (archiveRoot == null || !archiveRoot.isDirectory) {
            return JSONObject()
                .put("ok", false)
                .put("error", "Bitte den Ordner Documents/FA Fertigung/Einrichteplaene auswählen.")
        }

        var imported = 0
        var alreadyPresent = 0
        var errors = 0
        var found = 0

        archiveRoot.listFiles()
            .filter { it.isDirectory }
            .forEach customerLoop@{ customerDir ->
                val customer = customerDir.name.orEmpty()
                customerDir.listFiles()
                    .filter { it.isDirectory }
                    .forEach setupLoop@{ setupDir ->
                        val setupNumber = setupDir.name.orEmpty()
                        val pdf = setupDir.listFiles().firstOrNull {
                            it.isFile && it.name.equals("Einrichteplan.pdf", ignoreCase = true)
                        } ?: return@setupLoop

                        found++
                        val cleanCustomer = safePathPart(customer).ifBlank { "Unbekannter Kunde" }
                        val cleanNumber = safePathPart(setupNumber).ifBlank { "Ohne Nummer" }
                        val folder = File(context.filesDir,
                            "Einrichteplaene/$cleanCustomer/$cleanNumber")
                        val destination = File(folder, "Einrichteplan.pdf")

                        if (destination.isFile && destination.length() > 0) {
                            alreadyPresent++
                            return@setupLoop
                        }

                        try {
                            if (!folder.exists() && !folder.mkdirs()) {
                                throw IllegalStateException("Privater Archivordner nicht verfügbar")
                            }
                            val temporary = File.createTempFile("fa_recovery_", ".tmp", folder)
                            try {
                                context.contentResolver.openInputStream(pdf.uri)?.use { input ->
                                    temporary.outputStream().use { output -> input.copyTo(output) }
                                } ?: throw IllegalStateException("PDF kann nicht gelesen werden")

                                val header = ByteArray(5)
                                val count = temporary.inputStream().use { it.read(header) }
                                if (count != 5 || String(header, Charsets.US_ASCII) != "%PDF-") {
                                    throw IllegalStateException("Datei ist keine gültige PDF")
                                }

                                // Niemals eine bestehende intakte PDF ersetzen.
                                if (destination.isFile && destination.length() > 0) {
                                    alreadyPresent++
                                } else if (!temporary.renameTo(destination)) {
                                    temporary.copyTo(destination, overwrite = false)
                                    imported++
                                } else {
                                    imported++
                                }
                            } finally {
                                temporary.delete()
                            }

                            val metadataFile = File(folder, "archive.json")
                            val metadata = readMetadata(folder)
                            if (metadata.optString("customer").isBlank()) {
                                metadata.put("customer", customer)
                            }
                            if (metadata.optString("setupNumber").isBlank()) {
                                metadata.put("setupNumber", setupNumber)
                            }
                            if (metadata.optString("path").isBlank()) {
                                metadata.put("path", "Documents/FA Fertigung/Einrichteplaene/" +
                                    "$customer/$setupNumber/Einrichteplan.pdf")
                            }
                            if (metadata.optString("publicUri").isBlank()) {
                                metadata.put("publicUri", pdf.uri.toString())
                            }
                            metadata.put("recoveredAt", System.currentTimeMillis())
                            metadataFile.writeText(metadata.toString(2), Charsets.UTF_8)
                        } catch (_: Exception) {
                            errors++
                        }
                    }
            }

        return JSONObject()
            .put("ok", true)
            .put("found", found)
            .put("imported", imported)
            .put("alreadyPresent", alreadyPresent)
            .put("errors", errors)
    }


    fun listPlans(
        context: Context
    ): JSONObject {

        val items =
            JSONArray()

        val root =
            File(
                context.filesDir,
                "Einrichteplaene"
            )

        if (
            root.exists()
        ) {

            root
                .listFiles()
                ?.filter {
                    it.isDirectory
                }
                ?.sortedBy {
                    it.name.lowercase()
                }
                ?.forEach {
                    customerFolder ->

                    customerFolder
                        .listFiles()
                        ?.filter {
                            it.isDirectory
                        }
                        ?.sortedBy {
                            it.name.lowercase()
                        }
                        ?.forEach {
                            setupFolder ->

                            val metadataFile =
                                File(
                                    setupFolder,
                                    "archive.json"
                                )

                            val data =
                                runCatching {
                                    JSONObject(
                                        metadataFile.readText(
                                            Charsets.UTF_8
                                        )
                                    )
                                }
                                    .getOrDefault(
                                        JSONObject()
                                    )

                            val customer =
                                data
                                    .optString(
                                        "customer"
                                    )
                                    .ifBlank {
                                        customerFolder.name
                                    }

                            val setupNumber =
                                data
                                    .optString(
                                        "setupNumber"
                                    )
                                    .ifBlank {
                                        setupFolder.name
                                    }

                            /*
                             Alte FIX12/FIX15-Einträge hatten teils nur Metadaten.
                             Wir versuchen die öffentliche PDF einmalig in das
                             robuste interne Archiv zu übernehmen.
                            */

                            val privatePdf =
                                ensurePrivateCopy(
                                    context,
                                    customer,
                                    setupNumber,
                                    setupFolder,
                                    data
                                )

                            val path =
                                data
                                    .optString(
                                        "path"
                                    )
                                    .ifBlank {
                                        "Documents/FA Fertigung/Einrichteplaene/" +
                                            "${safePathPart(customer)}/" +
                                            "${safePathPart(setupNumber)}/" +
                                            "Einrichteplan.pdf"
                                    }

                            items.put(
                                JSONObject()
                                    .put(
                                        "customer",
                                        customer
                                    )
                                    .put(
                                        "setupNumber",
                                        setupNumber
                                    )
                                    .put(
                                        "path",
                                        path
                                    )
                                    .put(
                                        "savedAt",
                                        data.optLong(
                                            "savedAt",
                                            metadataFile
                                                .takeIf {
                                                    it.exists()
                                                }
                                                ?.lastModified()
                                                ?: 0L
                                        )
                                    )
                                    .put(
                                        "exists",
                                        privatePdf.exists()
                                    )
                                    .put(
                                        "recovered",
                                        data.optLong("recoveredAt", 0L) > 0L
                                    )
                            )
                        }
                }
        }

        return JSONObject()
            .put(
                "ok",
                true
            )
            .put(
                "items",
                items
            )
    }

    fun openPlan(
        context: Context,
        customer: String,
        setupNumber: String
    ): JSONObject {

        val cleanCustomer =
            safePathPart(
                customer
            )
                .ifBlank {
                    "Unbekannter Kunde"
                }

        val cleanNumber =
            safePathPart(
                setupNumber
            )
                .ifBlank {
                    "Ohne Nummer"
                }

        val folder =
            File(
                context.filesDir,
                "Einrichteplaene/" +
                    "$cleanCustomer/$cleanNumber"
            )

        val metadata =
            readMetadata(
                folder
            )

        val privatePdf =
            ensurePrivateCopy(
                context,
                customer,
                setupNumber,
                folder,
                metadata
            )

        if (
            !privatePdf.exists()
        ) {

            throw IllegalStateException(
                "Die gespeicherte PDF-Datei wurde nicht gefunden."
            )
        }

        val uri =
            FileProvider
                .getUriForFile(
                    context,
                    context.packageName +
                        ".fileprovider",
                    privatePdf
                )

        val intent =
            Intent(
                Intent.ACTION_VIEW
            )
                .setDataAndType(
                    uri,
                    "application/pdf"
                )
                .addFlags(
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )

        context.startActivity(
            Intent.createChooser(
                intent,
                "Einrichteplan öffnen"
            )
                .addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK
                )
        )

        return JSONObject()
            .put(
                "ok",
                true
            )
    }

    fun renamePlan(
        context: Context,
        customer: String,
        oldSetupNumber: String,
        newSetupNumber: String
    ): JSONObject {

        val cleanCustomer =
            safePathPart(
                customer
            )
                .ifBlank {
                    "Unbekannter Kunde"
                }


        val cleanOld =
            safePathPart(
                oldSetupNumber
            )
                .ifBlank {
                    "Ohne Nummer"
                }


        val cleanNew =
            safePathPart(
                newSetupNumber
            )
                .ifBlank {
                    "Ohne Nummer"
                }


        if (
            cleanOld ==
            cleanNew
        ) {

            return JSONObject()
                .put(
                    "ok",
                    true
                )
                .put(
                    "path",
                    "Documents/FA Fertigung/Einrichteplaene/" +
                        "$cleanCustomer/$cleanNew/Einrichteplan.pdf"
                )
        }


        val oldFolder =
            File(
                context.filesDir,
                "Einrichteplaene/" +
                    "$cleanCustomer/$cleanOld"
            )


        val oldMetadata =
            readMetadata(
                oldFolder
            )


        val oldPdf =
            ensurePrivateCopy(
                context,
                customer,
                oldSetupNumber,
                oldFolder,
                oldMetadata
            )


        if (
            !oldPdf.exists() ||
            oldPdf.length() <= 0
        ) {

            throw IllegalStateException(
                "Der Einrichteplan unter '$oldSetupNumber' wurde nicht gefunden."
            )
        }


        val pdfBytes =
            oldPdf.readBytes()


        val newFolder =
            File(
                context.filesDir,
                "Einrichteplaene/" +
                    "$cleanCustomer/$cleanNew"
            )
                .apply {
                    mkdirs()
                }


        val newPdf =
            File(
                newFolder,
                "Einrichteplan.pdf"
            )


        newPdf.writeBytes(
            pdfBytes
        )


        var publicUri =
            ""


        val newRelativePath =
            "Documents/FA Fertigung/Einrichteplaene/" +
                "$cleanCustomer/$cleanNew/"


        if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.Q
        ) {

            runCatching {

                val resolver =
                    context.contentResolver


                val collection =
                    MediaStore.Files
                        .getContentUri(
                            MediaStore
                                .VOLUME_EXTERNAL_PRIMARY
                        )


                /*
                 Ziel ggf. ersetzen.
                */

                resolver.delete(
                    collection,
                    "${MediaStore.MediaColumns.RELATIVE_PATH}=? AND " +
                        "${MediaStore.MediaColumns.DISPLAY_NAME}=?",
                    arrayOf(
                        newRelativePath,
                        "Einrichteplan.pdf"
                    )
                )


                val values =
                    ContentValues()
                        .apply {
                            put(
                                MediaStore.MediaColumns.DISPLAY_NAME,
                                "Einrichteplan.pdf"
                            )

                            put(
                                MediaStore.MediaColumns.MIME_TYPE,
                                "application/pdf"
                            )

                            put(
                                MediaStore.MediaColumns.RELATIVE_PATH,
                                newRelativePath
                            )

                            put(
                                MediaStore.MediaColumns.IS_PENDING,
                                1
                            )
                        }


                val uri =
                    resolver.insert(
                        collection,
                        values
                    )
                        ?: throw IllegalStateException(
                            "Neue PDF konnte nicht angelegt werden."
                        )


                resolver
                    .openOutputStream(
                        uri,
                        "w"
                    )
                    ?.use {
                        stream ->

                        stream.write(
                            pdfBytes
                        )

                        stream.flush()
                    }
                    ?: throw IllegalStateException(
                        "Neue PDF konnte nicht geschrieben werden."
                    )


                resolver.update(
                    uri,
                    ContentValues()
                        .apply {
                            put(
                                MediaStore.MediaColumns.IS_PENDING,
                                0
                            )
                        },
                    null,
                    null
                )


                publicUri =
                    uri.toString()


                /*
                 Alte öffentliche PDF löschen.
                */

                val oldUri =
                    oldMetadata
                        .optString(
                            "publicUri"
                        )
                        .takeIf {
                            it.isNotBlank()
                        }
                        ?.let {
                            Uri.parse(
                                it
                            )
                        }
                    ?: findPublicPdfUri(
                        context,
                        cleanCustomer,
                        cleanOld
                    )
                    ?: findPublicPdfUriLoose(
                        context,
                        cleanCustomer,
                        cleanOld
                    )


                if (
                    oldUri != null
                ) {

                    resolver.delete(
                        oldUri,
                        null,
                        null
                    )
                }
            }
        }


        val displayPath =
            newRelativePath +
                "Einrichteplan.pdf"


        File(
            newFolder,
            "archive.json"
        )
            .writeText(
                JSONObject()
                    .put(
                        "customer",
                        customer.trim()
                    )
                    .put(
                        "setupNumber",
                        newSetupNumber.trim()
                    )
                    .put(
                        "path",
                        displayPath
                    )
                    .put(
                        "privatePath",
                        newPdf.absolutePath
                    )
                    .put(
                        "publicUri",
                        publicUri
                    )
                    .put(
                        "savedAt",
                        System.currentTimeMillis()
                    )
                    .toString(
                        2
                    ),
                Charsets.UTF_8
            )


        if (
            oldFolder.exists()
        ) {

            oldFolder
                .deleteRecursively()
        }


        return JSONObject()
            .put(
                "ok",
                true
            )
            .put(
                "path",
                displayPath
            )
    }


    fun deletePlan(
        context: Context,
        customer: String,
        setupNumber: String
    ): JSONObject {

        val cleanCustomer =
            safePathPart(
                customer
            )
                .ifBlank {
                    "Unbekannter Kunde"
                }

        val cleanNumber =
            safePathPart(
                setupNumber
            )
                .ifBlank {
                    "Ohne Nummer"
                }

        val folder =
            File(
                context.filesDir,
                "Einrichteplaene/" +
                    "$cleanCustomer/$cleanNumber"
            )

        val metadata =
            readMetadata(
                folder
            )

        /*
         Öffentliche Kopie bestmöglich löschen.
        */

        if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.Q
        ) {

            runCatching {
                val resolver =
                    context.contentResolver

                val directUri =
                    metadata
                        .optString(
                            "publicUri"
                        )
                        .takeIf {
                            it.isNotBlank()
                        }
                        ?.let {
                            Uri.parse(
                                it
                            )
                        }

                if (
                    directUri != null
                ) {

                    resolver.delete(
                        directUri,
                        null,
                        null
                    )

                } else {

                    val uri =
                        findPublicPdfUri(
                            context,
                            cleanCustomer,
                            cleanNumber
                        )
                            ?: findPublicPdfUriLoose(
                                context,
                                cleanCustomer,
                                cleanNumber
                            )

                    if (
                        uri != null
                    ) {

                        resolver.delete(
                            uri,
                            null,
                            null
                        )
                    }
                }
            }
        }

        if (
            folder.exists()
        ) {

            folder.deleteRecursively()
        }

        val customerFolder =
            File(
                context.filesDir,
                "Einrichteplaene/$cleanCustomer"
            )

        if (
            customerFolder.exists() &&
            customerFolder
                .listFiles()
                .isNullOrEmpty()
        ) {

            customerFolder.delete()
        }

        return JSONObject()
            .put(
                "ok",
                true
            )
    }

    private fun ensurePrivateCopy(
        context: Context,
        customer: String,
        setupNumber: String,
        folder: File,
        metadata: JSONObject
    ): File {

        folder.mkdirs()

        val privatePdf =
            File(
                folder,
                "Einrichteplan.pdf"
            )

        if (
            privatePdf.exists() &&
            privatePdf.length() > 0
        ) {

            return privatePdf
        }

        if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.Q
        ) {

            val cleanCustomer =
                safePathPart(
                    customer
                )
                    .ifBlank {
                        "Unbekannter Kunde"
                    }

            val cleanNumber =
                safePathPart(
                    setupNumber
                )
                    .ifBlank {
                        "Ohne Nummer"
                    }

            val directUri =
                metadata
                    .optString(
                        "publicUri"
                    )
                    .takeIf {
                        it.isNotBlank()
                    }
                    ?.let {
                        runCatching {
                            Uri.parse(
                                it
                            )
                        }
                            .getOrNull()
                    }

            val uri =
                directUri
                    ?: findPublicPdfUri(
                        context,
                        cleanCustomer,
                        cleanNumber
                    )
                    ?: findPublicPdfUriLoose(
                        context,
                        cleanCustomer,
                        cleanNumber
                    )

            if (
                uri != null
            ) {

                runCatching {
                    context
                        .contentResolver
                        .openInputStream(
                            uri
                        )
                        ?.use {
                            input ->

                            privatePdf
                                .outputStream()
                                .use {
                                    output ->

                                    input.copyTo(
                                        output
                                    )
                                }
                        }
                }
            }
        }

        return privatePdf
    }

    private fun findPublicPdfUri(
        context: Context,
        cleanCustomer: String,
        cleanNumber: String
    ): Uri? {

        if (
            Build.VERSION.SDK_INT <
            Build.VERSION_CODES.Q
        ) {
            return null
        }

        val relativePath =
            "Documents/FA Fertigung/Einrichteplaene/" +
                "$cleanCustomer/$cleanNumber/"

        val collection =
            MediaStore.Files
                .getContentUri(
                    MediaStore
                        .VOLUME_EXTERNAL_PRIMARY
                )

        context
            .contentResolver
            .query(
                collection,
                arrayOf(
                    MediaStore.MediaColumns._ID
                ),
                "${MediaStore.MediaColumns.RELATIVE_PATH}=? AND " +
                    "${MediaStore.MediaColumns.DISPLAY_NAME}=?",
                arrayOf(
                    relativePath,
                    "Einrichteplan.pdf"
                ),
                null
            )
            ?.use {
                cursor ->

                if (
                    cursor.moveToFirst()
                ) {

                    val id =
                        cursor.getLong(
                            cursor.getColumnIndexOrThrow(
                                MediaStore.MediaColumns._ID
                            )
                        )

                    return ContentUris
                        .withAppendedId(
                            collection,
                            id
                        )
                }
            }

        return null
    }

    private fun findPublicPdfUriLoose(
        context: Context,
        cleanCustomer: String,
        cleanNumber: String
    ): Uri? {

        if (
            Build.VERSION.SDK_INT <
            Build.VERSION_CODES.Q
        ) {
            return null
        }

        val collection =
            MediaStore.Files
                .getContentUri(
                    MediaStore
                        .VOLUME_EXTERNAL_PRIMARY
                )

        val expected =
            "/FA Fertigung/Einrichteplaene/" +
                "$cleanCustomer/$cleanNumber/"

        context
            .contentResolver
            .query(
                collection,
                arrayOf(
                    MediaStore.MediaColumns._ID,
                    MediaStore.MediaColumns.RELATIVE_PATH
                ),
                "${MediaStore.MediaColumns.DISPLAY_NAME}=?",
                arrayOf(
                    "Einrichteplan.pdf"
                ),
                null
            )
            ?.use {
                cursor ->

                val idIndex =
                    cursor.getColumnIndexOrThrow(
                        MediaStore.MediaColumns._ID
                    )

                val pathIndex =
                    cursor.getColumnIndexOrThrow(
                        MediaStore.MediaColumns.RELATIVE_PATH
                    )

                while (
                    cursor.moveToNext()
                ) {

                    val path =
                        cursor.getString(
                            pathIndex
                        )
                            ?: ""

                    if (
                        (
                            "/" +
                            path.trim('/')
                        )
                            .endsWith(
                                expected.trimEnd(
                                    '/'
                                )
                            ) ||
                        path.contains(
                            "FA Fertigung/Einrichteplaene/" +
                                "$cleanCustomer/$cleanNumber"
                        )
                    ) {

                        return ContentUris
                            .withAppendedId(
                                collection,
                                cursor.getLong(
                                    idIndex
                                )
                            )
                    }
                }
            }

        return null
    }

    private fun readMetadata(
        folder: File
    ): JSONObject {

        val metadata =
            File(
                folder,
                "archive.json"
            )

        return runCatching {
            JSONObject(
                metadata.readText(
                    Charsets.UTF_8
                )
            )
        }
            .getOrDefault(
                JSONObject()
            )
    }

    private fun bitmapsToPdf(
        sources: List<Bitmap>
    ): ByteArray {

        if (
            sources.isEmpty()
        ) {
            throw IllegalArgumentException(
                "Keine Seiten für PDF vorhanden."
            )
        }


        val document =
            PdfDocument()


        try {

            sources.forEachIndexed {
                index,
                source ->

                val portrait =
                    source.height >=
                        source.width

                val pageWidth =
                    if (
                        portrait
                    ) {
                        1240
                    } else {
                        1754
                    }

                val pageHeight =
                    if (
                        portrait
                    ) {
                        1754
                    } else {
                        1240
                    }

                val margin =
                    45f

                val maxWidth =
                    pageWidth -
                        margin *
                        2f

                val maxHeight =
                    pageHeight -
                        margin *
                        2f

                val scale =
                    min(
                        maxWidth /
                            source.width
                                .toFloat(),
                        maxHeight /
                            source.height
                                .toFloat()
                    )

                val drawWidth =
                    source.width *
                        scale

                val drawHeight =
                    source.height *
                        scale

                val left =
                    (
                        pageWidth -
                            drawWidth
                    ) /
                        2f

                val top =
                    (
                        pageHeight -
                            drawHeight
                    ) /
                        2f

                val pageInfo =
                    PdfDocument
                        .PageInfo
                        .Builder(
                            pageWidth,
                            pageHeight,
                            index + 1
                        )
                        .create()

                val page =
                    document.startPage(
                        pageInfo
                    )

                val canvas:
                    Canvas =
                    page.canvas

                canvas.drawColor(
                    Color.WHITE
                )

                canvas.drawBitmap(
                    source,
                    null,
                    android.graphics.RectF(
                        left,
                        top,
                        left +
                            drawWidth,
                        top +
                            drawHeight
                    ),
                    Paint(
                        Paint.ANTI_ALIAS_FLAG or
                            Paint.FILTER_BITMAP_FLAG
                    )
                )

                document.finishPage(
                    page
                )
            }


            val output =
                ByteArrayOutputStream()

            document.writeTo(
                output
            )

            return output
                .toByteArray()

        } finally {

            document.close()

        }
    }


    fun extractSetupNumber(
        text: String
    ): String {

        val normalized =
            text
                .replace(
                    '\u00A0',
                    ' '
                )
                .replace(
                    Regex(
                        """[ \t]+"""
                    ),
                    " "
                )


        /*
         1. Idealfall:
         "Einrichteplan: J3817"
         oder Label und Nummer in zwei OCR-Zeilen.
        */

        val direct =
            Regex(
                """Einrichteplan\s*:?\s*([A-Za-z]?\s*[-_]?\s*\d[\w-]*)""",
                setOf(
                    RegexOption.IGNORE_CASE,
                    RegexOption.MULTILINE
                )
            )
                .find(
                    normalized
                )
                ?.groupValues
                ?.getOrNull(
                    1
                )
                .orEmpty()
                .replace(
                    Regex(
                        """\s+"""
                    ),
                    ""
                )
                .trim()

        if (
            direct.isNotBlank()
        ) {

            return direct
                .uppercase()
        }


        /*
         2. Sehr robuster Fallback für die üblichen
         Einrichteplan-Nummern Jxxxx.

         Das hilft genau bei dem Fall, bei dem OCR "J3817"
         erkennt, die Lesereihenfolge aber nicht direkt hinter
         "Einrichteplan:" liegt.
        */

        val jNumber =
            Regex(
                """\bJ\s*[-_]?\s*(\d{3,10})\b""",
                RegexOption.IGNORE_CASE
            )
                .find(
                    normalized
                )
                ?.groupValues
                ?.getOrNull(
                    1
                )
                .orEmpty()

        if (
            jNumber.isNotBlank()
        ) {

            return (
                "J" +
                jNumber
            )
        }


        /*
         3. Nummer ohne J:
         Nur in direkter Umgebung des Wortes Einrichteplan
         suchen, damit keine Teile-/Auftragsnummer genommen wird.
        */

        val labelIndex =
            normalized
                .indexOf(
                    "Einrichteplan",
                    ignoreCase = true
                )

        if (
            labelIndex >= 0
        ) {

            val from =
                maxOf(
                    0,
                    labelIndex -
                        80
                )

            val to =
                minOf(
                    normalized.length,
                    labelIndex +
                        140
                )

            val window =
                normalized.substring(
                    from,
                    to
                )

            val nearby =
                Regex(
                    """\b([A-Za-z]?\d{3,10})\b""",
                    RegexOption.IGNORE_CASE
                )
                    .find(
                        window
                    )
                    ?.groupValues
                    ?.getOrNull(
                        1
                    )
                    .orEmpty()
                    .trim()

            if (
                nearby.isNotBlank()
            ) {

                return nearby
                    .uppercase()
            }
        }


        return "Ohne Nummer"
    }

    private fun safePathPart(
        value: String
    ): String {

        return value
            .trim()
            .replace(
                Regex(
                    """[\\/:*?"<>|]"""
                ),
                "_"
            )
            .replace(
                Regex(
                    """\s+"""
                ),
                " "
            )
            .trim(
                '.',
                ' '
            )
            .take(
                100
            )
    }
}
