package de.fa.fertigung.ai

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfRenderer
import android.os.Build
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.os.PowerManager
import android.util.Base64
import androidx.core.app.NotificationCompat
import com.google.mlkit.genai.common.DownloadStatus
import com.google.mlkit.genai.common.FeatureStatus
import com.google.mlkit.genai.prompt.Content
import com.google.mlkit.genai.prompt.Generation
import com.google.mlkit.genai.prompt.ImagePart
import com.google.mlkit.genai.prompt.TextPart
import com.google.mlkit.genai.prompt.generateContentRequest
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import de.fa.fertigung.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.max
import kotlin.math.roundToInt

class AiBackgroundService :
    Service() {

    private val scope =
        CoroutineScope(
            SupervisorJob() +
                Dispatchers.Main.immediate
        )

    private val generativeModel by lazy {
        Generation.getClient()
    }

    private val textRecognizer by lazy {
        TextRecognition.getClient(
            TextRecognizerOptions.DEFAULT_OPTIONS
        )
    }

    private var wakeLock:
        PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()

        createChannels()
    }

    override fun onBind(
        intent: Intent?
    ): IBinder? {
        return null
    }

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int
    ): Int {

        if (intent == null) {
            stopSelf(startId)
            return START_NOT_STICKY
        }

        val action =
            intent.getStringExtra(
                EXTRA_ACTION
            ).orEmpty()

        val requestId =
            intent.getStringExtra(
                EXTRA_REQUEST_ID
            ).orEmpty()

        val payloadPath =
            intent.getStringExtra(
                EXTRA_PAYLOAD_PATH
            ).orEmpty()

        val documentType =
            intent.getStringExtra(
                EXTRA_DOCUMENT_TYPE
            ).orEmpty()

        val jobKind =
            intent.getStringExtra(
                EXTRA_JOB_KIND
            )
                .orEmpty()
                .ifBlank {
                    action
                }

        if (
            requestId.isBlank() ||
            payloadPath.isBlank()
        ) {
            stopSelf(startId)
            return START_NOT_STICKY
        }

        startForeground(
            runningNotificationId(
                requestId
            ),
            buildRunningNotification(
                documentType,
                "Auswertung wird gestartet …"
            )
        )

        acquireWakeLock(
            requestId
        )

        scope.launch {
            try {
                val payloadFile =
                    File(
                        payloadPath
                    )

                val payloadJson =
                    withContext(
                        Dispatchers.IO
                    ) {
                        payloadFile
                            .readText(
                                Charsets.UTF_8
                            )
                    }

                when (action) {
                    ACTION_OCR -> {
                        processOcr(
                            requestId,
                            payloadJson,
                            documentType.ifBlank {
                                "fa"
                            },
                            jobKind
                        )
                    }

                    ACTION_ANALYZE -> {
                        processAnalyze(
                            requestId,
                            payloadJson,
                            documentType,
                            jobKind
                        )
                    }

                    else -> {
                        throw IllegalArgumentException(
                            "Unbekannte Hintergrundaktion."
                        )
                    }
                }

                runCatching {
                    payloadFile.delete()
                }

            } catch (t: Throwable) {
                val error =
                    JSONObject()
                        .put(
                            "ok",
                            false
                        )
                        .put(
                            "error",
                            t.message
                                ?: t.javaClass.simpleName
                        )
                        .toString()

                AiJobStore.complete(
                    this@AiBackgroundService,
                    requestId,
                    error,
                    documentType,
                    jobKind
                )

                showFinishedNotification(
                    requestId,
                    documentType,
                    false,
                    t.message
                        ?: "Auswertung fehlgeschlagen."
                )

            } finally {
                releaseWakeLock()

                if (
                    Build.VERSION.SDK_INT >=
                    Build.VERSION_CODES.N
                ) {
                    stopForeground(
                        STOP_FOREGROUND_REMOVE
                    )
                } else {
                    @Suppress("DEPRECATION")
                    stopForeground(true)
                }

                stopSelf(startId)
            }
        }

        return START_REDELIVER_INTENT
    }

    private suspend fun processOcr(
        requestId: String,
        payloadJson: String,
        documentType: String,
        jobKind: String
    ) {
        var bitmap:
            Bitmap? = null

        try {
            val payload =
                JSONObject(
                    payloadJson
                )

            val pages =
                payload.optJSONArray(
                    "pages"
                ) ?: JSONArray()

            if (
                pages.length() == 0
            ) {
                throw IllegalArgumentException(
                    "Kein Bild für OCR empfangen."
                )
            }

            val page =
                pages.optJSONObject(
                    0
                ) ?: throw IllegalArgumentException(
                    "Ungültige OCR-Seite."
                )

            val base64 =
                page.optString(
                    "base64"
                )

            if (
                base64.isBlank()
            ) {
                throw IllegalArgumentException(
                    "OCR-Bilddaten fehlen."
                )
            }

            progress(
                requestId,
                documentType,
                jobKind,
                "🔎 Bild wird lokal gelesen …"
            )

            bitmap =
                withContext(
                    Dispatchers.IO
                ) {
                    val bytes =
                        Base64.decode(
                            base64,
                            Base64.DEFAULT
                        )

                    decodeSampledBitmap(
                        bytes,
                        OCR_MAX_IMAGE_DIMENSION
                    )
                }

            val current =
                bitmap ?: throw IllegalStateException(
                    "Bild konnte für OCR nicht dekodiert werden."
                )

            progress(
                requestId,
                documentType,
                jobKind,
                "🔎 Text und Feldpositionen werden erkannt …"
            )

            val recognized =
                withTimeout(
                    OCR_TIMEOUT_MS
                ) {
                    textRecognizer
                        .process(
                            InputImage.fromBitmap(
                                current,
                                0
                            )
                        )
                        .await()
                }

            val lines =
                JSONArray()

            recognized
                .textBlocks
                .forEachIndexed {
                    blockIndex,
                    block ->

                    block.lines.forEachIndexed {
                        lineIndex,
                        line ->

                        val rect =
                            line.boundingBox

                        lines.put(
                            JSONObject()
                                .put(
                                    "text",
                                    line.text
                                )
                                .put(
                                    "left",
                                    rect?.left ?: 0
                                )
                                .put(
                                    "top",
                                    rect?.top ?: 0
                                )
                                .put(
                                    "right",
                                    rect?.right ?: 0
                                )
                                .put(
                                    "bottom",
                                    rect?.bottom ?: 0
                                )
                                .put(
                                    "blockIndex",
                                    blockIndex
                                )
                                .put(
                                    "lineIndex",
                                    lineIndex
                                )
                        )
                    }
                }

            val result =
                JSONObject()
                    .put(
                        "ok",
                        true
                    )
                    .put(
                        "provider",
                        "Android ML Kit Text Recognition"
                    )
                    .put(
                        "text",
                        recognized.text
                    )
                    .put(
                        "imageWidth",
                        current.width
                    )
                    .put(
                        "imageHeight",
                        current.height
                    )
                    .put(
                        "lines",
                        lines
                    )
                    .toString()

            AiJobStore.complete(
                this,
                requestId,
                result,
                documentType,
                jobKind
            )

            val faNumber =
                Regex(
                    """Fertigungsauftrag\s*#?\s*[:\-]?\s*(\d{4,10})""",
                    RegexOption.IGNORE_CASE
                )
                    .find(
                        recognized.text
                    )
                    ?.groupValues
                    ?.getOrNull(1)
                    .orEmpty()

            val message =
                if (
                    documentType == "fa" &&
                    faNumber.isNotBlank()
                ) {
                    "FA $faNumber erkannt ✓"
                } else {
                    "Dokument erkannt ✓"
                }

            showFinishedNotification(
                requestId,
                documentType,
                true,
                message
            )

        } finally {
            bitmap?.let {
                runCatching {
                    if (
                        !it.isRecycled
                    ) {
                        it.recycle()
                    }
                }
            }
        }
    }

    private suspend fun processAnalyze(
        requestId: String,
        payloadJson: String,
        documentType: String,
        jobKind: String
    ) {
        val visuals =
            mutableListOf<Bitmap>()

        try {
            progress(
                requestId,
                documentType,
                jobKind,
                "📱 Geräte-KI wird vorbereitet …"
            )

            ensureModelReady(
                requestId,
                documentType,
                jobKind
            )

            val payload =
                JSONObject(
                    payloadJson
                )

            val prompt =
                payload
                    .optString(
                        "prompt"
                    )
                    .trim()

            if (
                prompt.isEmpty()
            ) {
                throw IllegalArgumentException(
                    "Lokaler KI-Prompt fehlt."
                )
            }

            val pages =
                payload.optJSONArray(
                    "pages"
                ) ?: JSONArray()

            withContext(
                Dispatchers.IO
            ) {
                collectVisualPages(
                    pages,
                    visuals
                )
            }

            progress(
                requestId,
                documentType,
                jobKind,
                if (
                    visuals.isNotEmpty()
                ) {
                    "📱 Dokument wird lokal mit Gemini Nano gelesen …"
                } else {
                    "📱 Text wird lokal mit Gemini Nano ausgewertet …"
                }
            )

            val contentBuilder =
                Content.builder()

            contentBuilder.addPart(
                TextPart(
                    prompt
                )
            )

            visuals
                .take(
                    MAX_VISUALS
                )
                .forEach {
                    bitmap ->

                    contentBuilder.addPart(
                        ImagePart(
                            bitmap
                        )
                    )
                }

            val request =
                generateContentRequest(
                    contentBuilder.build()
                ) {
                    temperature =
                        0.1f

                    candidateCount =
                        1

                    maxOutputTokens =
                        3000
                }

            progress(
                requestId,
                documentType,
                jobKind,
                "📱 Gemini Nano verarbeitet das Dokument …"
            )

            val response =
                withTimeout(
                    INFERENCE_TIMEOUT_MS
                ) {
                    generativeModel
                        .generateContent(
                            request
                        )
                }

            val text =
                response
                    .candidates
                    .firstOrNull()
                    ?.text
                    .orEmpty()
                    .trim()

            if (
                text.isEmpty()
            ) {
                throw IllegalStateException(
                    "Gemini Nano hat keine Antwort geliefert."
                )
            }

            val result =
                JSONObject()
                    .put(
                        "ok",
                        true
                    )
                    .put(
                        "text",
                        text
                    )
                    .put(
                        "provider",
                        "Galaxy ${Build.MODEL} · Gemini Nano"
                    )
                    .toString()

            AiJobStore.complete(
                this,
                requestId,
                result,
                documentType,
                jobKind
            )

            val message =
                when (documentType) {
                    "material" ->
                        "Materialschein erkannt ✓"

                    "setup" ->
                        "Einrichteplan erkannt ✓"

                    "fa-article" ->
                        "Artikelbezeichnung erkannt ✓"

                    else ->
                        "Auswertung abgeschlossen ✓"
                }

            showFinishedNotification(
                requestId,
                documentType,
                true,
                message
            )

        } finally {
            visuals.forEach {
                bitmap ->

                runCatching {
                    if (
                        !bitmap.isRecycled
                    ) {
                        bitmap.recycle()
                    }
                }
            }
        }
    }

    private suspend fun ensureModelReady(
        requestId: String,
        documentType: String,
        jobKind: String
    ) {
        val firstStatus =
            withTimeout(
                STATUS_TIMEOUT_MS
            ) {
                generativeModel
                    .checkStatus()
            }

        when (
            firstStatus
        ) {
            FeatureStatus.AVAILABLE -> {
                progress(
                    requestId,
                    documentType,
                    jobKind,
                    "📱 Gemini Nano ist bereit."
                )
            }

            FeatureStatus.DOWNLOADABLE -> {
                progress(
                    requestId,
                    documentType,
                    jobKind,
                    "📱 Gemini Nano wird einmalig geladen …"
                )

                var completed =
                    false

                var failed:
                    Throwable? = null

                withTimeout(
                    DOWNLOAD_TIMEOUT_MS
                ) {
                    generativeModel
                        .download()
                        .collect {
                            status ->

                            when (
                                status
                            ) {
                                is DownloadStatus.DownloadStarted -> {
                                    progress(
                                        requestId,
                                        documentType,
                                        jobKind,
                                        "📱 Download von Gemini Nano startet …"
                                    )
                                }

                                is DownloadStatus.DownloadProgress -> {
                                    val mb =
                                        status.totalBytesDownloaded /
                                            (
                                                1024.0 *
                                                1024.0
                                            )

                                    progress(
                                        requestId,
                                        documentType,
                                        jobKind,
                                        "📱 Gemini Nano: %.1f MB"
                                            .format(
                                                mb
                                            )
                                    )
                                }

                                DownloadStatus.DownloadCompleted -> {
                                    completed =
                                        true
                                }

                                is DownloadStatus.DownloadFailed -> {
                                    failed =
                                        status.e
                                }
                            }
                        }
                }

                failed?.let {
                    throw it
                }

                if (
                    !completed
                ) {
                    throw IllegalStateException(
                        "Der Gemini-Nano-Download wurde nicht abgeschlossen."
                    )
                }

                val status =
                    withTimeout(
                        STATUS_TIMEOUT_MS
                    ) {
                        generativeModel
                            .checkStatus()
                    }

                if (
                    status !=
                    FeatureStatus.AVAILABLE
                ) {
                    throw IllegalStateException(
                        "Gemini Nano ist noch nicht verfügbar."
                    )
                }
            }

            FeatureStatus.DOWNLOADING -> {
                progress(
                    requestId,
                    documentType,
                    jobKind,
                    "📱 AICore lädt Gemini Nano weiter …"
                )

                withTimeout(
                    DOWNLOAD_TIMEOUT_MS
                ) {
                    while (
                        true
                    ) {
                        delay(
                            STATUS_POLL_MS
                        )

                        val status =
                            withTimeout(
                                STATUS_TIMEOUT_MS
                            ) {
                                generativeModel
                                    .checkStatus()
                            }

                        when (
                            status
                        ) {
                            FeatureStatus.AVAILABLE -> {
                                return@withTimeout
                            }

                            FeatureStatus.UNAVAILABLE -> {
                                throw IllegalStateException(
                                    "Gemini Nano ist nicht verfügbar."
                                )
                            }

                            else -> {
                                progress(
                                    requestId,
                                    documentType,
                                    jobKind,
                                    "📱 Geräte-KI wird weiter vorbereitet …"
                                )
                            }
                        }
                    }
                }
            }

            FeatureStatus.UNAVAILABLE -> {
                throw IllegalStateException(
                    "Gemini Nano/AICore ist auf diesem Gerät derzeit nicht verfügbar."
                )
            }

            else -> {
                throw IllegalStateException(
                    "Unbekannter Status der Geräte-KI: $firstStatus"
                )
            }
        }
    }

    private fun progress(
        requestId: String,
        documentType: String,
        jobKind: String,
        message: String
    ) {
        val payload =
            JSONObject()
                .put(
                    "message",
                    message
                )
                .toString()

        AiJobStore.setState(
            this,
            requestId,
            "progress",
            payload,
            documentType,
            jobKind
        )

        val manager =
            getSystemService(
                NotificationManager::class.java
            )

        manager?.notify(
            runningNotificationId(
                requestId
            ),
            buildRunningNotification(
                documentType,
                message
            )
        )
    }

    private fun buildRunningNotification(
        documentType: String,
        message: String
    ) =
        NotificationCompat
            .Builder(
                this,
                CHANNEL_WORK
            )
            .setSmallIcon(
                android.R.drawable.stat_sys_download
            )
            .setContentTitle(
                runningTitle(
                    documentType
                )
            )
            .setContentText(
                message
                    .replace(
                        "📱",
                        ""
                    )
                    .replace(
                        "🔎",
                        ""
                    )
                    .trim()
            )
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(
                NotificationCompat
                    .PRIORITY_LOW
            )
            .setContentIntent(
                appPendingIntent(
                    1000
                )
            )
            .build()

    private fun showFinishedNotification(
        requestId: String,
        documentType: String,
        success: Boolean,
        message: String
    ) {
        val manager =
            getSystemService(
                NotificationManager::class.java
            ) ?: return

        manager.notify(
            finishedNotificationId(
                requestId
            ),
            NotificationCompat
                .Builder(
                    this,
                    CHANNEL_RESULT
                )
                .setSmallIcon(
                    if (
                        success
                    ) {
                        android.R.drawable.stat_sys_download_done
                    } else {
                        android.R.drawable.stat_notify_error
                    }
                )
                .setContentTitle(
                    if (
                        success
                    ) {
                        "FA Fertigung"
                    } else {
                        "FA Fertigung · Fehler"
                    }
                )
                .setContentText(
                    message
                )
                .setAutoCancel(true)
                .setPriority(
                    NotificationCompat
                        .PRIORITY_HIGH
                )
                .setContentIntent(
                    appPendingIntent(
                        finishedNotificationId(
                            requestId
                        )
                    )
                )
                .build()
        )
    }

    private fun runningTitle(
        documentType: String
    ): String {
        return when (
            documentType
        ) {
            "fa" ->
                "FA wird ausgewertet …"

            "material" ->
                "Materialschein wird ausgewertet …"

            "setup" ->
                "Einrichteplan wird ausgewertet …"

            "fa-article" ->
                "Artikelbezeichnung wird ausgewertet …"

            else ->
                "Dokument wird ausgewertet …"
        }
    }

    private fun appPendingIntent(
        requestCode: Int
    ): PendingIntent {
        val intent =
            Intent(
                this,
                MainActivity::class.java
            ).apply {
                flags =
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP

                putExtra(
                    "openAiResult",
                    true
                )
            }

        return PendingIntent
            .getActivity(
                this,
                requestCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or
                    PendingIntent.FLAG_IMMUTABLE
            )
    }

    private fun createChannels() {
        if (
            Build.VERSION.SDK_INT <
            Build.VERSION_CODES.O
        ) {
            return
        }

        val manager =
            getSystemService(
                NotificationManager::class.java
            ) ?: return

        val work =
            NotificationChannel(
                CHANNEL_WORK,
                "KI-Auswertung",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description =
                    "Laufende lokale Dokumentauswertung"
            }

        val result =
            NotificationChannel(
                CHANNEL_RESULT,
                "KI-Ergebnisse",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description =
                    "Benachrichtigung nach abgeschlossener Auswertung"
            }

        manager.createNotificationChannel(
            work
        )

        manager.createNotificationChannel(
            result
        )
    }

    private fun acquireWakeLock(
        requestId: String
    ) {
        val power =
            getSystemService(
                POWER_SERVICE
            ) as? PowerManager
                ?: return

        wakeLock =
            power.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "FAFertigung:AI:$requestId"
            ).apply {
                setReferenceCounted(false)

                acquire(
                    WAKE_LOCK_TIMEOUT_MS
                )
            }
    }

    private fun releaseWakeLock() {
        val lock =
            wakeLock

        if (
            lock != null &&
            lock.isHeld
        ) {
            runCatching {
                lock.release()
            }
        }

        wakeLock =
            null
    }

    private fun collectVisualPages(
        pages: JSONArray,
        out: MutableList<Bitmap>
    ) {
        for (
            i in 0 until pages.length()
        ) {
            if (
                out.size >=
                MAX_VISUALS
            ) {
                break
            }

            val page =
                pages.optJSONObject(
                    i
                ) ?: continue

            val mime =
                page
                    .optString(
                        "mimeType"
                    )
                    .lowercase()

            val name =
                page
                    .optString(
                        "name"
                    )
                    .lowercase()

            val b64 =
                page.optString(
                    "base64"
                )

            if (
                b64.isBlank()
            ) {
                continue
            }

            val bytes =
                Base64.decode(
                    b64,
                    Base64.DEFAULT
                )

            when {
                mime.startsWith(
                    "image/"
                ) ||
                name.endsWith(
                    ".jpg"
                ) ||
                name.endsWith(
                    ".jpeg"
                ) ||
                name.endsWith(
                    ".png"
                ) ||
                name.endsWith(
                    ".webp"
                ) -> {
                    decodeSampledBitmap(
                        bytes
                    )?.let(
                        out::add
                    )
                }

                mime ==
                    "application/pdf" ||
                name.endsWith(
                    ".pdf"
                ) -> {
                    out.addAll(
                        renderPdf(
                            bytes,
                            MAX_VISUALS -
                                out.size
                        )
                    )
                }
            }
        }
    }

    private fun decodeSampledBitmap(
        bytes: ByteArray,
        maxDimension: Int =
            MAX_IMAGE_DIMENSION
    ): Bitmap? {
        val bounds =
            BitmapFactory
                .Options()
                .apply {
                    inJustDecodeBounds =
                        true
                }

        BitmapFactory.decodeByteArray(
            bytes,
            0,
            bytes.size,
            bounds
        )

        var sample =
            1

        val width =
            bounds.outWidth

        val height =
            bounds.outHeight

        while (
            width / sample >
            maxDimension ||
            height / sample >
            maxDimension
        ) {
            sample *=
                2
        }

        val options =
            BitmapFactory
                .Options()
                .apply {
                    inSampleSize =
                        max(
                            1,
                            sample
                        )

                    inPreferredConfig =
                        Bitmap.Config.ARGB_8888
                }

        return BitmapFactory
            .decodeByteArray(
                bytes,
                0,
                bytes.size,
                options
            )
    }

    private fun renderPdf(
        bytes: ByteArray,
        maxPages: Int
    ): List<Bitmap> {
        if (
            maxPages <= 0
        ) {
            return emptyList()
        }

        val dir =
            File(
                cacheDir,
                "background_ai_pdf"
            ).apply {
                mkdirs()
            }

        val file =
            File.createTempFile(
                "fa_bg_",
                ".pdf",
                dir
            )

        file.writeBytes(
            bytes
        )

        val bitmaps =
            mutableListOf<Bitmap>()

        try {
            ParcelFileDescriptor
                .open(
                    file,
                    ParcelFileDescriptor
                        .MODE_READ_ONLY
                )
                .use {
                    descriptor ->

                    PdfRenderer(
                        descriptor
                    ).use {
                        renderer ->

                        val count =
                            minOf(
                                renderer.pageCount,
                                maxPages
                            )

                        for (
                            i in 0 until count
                        ) {
                            renderer
                                .openPage(
                                    i
                                )
                                .use {
                                    page ->

                                    val scale =
                                        minOf(
                                            1.8f,
                                            MAX_IMAGE_DIMENSION
                                                .toFloat() /
                                                max(
                                                    page.width,
                                                    page.height
                                                )
                                                    .toFloat()
                                        )

                                    val width =
                                        max(
                                            1,
                                            (
                                                page.width *
                                                scale
                                            )
                                                .roundToInt()
                                        )

                                    val height =
                                        max(
                                            1,
                                            (
                                                page.height *
                                                scale
                                            )
                                                .roundToInt()
                                        )

                                    val bitmap =
                                        Bitmap.createBitmap(
                                            width,
                                            height,
                                            Bitmap.Config
                                                .ARGB_8888
                                        )

                                    bitmap.eraseColor(
                                        android.graphics
                                            .Color
                                            .WHITE
                                    )

                                    page.render(
                                        bitmap,
                                        null,
                                        null,
                                        PdfRenderer.Page
                                            .RENDER_MODE_FOR_DISPLAY
                                    )

                                    bitmaps.add(
                                        bitmap
                                    )
                                }
                        }
                    }
                }
        } finally {
            runCatching {
                file.delete()
            }
        }

        return bitmaps
    }

    override fun onDestroy() {
        releaseWakeLock()

        runCatching {
            textRecognizer.close()
        }

        runCatching {
            generativeModel.close()
        }

        scope.cancel()

        super.onDestroy()
    }

    companion object {
        const val ACTION_OCR =
            "de.fa.fertigung.action.OCR"

        const val ACTION_ANALYZE =
            "de.fa.fertigung.action.ANALYZE"

        const val EXTRA_ACTION =
            "action"

        const val EXTRA_REQUEST_ID =
            "requestId"

        const val EXTRA_PAYLOAD_PATH =
            "payloadPath"

        const val EXTRA_DOCUMENT_TYPE =
            "documentType"

        const val EXTRA_JOB_KIND =
            "jobKind"

        private const val CHANNEL_WORK =
            "fa_ai_work"

        private const val CHANNEL_RESULT =
            "fa_ai_result"

        private const val MAX_VISUALS =
            4

        private const val MAX_IMAGE_DIMENSION =
            1600

        private const val OCR_MAX_IMAGE_DIMENSION =
            2800

        private const val STATUS_TIMEOUT_MS =
            30000L

        private const val STATUS_POLL_MS =
            2000L

        private const val DOWNLOAD_TIMEOUT_MS =
            600000L

        private const val INFERENCE_TIMEOUT_MS =
            180000L

        private const val OCR_TIMEOUT_MS =
            45000L

        private const val WAKE_LOCK_TIMEOUT_MS =
            15L *
            60L *
            1000L

        fun start(
            context: android.content.Context,
            action: String,
            requestId: String,
            payloadJson: String,
            documentType: String,
            jobKind: String
        ) {
            val dir =
                File(
                    context.cacheDir,
                    "ai_jobs"
                ).apply {
                    mkdirs()
                }

            val payloadFile =
                File(
                    dir,
                    "$requestId.json"
                )

            payloadFile.writeText(
                payloadJson,
                Charsets.UTF_8
            )

            val intent =
                Intent(
                    context,
                    AiBackgroundService::class.java
                ).apply {
                    putExtra(
                        EXTRA_ACTION,
                        action
                    )

                    putExtra(
                        EXTRA_REQUEST_ID,
                        requestId
                    )

                    putExtra(
                        EXTRA_PAYLOAD_PATH,
                        payloadFile.absolutePath
                    )

                    putExtra(
                        EXTRA_DOCUMENT_TYPE,
                        documentType
                    )

                    putExtra(
                        EXTRA_JOB_KIND,
                        jobKind
                    )
                }

            androidx.core.content.ContextCompat
                .startForegroundService(
                    context,
                    intent
                )
        }

        private fun runningNotificationId(
            requestId: String
        ): Int {
            return (
                10000 +
                (
                    requestId
                        .hashCode() and
                        0x3fff
                )
            )
        }

        private fun finishedNotificationId(
            requestId: String
        ): Int {
            return (
                30000 +
                (
                    requestId
                        .hashCode() and
                        0x3fff
                )
            )
        }
    }
}
