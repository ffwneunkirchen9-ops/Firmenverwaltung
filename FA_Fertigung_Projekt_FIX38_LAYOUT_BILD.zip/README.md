# FA Fertigung FIX38

Wear-OS-Kachel nach dem freigegebenen Layoutbild.

## Build/Installation
Nur die Watch-App neu bauen und installieren.
Handy-App und `script.html` bleiben unverändert.

Beim Entgraten zeigt die Kachel die Tagesstückzahl und zählt über den großen mittleren Button in +10er-Schritten. −1/+1 bleiben für Korrekturen.
