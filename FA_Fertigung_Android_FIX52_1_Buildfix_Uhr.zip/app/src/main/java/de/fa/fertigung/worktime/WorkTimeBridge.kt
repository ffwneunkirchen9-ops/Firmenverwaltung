package de.fa.fertigung.worktime

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Build
import android.webkit.JavascriptInterface
import android.webkit.WebView
import com.google.android.gms.wearable.PutDataMapRequest
import com.google.android.gms.wearable.Wearable
import org.json.JSONArray
import org.json.JSONObject

/** FIX52: Nur separate Arbeitszeiterfassung; keine Änderung am FA-Datenspeicher. */
class WorkTimeBridge(private val activity: Activity, private val web: WebView) {
    private val prefs get() = activity.getSharedPreferences("fa_work_native_52", Context.MODE_PRIVATE)

    @JavascriptInterface
    fun setWorkState(json: String) {
        val o = runCatching { JSONObject(json) }.getOrNull() ?: return
        if (!o.has("active")) return
        activity.runOnUiThread {
            prefs.edit().putString("state", o.toString()).commit()
            val intent = Intent(activity, WorkTimeService::class.java).apply {
                action = WorkTimeService.ACTION_UPDATE
                putExtra("state", o.toString())
            }
            try {
                if (o.optBoolean("active") && Build.VERSION.SDK_INT >= 26) {
                    activity.startForegroundService(intent)
                } else {
                    activity.startService(intent)
                }
            } catch (e: Exception) {
                android.util.Log.e("FAWork", "Benachrichtigung konnte nicht gestartet werden", e)
            }
            // Derselbe Status ist auf der Uhr lesbar; lokale Uhr-Ereignisse haben Vorrang.
            val req = PutDataMapRequest.create("/fa/watch/worktime")
            req.dataMap.putString("json", o.toString())
            req.dataMap.putLong("updatedAt", System.currentTimeMillis())
            Wearable.getDataClient(activity).putDataItem(req.asPutDataRequest().setUrgent())
        }
    }

    @JavascriptInterface
    fun peekWorkActions(): String = synchronized(WorkTimeService.LOCK) {
        prefs.getString("pending", "[]") ?: "[]"
    }

    @JavascriptInterface
    fun ackWorkAction(id: String) = synchronized(WorkTimeService.LOCK) {
        if (id.isBlank()) return@synchronized
        val old = runCatching { JSONArray(prefs.getString("pending", "[]")) }.getOrDefault(JSONArray())
        val next = JSONArray()
        for (i in 0 until old.length()) {
            val row = old.optJSONObject(i) ?: continue
            if (row.optString("id") != id) next.put(row)
        }
        prefs.edit().putString("pending", next.toString()).commit()
    }
}
