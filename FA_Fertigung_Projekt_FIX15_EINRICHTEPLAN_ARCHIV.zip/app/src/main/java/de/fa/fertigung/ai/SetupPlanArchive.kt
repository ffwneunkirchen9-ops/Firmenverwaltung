package de.fa.fertigung.ai

import android.content.ContentValues
import android.content.ContentUris
import android.content.Intent
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Build
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.math.min
import kotlin.math.roundToInt

object SetupPlanArchive {

    fun saveDataUrlAsPdf(
        context: Context,
        customer: String,
        setupNumber: String,
        dataUrl: String
    ): JSONObject {
        val base64 =
            if (
                dataUrl.contains(
                    "base64,"
                )
            ) {
                dataUrl.substringAfter(
                    "base64,"
                )
            } else {
                dataUrl
            }

        val bytes =
            Base64.decode(
                base64,
                Base64.DEFAULT
            )

        val bitmap =
            BitmapFactory
                .decodeByteArray(
                    bytes,
                    0,
                    bytes.size
                )
                ?: throw IllegalArgumentException(
                    "Einrichteplan-Bild konnte nicht gelesen werden."
                )

        return try {
            saveBitmapAsPdf(
                context,
                customer,
                setupNumber,
                bitmap
            )
        } finally {
            runCatching {
                if (
                    !bitmap.isRecycled
                ) {
                    bitmap.recycle()
                }
            }
        }
    }

    fun saveBitmapAsPdf(
        context: Context,
        customer: String,
        setupNumber: String,
        bitmap: Bitmap
    ): JSONObject {

        val cleanCustomer =
            safePathPart(
                customer
            )
                .ifBlank {
                    "Unbekannter Kunde"
                }

        val cleanNumber =
            safePathPart(
                setupNumber
            )
                .ifBlank {
                    "Ohne Nummer"
                }

        val relativePath =
            "Documents/FA Fertigung/Einrichteplaene/" +
            "$cleanCustomer/$cleanNumber/"

        val displayName =
            "Einrichteplan.pdf"

        val pdfBytes =
            bitmapToPdf(
                bitmap
            )

        val savedPath =
            if (
                Build.VERSION.SDK_INT >=
                Build.VERSION_CODES.Q
            ) {
                val resolver =
                    context.contentResolver

                val collection =
                    MediaStore.Files
                        .getContentUri(
                            MediaStore
                                .VOLUME_EXTERNAL_PRIMARY
                        )

                resolver.delete(
                    collection,
                    "${MediaStore.MediaColumns.RELATIVE_PATH}=? AND " +
                        "${MediaStore.MediaColumns.DISPLAY_NAME}=?",
                    arrayOf(
                        relativePath,
                        displayName
                    )
                )

                val values =
                    ContentValues()
                        .apply {
                            put(
                                MediaStore.MediaColumns.DISPLAY_NAME,
                                displayName
                            )

                            put(
                                MediaStore.MediaColumns.MIME_TYPE,
                                "application/pdf"
                            )

                            put(
                                MediaStore.MediaColumns.RELATIVE_PATH,
                                relativePath
                            )

                            put(
                                MediaStore.MediaColumns.IS_PENDING,
                                1
                            )
                        }

                val uri =
                    resolver.insert(
                        collection,
                        values
                    )
                        ?: throw IllegalStateException(
                            "PDF-Speicher konnte nicht angelegt werden."
                        )

                resolver
                    .openOutputStream(
                        uri,
                        "w"
                    )
                    ?.use {
                        stream ->

                        stream.write(
                            pdfBytes
                        )

                        stream.flush()
                    }
                    ?: throw IllegalStateException(
                        "Einrichteplan-PDF konnte nicht geschrieben werden."
                    )

                val finished =
                    ContentValues()
                        .apply {
                            put(
                                MediaStore.MediaColumns.IS_PENDING,
                                0
                            )
                        }

                resolver.update(
                    uri,
                    finished,
                    null,
                    null
                )

                relativePath +
                    displayName

            } else {
                val root =
                    context.getExternalFilesDir(
                        Environment
                            .DIRECTORY_DOCUMENTS
                    )
                        ?: context.filesDir

                val folder =
                    File(
                        root,
                        "FA Fertigung/Einrichteplaene/" +
                            "$cleanCustomer/$cleanNumber"
                    )
                        .apply {
                            mkdirs()
                        }

                val file =
                    File(
                        folder,
                        displayName
                    )

                file.writeBytes(
                    pdfBytes
                )

                file.absolutePath
            }

        val metadataFolder =
            File(
                context.filesDir,
                "Einrichteplaene/" +
                    "$cleanCustomer/$cleanNumber"
            )
                .apply {
                    mkdirs()
                }

        File(
            metadataFolder,
            "archive.json"
        )
            .writeText(
                JSONObject()
                    .put(
                        "customer",
                        customer.trim()
                    )
                    .put(
                        "setupNumber",
                        setupNumber.trim()
                    )
                    .put(
                        "path",
                        savedPath
                    )
                    .put(
                        "savedAt",
                        System.currentTimeMillis()
                    )
                    .toString(
                        2
                    ),
                Charsets.UTF_8
            )

        return JSONObject()
            .put(
                "ok",
                true
            )
            .put(
                "customer",
                customer.trim()
            )
            .put(
                "setupNumber",
                setupNumber.trim()
            )
            .put(
                "path",
                savedPath
            )
    }

    fun listPlans(
        context: Context
    ): JSONObject {

        val items =
            JSONArray()


        val root =
            File(
                context.filesDir,
                "Einrichteplaene"
            )


        if (
            root.exists()
        ) {

            root
                .listFiles()
                ?.filter {
                    it.isDirectory
                }
                ?.sortedBy {
                    it.name.lowercase()
                }
                ?.forEach {
                    customerFolder ->

                    customerFolder
                        .listFiles()
                        ?.filter {
                            it.isDirectory
                        }
                        ?.sortedBy {
                            it.name.lowercase()
                        }
                        ?.forEach {
                            setupFolder ->

                            val metadata =
                                File(
                                    setupFolder,
                                    "archive.json"
                                )


                            val data =
                                runCatching {
                                    JSONObject(
                                        metadata.readText(
                                            Charsets.UTF_8
                                        )
                                    )
                                }
                                    .getOrDefault(
                                        JSONObject()
                                    )


                            val customer =
                                data
                                    .optString(
                                        "customer"
                                    )
                                    .ifBlank {
                                        customerFolder.name
                                    }


                            val setupNumber =
                                data
                                    .optString(
                                        "setupNumber"
                                    )
                                    .ifBlank {
                                        setupFolder.name
                                    }


                            val path =
                                data.optString(
                                    "path"
                                )


                            val savedAt =
                                data.optLong(
                                    "savedAt",
                                    metadata
                                        .takeIf {
                                            it.exists()
                                        }
                                        ?.lastModified()
                                        ?: 0L
                                )


                            val exists =
                                pdfExists(
                                    context,
                                    customer,
                                    setupNumber,
                                    path
                                )


                            items.put(
                                JSONObject()
                                    .put(
                                        "customer",
                                        customer
                                    )
                                    .put(
                                        "setupNumber",
                                        setupNumber
                                    )
                                    .put(
                                        "path",
                                        path
                                    )
                                    .put(
                                        "savedAt",
                                        savedAt
                                    )
                                    .put(
                                        "exists",
                                        exists
                                    )
                            )

                        }
                }

        }


        return JSONObject()
            .put(
                "ok",
                true
            )
            .put(
                "items",
                items
            )
    }


    fun openPlan(
        context: Context,
        customer: String,
        setupNumber: String
    ): JSONObject {

        val uri =
            findPdfUri(
                context,
                customer,
                setupNumber
            )
                ?: findLegacyPdfUri(
                    context,
                    customer,
                    setupNumber
                )
                ?: throw IllegalStateException(
                    "Die gespeicherte PDF-Datei wurde nicht gefunden."
                )


        val intent =
            Intent(
                Intent.ACTION_VIEW
            )
                .setDataAndType(
                    uri,
                    "application/pdf"
                )
                .addFlags(
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
                .addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK
                )


        context.startActivity(
            Intent.createChooser(
                intent,
                "Einrichteplan öffnen"
            )
                .addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK
                )
        )


        return JSONObject()
            .put(
                "ok",
                true
            )
    }


    fun deletePlan(
        context: Context,
        customer: String,
        setupNumber: String
    ): JSONObject {

        val cleanCustomer =
            safePathPart(
                customer
            )
                .ifBlank {
                    "Unbekannter Kunde"
                }


        val cleanNumber =
            safePathPart(
                setupNumber
            )
                .ifBlank {
                    "Ohne Nummer"
                }


        var deleted =
            0


        if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.Q
        ) {

            val relativePath =
                mediaRelativePath(
                    cleanCustomer,
                    cleanNumber
                )


            val resolver =
                context.contentResolver


            val collection =
                MediaStore.Files
                    .getContentUri(
                        MediaStore
                            .VOLUME_EXTERNAL_PRIMARY
                    )


            deleted +=
                resolver.delete(
                    collection,
                    "${MediaStore.MediaColumns.RELATIVE_PATH}=? AND " +
                    "${MediaStore.MediaColumns.DISPLAY_NAME}=?",
                    arrayOf(
                        relativePath,
                        "Einrichteplan.pdf"
                    )
                )

        } else {

            val metadata =
                readMetadata(
                    context,
                    cleanCustomer,
                    cleanNumber
                )


            val path =
                metadata
                    .optString(
                        "path"
                    )


            if (
                path.isNotBlank()
            ) {

                val file =
                    File(
                        path
                    )


                if (
                    file.exists() &&
                    file.delete()
                ) {
                    deleted++
                }

            }

        }


        val metadataFolder =
            File(
                context.filesDir,
                "Einrichteplaene/" +
                "$cleanCustomer/$cleanNumber"
            )


        if (
            metadataFolder.exists()
        ) {

            metadataFolder
                .deleteRecursively()

        }


        val customerFolder =
            File(
                context.filesDir,
                "Einrichteplaene/$cleanCustomer"
            )


        if (
            customerFolder.exists() &&
            customerFolder
                .listFiles()
                .isNullOrEmpty()
        ) {

            customerFolder.delete()

        }


        return JSONObject()
            .put(
                "ok",
                true
            )
            .put(
                "deleted",
                deleted
            )
    }


    private fun pdfExists(
        context: Context,
        customer: String,
        setupNumber: String,
        storedPath: String
    ): Boolean {

        if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.Q
        ) {

            return (
                findPdfUri(
                    context,
                    customer,
                    setupNumber
                ) != null
            )

        }


        return (
            storedPath.isNotBlank() &&
            File(
                storedPath
            ).exists()
        )
    }


    private fun findPdfUri(
        context: Context,
        customer: String,
        setupNumber: String
    ): Uri? {

        if (
            Build.VERSION.SDK_INT <
            Build.VERSION_CODES.Q
        ) {
            return null
        }


        val cleanCustomer =
            safePathPart(
                customer
            )
                .ifBlank {
                    "Unbekannter Kunde"
                }


        val cleanNumber =
            safePathPart(
                setupNumber
            )
                .ifBlank {
                    "Ohne Nummer"
                }


        val relativePath =
            mediaRelativePath(
                cleanCustomer,
                cleanNumber
            )


        val collection =
            MediaStore.Files
                .getContentUri(
                    MediaStore
                        .VOLUME_EXTERNAL_PRIMARY
                )


        val projection =
            arrayOf(
                MediaStore.MediaColumns._ID
            )


        context
            .contentResolver
            .query(
                collection,
                projection,
                "${MediaStore.MediaColumns.RELATIVE_PATH}=? AND " +
                "${MediaStore.MediaColumns.DISPLAY_NAME}=?",
                arrayOf(
                    relativePath,
                    "Einrichteplan.pdf"
                ),
                null
            )
            ?.use {
                cursor ->

                if (
                    cursor.moveToFirst()
                ) {

                    val id =
                        cursor.getLong(
                            cursor.getColumnIndexOrThrow(
                                MediaStore.MediaColumns._ID
                            )
                        )


                    return ContentUris
                        .withAppendedId(
                            collection,
                            id
                        )

                }
            }


        return null
    }


    private fun findLegacyPdfUri(
        context: Context,
        customer: String,
        setupNumber: String
    ): Uri? {

        val cleanCustomer =
            safePathPart(
                customer
            )
                .ifBlank {
                    "Unbekannter Kunde"
                }


        val cleanNumber =
            safePathPart(
                setupNumber
            )
                .ifBlank {
                    "Ohne Nummer"
                }


        val metadata =
            readMetadata(
                context,
                cleanCustomer,
                cleanNumber
            )


        val path =
            metadata.optString(
                "path"
            )


        if (
            path.isBlank()
        ) {
            return null
        }


        val file =
            File(
                path
            )


        if (
            !file.exists()
        ) {
            return null
        }


        return FileProvider
            .getUriForFile(
                context,
                context.packageName +
                    ".fileprovider",
                file
            )
    }


    private fun readMetadata(
        context: Context,
        cleanCustomer: String,
        cleanNumber: String
    ): JSONObject {

        val metadata =
            File(
                context.filesDir,
                "Einrichteplaene/" +
                "$cleanCustomer/$cleanNumber/archive.json"
            )


        return runCatching {

            JSONObject(
                metadata.readText(
                    Charsets.UTF_8
                )
            )

        }
            .getOrDefault(
                JSONObject()
            )
    }


    private fun mediaRelativePath(
        cleanCustomer: String,
        cleanNumber: String
    ): String {

        return (
            "Documents/FA Fertigung/Einrichteplaene/" +
            "$cleanCustomer/$cleanNumber/"
        )
    }


    private fun bitmapToPdf(
        source: Bitmap
    ): ByteArray {

        val portrait =
            source.height >=
            source.width

        val pageWidth =
            if (portrait) {
                1240
            } else {
                1754
            }

        val pageHeight =
            if (portrait) {
                1754
            } else {
                1240
            }

        val margin =
            45f

        val maxWidth =
            pageWidth -
            margin *
            2f

        val maxHeight =
            pageHeight -
            margin *
            2f

        val scale =
            min(
                maxWidth /
                    source.width
                        .toFloat(),
                maxHeight /
                    source.height
                        .toFloat()
            )

        val drawWidth =
            source.width *
            scale

        val drawHeight =
            source.height *
            scale

        val left =
            (
                pageWidth -
                drawWidth
            ) /
            2f

        val top =
            (
                pageHeight -
                drawHeight
            ) /
            2f

        val document =
            PdfDocument()

        try {
            val pageInfo =
                PdfDocument
                    .PageInfo
                    .Builder(
                        pageWidth,
                        pageHeight,
                        1
                    )
                    .create()

            val page =
                document.startPage(
                    pageInfo
                )

            val canvas:
                Canvas =
                page.canvas

            canvas.drawColor(
                Color.WHITE
            )

            val destination =
                android.graphics.RectF(
                    left,
                    top,
                    left +
                        drawWidth,
                    top +
                        drawHeight
                )

            canvas.drawBitmap(
                source,
                null,
                destination,
                Paint(
                    Paint.ANTI_ALIAS_FLAG or
                        Paint.FILTER_BITMAP_FLAG
                )
            )

            document.finishPage(
                page
            )

            val output =
                ByteArrayOutputStream()

            document.writeTo(
                output
            )

            return output
                .toByteArray()

        } finally {
            document.close()
        }
    }

    fun extractSetupNumber(
        aiText: String
    ): String {

        val cleaned =
            aiText
                .trim()
                .removePrefix(
                    "```json"
                )
                .removePrefix(
                    "```"
                )
                .removeSuffix(
                    "```"
                )
                .trim()

        return runCatching {
            JSONObject(
                cleaned
            )
                .optString(
                    "setupNumber"
                )
                .trim()
        }
            .getOrDefault(
                ""
            )
    }

    private fun safePathPart(
        value: String
    ): String {

        return value
            .trim()
            .replace(
                Regex(
                    """[\\/:*?"<>|]"""
                ),
                "_"
            )
            .replace(
                Regex(
                    """\s+"""
                ),
                " "
            )
            .trim(
                '.',
                ' '
            )
            .take(
                100
            )
    }
}
