package de.fa.fertigung.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfRenderer
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import com.google.mlkit.genai.common.DownloadStatus
import com.google.mlkit.genai.common.FeatureStatus
import com.google.mlkit.genai.prompt.Content
import com.google.mlkit.genai.prompt.Generation
import com.google.mlkit.genai.prompt.ImagePart
import com.google.mlkit.genai.prompt.TextPart
import com.google.mlkit.genai.prompt.generateContentRequest
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.max
import kotlin.math.roundToInt

class LocalAiBridge(
    private val context: Context,
    private val webView: WebView
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val generativeModel by lazy { Generation.getClient() }
    private val textRecognizer by lazy {
        TextRecognition.getClient(
            TextRecognizerOptions.DEFAULT_OPTIONS
        )
    }
    private val nativeStates = ConcurrentHashMap<String, String>()

    @JavascriptInterface
    fun status(): String {
        return JSONObject()
            .put("bridge", true)
            .put("platform", "android")
            .put("device", "${Build.MANUFACTURER} ${Build.MODEL}")
            .put("version", "1.0.0")
            .toString()
    }

    @JavascriptInterface
    fun saveSetupPlanPdf(
        customer: String,
        setupNumber: String,
        dataUrl: String
    ): String {

        return try {

            SetupPlanArchive
                .saveDataUrlAsPdf(
                    context,
                    customer,
                    setupNumber,
                    dataUrl
                )
                .toString()

        } catch (
            t: Throwable
        ) {

            JSONObject()
                .put(
                    "ok",
                    false
                )
                .put(
                    "error",
                    t.message
                        ?: t.javaClass.simpleName
                )
                .toString()
        }
    }


    @JavascriptInterface
    fun listSetupPlans(): String {

        return try {

            SetupPlanArchive
                .listPlans(
                    context
                )
                .toString()

        } catch (
            t: Throwable
        ) {

            JSONObject()
                .put(
                    "ok",
                    false
                )
                .put(
                    "error",
                    t.message
                        ?: t.javaClass.simpleName
                )
                .toString()
        }
    }


    @JavascriptInterface
    fun openSetupPlan(
        customer: String,
        setupNumber: String
    ): String {

        return try {

            SetupPlanArchive
                .openPlan(
                    context,
                    customer,
                    setupNumber
                )
                .toString()

        } catch (
            t: Throwable
        ) {

            JSONObject()
                .put(
                    "ok",
                    false
                )
                .put(
                    "error",
                    t.message
                        ?: t.javaClass.simpleName
                )
                .toString()
        }
    }


    @JavascriptInterface
    fun deleteSetupPlan(
        customer: String,
        setupNumber: String
    ): String {

        return try {

            SetupPlanArchive
                .deletePlan(
                    context,
                    customer,
                    setupNumber
                )
                .toString()

        } catch (
            t: Throwable
        ) {

            JSONObject()
                .put(
                    "ok",
                    false
                )
                .put(
                    "error",
                    t.message
                        ?: t.javaClass.simpleName
                )
                .toString()
        }
    }


    @JavascriptInterface
    fun poll(requestId: String): String {
        return AiJobStore.poll(
            context,
            requestId
        )
    }


    @JavascriptInterface
    fun takeCompleted(): String {
        return AiJobStore.takeCompleted(
            context
        )
    }



    @JavascriptInterface
    fun ocr(
        requestId: String,
        payloadJson: String
    ) {
        val safeId =
            requestId.trim()

        if (
            safeId.isEmpty()
        ) {
            return
        }

        val payload =
            runCatching {
                JSONObject(
                    payloadJson
                )
            }
                .getOrDefault(
                    JSONObject()
                )

        val documentType =
            payload.optString(
                "documentType",
                "fa"
            )

        val jobKind =
            payload.optString(
                "jobKind",
                "ocr"
            )

        AiBackgroundService.start(
            context,
            AiBackgroundService.ACTION_OCR,
            safeId,
            payloadJson,
            documentType,
            jobKind
        )
    }


    @JavascriptInterface
    fun analyze(
        requestId: String,
        payloadJson: String
    ) {
        val safeId =
            requestId.trim()

        if (
            safeId.isEmpty()
        ) {
            return
        }

        val payload =
            runCatching {
                JSONObject(
                    payloadJson
                )
            }
                .getOrDefault(
                    JSONObject()
                )

        val documentType =
            payload.optString(
                "documentType",
                "document"
            )

        val jobKind =
            payload.optString(
                "jobKind",
                "analyze"
            )

        AiBackgroundService.start(
            context,
            AiBackgroundService.ACTION_ANALYZE,
            safeId,
            payloadJson,
            documentType,
            jobKind
        )
    }

    fun close() {
        nativeStates.clear()
        scope.cancel()
    }

    private suspend fun ensureModelReady(
        requestId: String
    ) {

        val firstStatus =
            withTimeout(
                STATUS_TIMEOUT_MS
            ) {
                generativeModel.checkStatus()
            }


        when (firstStatus) {

            FeatureStatus.AVAILABLE -> {
                progress(
                    requestId,
                    "📱 Gemini Nano ist auf dem Gerät bereit."
                )

                return
            }


            FeatureStatus.DOWNLOADABLE -> {

                progress(
                    requestId,
                    "📱 Gemini Nano muss einmalig auf das Gerät geladen werden…"
                )


                var completed = false
                var failed: Throwable? = null


                withTimeout(
                    DOWNLOAD_TIMEOUT_MS
                ) {

                    generativeModel
                        .download()
                        .collect { status ->

                            when (status) {

                                is DownloadStatus.DownloadStarted -> {
                                    progress(
                                        requestId,
                                        "📱 Download von Gemini Nano startet…"
                                    )
                                }


                                is DownloadStatus.DownloadProgress -> {
                                    val mb =
                                        status.totalBytesDownloaded /
                                        (1024.0 * 1024.0)

                                    progress(
                                        requestId,
                                        "📱 Gemini Nano wird geladen: %.1f MB"
                                            .format(mb)
                                    )
                                }


                                DownloadStatus.DownloadCompleted -> {
                                    completed = true

                                    progress(
                                        requestId,
                                        "📱 Gemini Nano wurde geladen."
                                    )
                                }


                                is DownloadStatus.DownloadFailed -> {
                                    failed = status.e
                                }
                            }
                        }
                }


                failed?.let {
                    throw it
                }


                if (!completed) {
                    throw IllegalStateException(
                        "Der Gemini-Nano-Download wurde nicht abgeschlossen."
                    )
                }


                val afterDownload =
                    withTimeout(
                        STATUS_TIMEOUT_MS
                    ) {
                        generativeModel.checkStatus()
                    }


                if (
                    afterDownload !=
                    FeatureStatus.AVAILABLE
                ) {
                    throw IllegalStateException(
                        "Gemini Nano wurde geladen, ist aber noch nicht verfügbar."
                    )
                }


                progress(
                    requestId,
                    "📱 Gemini Nano ist bereit."
                )
            }


            FeatureStatus.DOWNLOADING -> {

                progress(
                    requestId,
                    "📱 Gemini Nano wird bereits von Android/AICore geladen…"
                )


                withTimeout(
                    DOWNLOAD_TIMEOUT_MS
                ) {

                    while (true) {

                        delay(
                            STATUS_POLL_MS
                        )


                        val status =
                            withTimeout(
                                STATUS_TIMEOUT_MS
                            ) {
                                generativeModel.checkStatus()
                            }


                        when (status) {

                            FeatureStatus.AVAILABLE -> {
                                progress(
                                    requestId,
                                    "📱 Gemini Nano ist bereit."
                                )

                                return@withTimeout
                            }


                            FeatureStatus.UNAVAILABLE -> {
                                throw IllegalStateException(
                                    "Gemini Nano wurde während der Bereitstellung als nicht verfügbar gemeldet."
                                )
                            }


                            FeatureStatus.DOWNLOADING -> {
                                progress(
                                    requestId,
                                    "📱 AICore lädt Gemini Nano weiter…"
                                )
                            }


                            FeatureStatus.DOWNLOADABLE -> {
                                progress(
                                    requestId,
                                    "📱 Gemini Nano wartet noch auf die Bereitstellung…"
                                )
                            }


                            else -> {
                                progress(
                                    requestId,
                                    "📱 Geräte-KI wird weiter vorbereitet…"
                                )
                            }
                        }
                    }
                }


                val finalStatus =
                    withTimeout(
                        STATUS_TIMEOUT_MS
                    ) {
                        generativeModel.checkStatus()
                    }


                if (
                    finalStatus !=
                    FeatureStatus.AVAILABLE
                ) {
                    throw IllegalStateException(
                        "Gemini Nano ist nach dem Download noch nicht verfügbar."
                    )
                }
            }


            FeatureStatus.UNAVAILABLE -> {
                throw IllegalStateException(
                    "Gemini Nano/AICore ist auf diesem Gerät derzeit nicht verfügbar. " +
                    "AICore aktualisieren, Internetverbindung prüfen und das Gerät einmal neu starten."
                )
            }


            else -> {
                throw IllegalStateException(
                    "Unbekannter Status der lokalen Geräte-KI: $firstStatus"
                )
            }
        }
    }


    private fun collectVisualPages(
        pages: JSONArray,
        out: MutableList<Bitmap>
    ) {
        for (i in 0 until pages.length()) {
            if (out.size >= MAX_VISUALS) break

            val page = pages.optJSONObject(i) ?: continue
            val mime = page.optString("mimeType").lowercase()
            val name = page.optString("name").lowercase()
            val b64 = page.optString("base64")

            if (b64.isBlank()) continue

            val bytes = Base64.decode(b64, Base64.DEFAULT)

            when {
                mime.startsWith("image/") ||
                    name.endsWith(".jpg") ||
                    name.endsWith(".jpeg") ||
                    name.endsWith(".png") ||
                    name.endsWith(".webp") -> {
                    decodeSampledBitmap(bytes)?.let(out::add)
                }

                mime == "application/pdf" ||
                    name.endsWith(".pdf") -> {
                    out.addAll(
                        renderPdf(bytes, MAX_VISUALS - out.size)
                    )
                }
            }
        }
    }

    private fun decodeSampledBitmap(
        bytes: ByteArray,
        maxDimension: Int = MAX_IMAGE_DIMENSION
    ): Bitmap? {
        val bounds = BitmapFactory.Options().apply {
            inJustDecodeBounds = true
        }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)

        var sample = 1
        val width = bounds.outWidth
        val height = bounds.outHeight

        while (
            width / sample > maxDimension ||
            height / sample > maxDimension
        ) {
            sample *= 2
        }

        val options = BitmapFactory.Options().apply {
            inSampleSize = max(1, sample)
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }

        return BitmapFactory.decodeByteArray(
            bytes,
            0,
            bytes.size,
            options
        )
    }

    private fun renderPdf(
        bytes: ByteArray,
        maxPages: Int
    ): List<Bitmap> {
        if (maxPages <= 0) return emptyList()

        val dir = File(context.cacheDir, "local_ai_pdf").apply {
            mkdirs()
        }

        val file = File.createTempFile(
            "fa_ai_",
            ".pdf",
            dir
        )

        file.writeBytes(bytes)

        val bitmaps = mutableListOf<Bitmap>()

        try {
            ParcelFileDescriptor.open(
                file,
                ParcelFileDescriptor.MODE_READ_ONLY
            ).use { descriptor ->
                PdfRenderer(descriptor).use { renderer ->
                    val count = minOf(
                        renderer.pageCount,
                        maxPages
                    )

                    for (i in 0 until count) {
                        renderer.openPage(i).use { page ->
                            val scale = minOf(
                                1.8f,
                                MAX_IMAGE_DIMENSION.toFloat() /
                                    max(page.width, page.height).toFloat()
                            )

                            val width = max(
                                1,
                                (page.width * scale).roundToInt()
                            )
                            val height = max(
                                1,
                                (page.height * scale).roundToInt()
                            )

                            val bitmap = Bitmap.createBitmap(
                                width,
                                height,
                                Bitmap.Config.ARGB_8888
                            )

                            bitmap.eraseColor(android.graphics.Color.WHITE)

                            page.render(
                                bitmap,
                                null,
                                null,
                                PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY
                            )

                            bitmaps.add(bitmap)
                        }
                    }
                }
            }
        } finally {
            runCatching { file.delete() }
        }

        return bitmaps
    }

    private fun progress(
        requestId: String,
        message: String
    ) {
        val json = JSONObject()
            .put("message", message)
            .toString()

        setNativeState(
            requestId,
            "progress",
            json
        )

        dispatchToWeb(
            "progress",
            requestId,
            json
        )
    }

    private fun result(
        requestId: String,
        payload: JSONObject
    ) {
        val json =
            payload.toString()

        setNativeState(
            requestId,
            "result",
            json
        )

        dispatchToWeb(
            "result",
            requestId,
            json
        )
    }

    private fun setNativeState(
        requestId: String,
        type: String,
        payloadJson: String
    ) {
        nativeStates[requestId] =
            JSONObject()
                .put(
                    "type",
                    type
                )
                .put(
                    "payloadJson",
                    payloadJson
                )
                .toString()
    }


    private fun dispatchToWeb(
        type: String,
        requestId: String,
        payloadJson: String
    ) {
        val callbackName =
            if (type == "progress") {
                "faNativeAiProgress"
            } else {
                "faNativeAiResult"
            }

        val script =
            """
            (function(){
              var requestId=${JSONObject.quote(requestId)};
              var payloadJson=${JSONObject.quote(payloadJson)};
              var message={
                source:"fa-native-ai-response",
                type:${JSONObject.quote(type)},
                requestId:requestId,
                payloadJson:payloadJson
              };

              try {
                if (
                  typeof window[${JSONObject.quote(callbackName)}] === "function"
                ) {
                  window[${JSONObject.quote(callbackName)}](
                    requestId,
                    payloadJson
                  );
                }
              } catch(e) {}

              try {
                window.postMessage(
                  message,
                  "*"
                );
              } catch(e) {}

              try {
                for (
                  var i = 0;
                  i < window.frames.length;
                  i++
                ) {
                  window.frames[i].postMessage(
                    message,
                    "*"
                  );
                }
              } catch(e) {}
            })();
            """.trimIndent()

        evaluate(script)
    }


    private fun evaluate(script: String) {
        webView.post {
            runCatching {
                webView.evaluateJavascript(script, null)
            }
        }
    }

    private companion object {
        const val MAX_VISUALS = 4
        const val MAX_IMAGE_DIMENSION = 1600

        const val STATUS_TIMEOUT_MS =
            30000L

        const val STATUS_POLL_MS =
            2000L

        const val DOWNLOAD_TIMEOUT_MS =
            600000L

        const val INFERENCE_TIMEOUT_MS =
            180000L

        const val OCR_TIMEOUT_MS =
            45000L

        const val OCR_MAX_IMAGE_DIMENSION =
            2800
    }
}
