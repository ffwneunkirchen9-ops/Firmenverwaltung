# FA Fertigung FIX45C

Gezielte Reparatur des Absturzes beim Start der nativen Watch-Oberfläche.

Der Fehler lag nicht am Layout, sondern am zu frühen Zugriff auf den
WindowInsetsController während `onCreate()`.

FIX45C verschiebt die Fullscreen-Konfiguration auf den Zeitpunkt nach
`setContentView()`, wenn die View tatsächlich am Fenster hängt.

Nur die Watch-App neu bauen und installieren. `script.html`, `Code.gs`
und die Handy-App müssen nicht geändert werden.
