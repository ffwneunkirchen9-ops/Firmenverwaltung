package de.fa.fertigung.wear

import android.content.Context
import com.google.android.gms.wearable.DataMapItem
import com.google.android.gms.wearable.PutDataMapRequest
import com.google.android.gms.wearable.Wearable
import org.json.JSONObject
import java.util.UUID

object WatchDataSync {

    const val CONTEXT_PATH =
        "/fa/watch/context"

    const val ACK_PATH =
        "/fa/watch/ack"

    const val EVENT_PREFIX =
        "/fa/watch/event/"

    const val EVENT_MESSAGE_PATH =
        "/fa/watch/action"


    /**
     * FIX47:
     * Holt den zuletzt vom Handy veröffentlichten FA-Kontext direkt aus
     * dem Wear-Data-Layer. Das ist wichtig, wenn ein Kontext-Update wegen
     * eines noch nicht bestätigten Watch-Events zunächst ignoriert wurde.
     *
     * Es wird nur übernommen, wenn keine lokalen Watch-Ereignisse mehr auf
     * Bestätigung warten. So kann ein noch nicht verarbeitetes +10/-10 nicht
     * von einem älteren Handy-Stand überschrieben werden.
     */
    fun refreshContextFromDataLayer(
        context: Context,
        onUpdated: (() -> Unit)? = null
    ) {

        Wearable
            .getDataClient(
                context
            )
            .dataItems
            .addOnSuccessListener {
                buffer ->

                var newestJson: String? =
                    null

                var newestUpdatedAt =
                    Long.MIN_VALUE

                try {

                    for (
                        index in
                        0 until buffer.count
                    ) {

                        val item =
                            buffer.get(
                                index
                            )

                        if (
                            item.uri.path
                                .orEmpty() !=
                            CONTEXT_PATH
                        ) {
                            continue
                        }

                        val map =
                            runCatching {
                                DataMapItem
                                    .fromDataItem(
                                        item
                                    )
                                    .dataMap
                            }.getOrNull()
                                ?: continue

                        val json =
                            map.getString(
                                "json"
                            )
                                .orEmpty()

                        if (
                            json.isBlank()
                        ) {
                            continue
                        }

                        val updatedAt =
                            map.getLong(
                                "updatedAt",
                                0L
                            )

                        if (
                            newestJson == null ||
                            updatedAt >=
                            newestUpdatedAt
                        ) {

                            newestJson =
                                json

                            newestUpdatedAt =
                                updatedAt
                        }
                    }

                } finally {

                    buffer.release()
                }


                val json =
                    newestJson


                if (
                    json != null &&
                    WatchStateStore
                        .pendingCount(
                            context
                        ) == 0
                ) {

                    WatchStateStore
                        .saveContext(
                            context,
                            json
                        )
                }


                onUpdated
                    ?.invoke()
            }
            .addOnFailureListener {

                onUpdated
                    ?.invoke()
            }
    }


    fun sendEvent(
        context: Context,
        type: String,
        positionIndex: Int
    ): Boolean {

        val current =
            WatchStateStore
                .selectedFa(
                    context
                )
                ?: return false

        if (
            !current.optBoolean(
                "active",
                true
            )
        ) {
            return false
        }

        val faId =
            current.optString(
                "faId"
            )
                .trim()

        if (
            faId.isEmpty()
        ) {
            return false
        }

        val eventId =
            UUID.randomUUID()
                .toString()

        val timestamp =
            System.currentTimeMillis()

        val eventJson =
            JSONObject()
                .put(
                    "eventId",
                    eventId
                )
                .put(
                    "type",
                    type
                )
                .put(
                    "faId",
                    faId
                )
                .put(
                    "faNo",
                    current.optString(
                        "faNo"
                    )
                )
                .put(
                    "date",
                    WatchStateStore.currentDateString()
                )
                .put(
                    "positionIndex",
                    positionIndex
                )
                .put(
                    "timestamp",
                    timestamp
                )

        Wearable
            .getNodeClient(
                context
            )
            .connectedNodes
            .addOnSuccessListener {
                nodes ->

                val payload =
                    eventJson
                        .toString()
                        .toByteArray(
                            Charsets.UTF_8
                        )

                nodes.forEach {
                    node ->

                    Wearable
                        .getMessageClient(
                            context
                        )
                        .sendMessage(
                            node.id,
                            EVENT_MESSAGE_PATH,
                            payload
                        )
                }
            }

        val request =
            PutDataMapRequest
                .create(
                    EVENT_PREFIX +
                    eventId
                )
                .apply {

                    dataMap.putString(
                        "eventId",
                        eventId
                    )

                    dataMap.putString(
                        "type",
                        type
                    )

                    dataMap.putString(
                        "faId",
                        faId
                    )

                    dataMap.putString(
                        "faNo",
                        current.optString(
                            "faNo"
                        )
                    )

                    dataMap.putString(
                        "date",
                        WatchStateStore.currentDateString()
                    )

                    dataMap.putInt(
                        "positionIndex",
                        positionIndex
                    )

                    dataMap.putLong(
                        "timestamp",
                        timestamp
                    )
                }
                .asPutDataRequest()
                .setUrgent()

        WatchStateStore.addPending(
            context,
            eventId,
            type
        )

        Wearable
            .getDataClient(
                context
            )
            .putDataItem(
                request
            )

        return true
    }
}
