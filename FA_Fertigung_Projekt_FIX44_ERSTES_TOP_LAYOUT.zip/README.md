# FA Fertigung FIX44

FIX44 setzt die Wear-Kachel wieder auf das bestätigte erste Top-Layout zurück.

Schneiden und Entgraten verwenden dieselben Proportionen. Beim Entgraten arbeitet die Tagesmenge intern in 10er-Schritten. Ausschuss bleibt in 1er-Schritten. Der Timer bleibt unten.

Für FIX44 die Watch-App neu bauen/installieren und das mitgelieferte script.html übernehmen. Code.gs und die Handy-App bleiben unverändert.
