package de.fa.fertigung.wear

import android.content.Context
import androidx.wear.protolayout.DimensionBuilders.dp
import androidx.wear.protolayout.DimensionBuilders.expand
import androidx.wear.protolayout.DimensionBuilders.weight
import androidx.wear.protolayout.ProtoLayoutScope
import androidx.wear.protolayout.TimelineBuilders.Timeline
import androidx.wear.protolayout.layout.column
import androidx.wear.protolayout.material3.ButtonDefaults.filledButtonColors
import androidx.wear.protolayout.material3.ButtonDefaults.filledTonalButtonColors
import androidx.wear.protolayout.material3.CardDefaults.filledVariantCardColors
import androidx.wear.protolayout.material3.Typography.BODY_SMALL
import androidx.wear.protolayout.material3.Typography.NUMERAL_SMALL
import androidx.wear.protolayout.material3.buttonGroup
import androidx.wear.protolayout.material3.materialScopeWithResources
import androidx.wear.protolayout.material3.primaryLayout
import androidx.wear.protolayout.material3.text
import androidx.wear.protolayout.material3.textButton
import androidx.wear.protolayout.material3.textDataCard
import androidx.wear.protolayout.modifiers.clickable
import androidx.wear.protolayout.modifiers.loadAction
import androidx.wear.protolayout.types.layoutString
import androidx.wear.tiles.RequestBuilders
import androidx.wear.tiles.TileService
import androidx.wear.tiles.tile
import com.google.common.util.concurrent.Futures
import org.json.JSONObject

class FaCounterTileService : TileService() {

    override fun onTileRequest(requestParams: RequestBuilders.TileRequest) =
        Futures.immediateFuture(
            run {
                val action = when (requestParams.currentState.lastClickableId) {
                    CLICK_PLATE_MINUS -> TileActionReceiver.ACTION_PLATE_MINUS
                    CLICK_PLATE_PLUS -> TileActionReceiver.ACTION_PLATE_PLUS
                    CLICK_SCRAP_MINUS -> TileActionReceiver.ACTION_SCRAP_MINUS
                    CLICK_SCRAP_PLUS -> TileActionReceiver.ACTION_SCRAP_PLUS
                    CLICK_QUANTITY_MINUS_10 -> TileActionReceiver.ACTION_QUANTITY_MINUS_10
                    CLICK_QUANTITY_PLUS_10 -> TileActionReceiver.ACTION_QUANTITY_PLUS_10
                    CLICK_TIMER_TOGGLE -> TileActionReceiver.ACTION_TIMER_TOGGLE
                    CLICK_TIMER_STOP -> TileActionReceiver.ACTION_TIMER_STOP
                    CLICK_NEXT_FA -> TileActionReceiver.ACTION_NEXT_FA
                    CLICK_NEXT_POSITION -> TileActionReceiver.ACTION_NEXT_POSITION
                    CLICK_DISPLAY -> TileActionReceiver.ACTION_NOOP
                    else -> null
                }

                if (action != null) {
                    TileActionReceiver.handleAction(this, action, false)
                }

                tile(
                    Timeline.fromLayoutElement(
                        buildTileLayout(
                            this,
                            requestParams.scope,
                            requestParams.deviceConfiguration
                        )
                    )
                )
            }
        )

    private fun buildTileLayout(
        context: Context,
        scope: ProtoLayoutScope,
        deviceParameters: androidx.wear.protolayout.DeviceParametersBuilders.DeviceParameters
    ) = materialScopeWithResources(context, scope, deviceParameters) {

        val fa = WatchStateStore.selectedFa(context)

        if (fa == null) {
            return@materialScopeWithResources primaryLayout(
                titleSlot = { text("FA Fertigung".layoutString) },
                mainSlot = {
                    text("Am Handy einen FA öffnen.".layoutString, typography = BODY_SMALL)
                }
            )
        }

        val positions = fa.optJSONArray("positions")
        val positionCount = positions?.length() ?: 0
        val selected = WatchStateStore.selectedPosition(context, positionCount)
        val selectedPosition = positions?.optJSONObject(selected) ?: JSONObject()

        val faNo = fa.optString("faNo", "?")
        val op = fa.optString("op", "")
        val plates = fa.optInt("plates", 0)
        val scrap = selectedPosition.optInt("scrap", 0)
        val quantityToday = selectedPosition.optInt("quantity", 0)
        val pending = WatchStateStore.pendingCount(context)
        val timerState = fa.optString("timerState", "stopped")
        val timerMinutes = currentTimerMinutes(fa)
        val runningCount = countRunningTimers(context)

        val plateMinusClick = clickable(id = CLICK_PLATE_MINUS, action = loadAction())
        val platePlusClick = clickable(id = CLICK_PLATE_PLUS, action = loadAction())
        val scrapMinusClick = clickable(id = CLICK_SCRAP_MINUS, action = loadAction())
        val scrapPlusClick = clickable(id = CLICK_SCRAP_PLUS, action = loadAction())
        val quantityMinusTenClick = clickable(id = CLICK_QUANTITY_MINUS_10, action = loadAction())
        val quantityPlusTenClick = clickable(id = CLICK_QUANTITY_PLUS_10, action = loadAction())
        val timerToggleClick = clickable(id = CLICK_TIMER_TOGGLE, action = loadAction())
        val timerStopClick = clickable(id = CLICK_TIMER_STOP, action = loadAction())
        val nextFaClick = clickable(id = CLICK_NEXT_FA, action = loadAction())
        val nextPositionClick = clickable(id = CLICK_NEXT_POSITION, action = loadAction())
        val displayClick = clickable(id = CLICK_DISPLAY, action = loadAction())
        val positionClick = if (positionCount > 1) nextPositionClick else displayClick

        val opLabel = if (op.isNotBlank()) op else "Arbeitsgang"

        primaryLayout(
            mainSlot = {
                if (op == "Schneiden") {
                    column(
                        faSwitchRow(
                            faLabel = "FA $faNo",
                            displayClick = displayClick,
                            nextFaClick = nextFaClick
                        ),
                        operationLabelRow(
                            opLabel = opLabel,
                            displayClick = displayClick
                        ),
                        valueRow(
                            label = "Platten",
                            value = plates,
                            minusLabel = "-",
                            plusLabel = "+",
                            minusClick = plateMinusClick,
                            plusClick = platePlusClick,
                            centerClick = displayClick,
                            rowHeight = 44f
                        ),
                        valueRow(
                            label = if (positionCount > 1) "Aussch. P${selected + 1}/$positionCount" else "Ausschuss",
                            value = scrap,
                            minusLabel = "-",
                            plusLabel = "+",
                            minusClick = scrapMinusClick,
                            plusClick = scrapPlusClick,
                            centerClick = positionClick,
                            rowHeight = 44f
                        ),
                        timerRow(
                            timerState = timerState,
                            timerMinutes = timerMinutes,
                            timerToggleClick = timerToggleClick,
                            timerStopClick = timerStopClick
                        ),
                        width = expand(),
                        height = expand()
                    )
                } else {
                    column(
                        faSwitchRow(
                            faLabel = "FA $faNo",
                            displayClick = displayClick,
                            nextFaClick = nextFaClick
                        ),
                        operationLabelRow(
                            opLabel = opLabel,
                            displayClick = displayClick
                        ),
                        valueRow(
                            label = "Tagesmenge",
                            value = quantityToday,
                            minusLabel = "-",
                            plusLabel = "+",
                            minusClick = quantityMinusTenClick,
                            plusClick = quantityPlusTenClick,
                            centerClick = positionClick,
                            rowHeight = 44f
                        ),
                        valueRow(
                            label = if (positionCount > 1) "Aussch. P${selected + 1}/$positionCount" else "Ausschuss",
                            value = scrap,
                            minusLabel = "-",
                            plusLabel = "+",
                            minusClick = scrapMinusClick,
                            plusClick = scrapPlusClick,
                            centerClick = positionClick,
                            rowHeight = 44f
                        ),
                        timerRow(
                            timerState = timerState,
                            timerMinutes = timerMinutes,
                            timerToggleClick = timerToggleClick,
                            timerStopClick = timerStopClick
                        ),
                        width = expand(),
                        height = expand()
                    )
                }
            }
        )
    }

    private fun androidx.wear.protolayout.material3.MaterialScope.faSwitchRow(
        faLabel: String,
        displayClick: androidx.wear.protolayout.ModifiersBuilders.Clickable,
        nextFaClick: androidx.wear.protolayout.ModifiersBuilders.Clickable
    ) = buttonGroup(height = dp(34f)) {
        buttonGroupItem {
            textButton(
                width = weight(3f),
                height = expand(),
                onClick = displayClick,
                colors = filledTonalButtonColors(),
                labelContent = {
                    text(faLabel.layoutString, typography = NUMERAL_SMALL)
                }
            )
        }
        buttonGroupItem {
            textButton(
                width = weight(1f),
                height = expand(),
                onClick = nextFaClick,
                colors = filledTonalButtonColors(),
                labelContent = {
                    text("↔".layoutString, typography = NUMERAL_SMALL)
                }
            )
        }
    }

    private fun androidx.wear.protolayout.material3.MaterialScope.operationLabelRow(
        opLabel: String,
        displayClick: androidx.wear.protolayout.ModifiersBuilders.Clickable
    ) = buttonGroup(height = dp(26f)) {
        buttonGroupItem {
            textButton(
                width = weight(1f),
                height = expand(),
                onClick = displayClick,
                colors = filledTonalButtonColors(),
                labelContent = {
                    text(opLabel.layoutString, typography = BODY_SMALL)
                }
            )
        }
    }

    private fun androidx.wear.protolayout.material3.MaterialScope.valueRow(
        label: String,
        value: Int,
        minusLabel: String,
        plusLabel: String,
        minusClick: androidx.wear.protolayout.ModifiersBuilders.Clickable,
        plusClick: androidx.wear.protolayout.ModifiersBuilders.Clickable,
        centerClick: androidx.wear.protolayout.ModifiersBuilders.Clickable,
        rowHeight: Float
    ) = buttonGroup(height = dp(rowHeight)) {
        buttonGroupItem {
            textButton(
                width = weight(1f),
                height = expand(),
                onClick = minusClick,
                colors = filledTonalButtonColors(),
                labelContent = {
                    text(minusLabel.layoutString, typography = NUMERAL_SMALL)
                }
            )
        }
        buttonGroupItem {
            textDataCard(
                onClick = centerClick,
                width = weight(2f),
                height = expand(),
                colors = filledVariantCardColors(),
                title = {
                    text(value.toString().layoutString, typography = NUMERAL_SMALL)
                },
                content = {
                    text(label.layoutString, typography = BODY_SMALL)
                }
            )
        }
        buttonGroupItem {
            textButton(
                width = weight(1f),
                height = expand(),
                onClick = plusClick,
                colors = filledButtonColors(),
                labelContent = {
                    text(plusLabel.layoutString, typography = NUMERAL_SMALL)
                }
            )
        }
    }

    private fun androidx.wear.protolayout.material3.MaterialScope.timerRow(
        timerState: String,
        timerMinutes: Int,
        timerToggleClick: androidx.wear.protolayout.ModifiersBuilders.Clickable,
        timerStopClick: androidx.wear.protolayout.ModifiersBuilders.Clickable
    ) = buttonGroup(height = dp(34f)) {
        buttonGroupItem {
            textButton(
                width = weight(if (timerState == "stopped") 3f else 2f),
                height = expand(),
                onClick = timerToggleClick,
                colors = filledButtonColors(),
                labelContent = {
                    text(
                        timerToggleLabel(timerState, timerMinutes).layoutString,
                        typography = BODY_SMALL
                    )
                }
            )
        }
        if (timerState != "stopped") {
            buttonGroupItem {
                textButton(
                    width = weight(1f),
                    height = expand(),
                    onClick = timerStopClick,
                    colors = filledTonalButtonColors(),
                    labelContent = { text("■".layoutString, typography = BODY_SMALL) }
                )
            }
        }
    }

    private fun currentTimerMinutes(fa: JSONObject): Int {
        var minutes = fa.optInt("timerClosedMinutes", 0).coerceAtLeast(0)
        if (fa.optString("timerState", "stopped") == "running") {
            val since = fa.optLong("runningSince", 0L)
            if (since > 0L) {
                minutes += ((System.currentTimeMillis() - since).coerceAtLeast(0L) / 60000L).toInt()
            }
        }
        return minutes
    }

    private fun timerToggleLabel(state: String, minutes: Int): String {
        val time = formatTimer(minutes)
        return when (state) {
            "running" -> "⏸ $time"
            "paused" -> "▶ $time"
            else -> "▶ Start"
        }
    }

    private fun formatTimer(minutes: Int): String {
        val safe = minutes.coerceAtLeast(0)
        val hours = safe / 60
        val rest = safe % 60
        return if (hours > 0) "$hours:${rest.toString().padStart(2, '0')}" else "${rest}m"
    }

    private fun countRunningTimers(context: Context): Int {
        val root = runCatching { JSONObject(WatchStateStore.contextJson(context)) }
            .getOrElse { JSONObject() }
        val fas = root.optJSONArray("fas")
        if (fas == null) {
            return if (root.optString("timerState", "stopped") == "running") 1 else 0
        }
        var count = 0
        for (index in 0 until fas.length()) {
            if (fas.optJSONObject(index)?.optString("timerState", "stopped") == "running") count++
        }
        return count
    }

    companion object {
        private const val CLICK_PLATE_MINUS = "plate_minus"
        private const val CLICK_PLATE_PLUS = "plate_plus"
        private const val CLICK_SCRAP_MINUS = "scrap_minus"
        private const val CLICK_SCRAP_PLUS = "scrap_plus"
        private const val CLICK_QUANTITY_MINUS_10 = "quantity_minus_10"
        private const val CLICK_QUANTITY_PLUS_10 = "quantity_plus_10"
        private const val CLICK_TIMER_TOGGLE = "timer_toggle"
        private const val CLICK_TIMER_STOP = "timer_stop"
        private const val CLICK_NEXT_FA = "next_fa"
        private const val CLICK_NEXT_POSITION = "next_position"
        private const val CLICK_DISPLAY = "display"
    }
}
