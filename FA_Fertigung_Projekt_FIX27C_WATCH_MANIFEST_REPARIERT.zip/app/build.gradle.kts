import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "de.fa.fertigung"
    compileSdk = 36

    defaultConfig {
        applicationId = "de.fa.fertigung"
        minSdk = 26
        targetSdk = 35

        val githubRunNumber =
            System.getenv("GITHUB_RUN_NUMBER")
                ?.toIntOrNull()
                ?: 0

        versionCode =
            27200 + githubRunNumber

        versionName =
            "1.27.2." + githubRunNumber
    }

    signingConfigs {
        create("release") {
            val keystorePath =
                System.getenv("FA_KEYSTORE_PATH")
                    ?: error("FA_KEYSTORE_PATH fehlt")

            val storePasswordValue =
                System.getenv("FA_KEYSTORE_PASSWORD")
                    ?: error("FA_KEYSTORE_PASSWORD fehlt")

            val keyAliasValue =
                System.getenv("FA_KEY_ALIAS")
                    ?: error("FA_KEY_ALIAS fehlt")

            val keyPasswordValue =
                System.getenv("FA_KEY_PASSWORD")
                    ?: error("FA_KEY_PASSWORD fehlt")

            storeFile =
                file(keystorePath)

            storePassword =
                storePasswordValue

            keyAlias =
                keyAliasValue

            keyPassword =
                keyPasswordValue
        }
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            signingConfig =
                signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("com.google.mlkit:genai-prompt:1.0.0-beta4")
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.9.0")
    implementation("com.google.android.gms:play-services-wearable:20.0.1")
}
