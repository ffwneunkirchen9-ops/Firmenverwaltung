# FA Fertigung FIX43

Freigegebenes frühes, übersichtliches Layout mit Timer.

- Schneiden: Platten, Ausschuss, Timer
- Entgraten: Tagesmenge in 10er-Schritten, Ausschuss in 1er-Schritten, Timer
- FA-Wechsel über sichtbares ↔ Symbol

Für FIX43 die Watch-App neu bauen/installieren und das mitgelieferte script.html verwenden.
Code.gs und die Handy-App bleiben unverändert.
