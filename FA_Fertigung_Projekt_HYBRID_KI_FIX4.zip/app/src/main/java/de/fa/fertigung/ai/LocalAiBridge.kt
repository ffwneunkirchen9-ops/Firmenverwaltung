package de.fa.fertigung.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfRenderer
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import com.google.mlkit.genai.common.DownloadStatus
import com.google.mlkit.genai.common.FeatureStatus
import com.google.mlkit.genai.prompt.Content
import com.google.mlkit.genai.prompt.Generation
import com.google.mlkit.genai.prompt.ImagePart
import com.google.mlkit.genai.prompt.TextPart
import com.google.mlkit.genai.prompt.generateContentRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.max
import kotlin.math.roundToInt

class LocalAiBridge(
    private val context: Context,
    private val webView: WebView
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val generativeModel by lazy { Generation.getClient() }

    @JavascriptInterface
    fun status(): String {
        return JSONObject()
            .put("bridge", true)
            .put("platform", "android")
            .put("device", "${Build.MANUFACTURER} ${Build.MODEL}")
            .put("version", "1.0.0")
            .toString()
    }

    @JavascriptInterface
    fun analyze(requestId: String, payloadJson: String) {
        val safeId = requestId.trim()
        if (safeId.isEmpty()) return

        scope.launch {
            val visuals = mutableListOf<Bitmap>()

            try {
                progress(safeId, "📱 Geräte-KI wird vorbereitet…")
                ensureModelReady(safeId)

                val payload = JSONObject(payloadJson)
                val prompt = payload.optString("prompt").trim()

                if (prompt.isEmpty()) {
                    throw IllegalArgumentException("Lokaler KI-Prompt fehlt.")
                }

                val pages = payload.optJSONArray("pages") ?: JSONArray()

                withContext(Dispatchers.IO) {
                    collectVisualPages(pages, visuals)
                }

                progress(
                    safeId,
                    if (visuals.isNotEmpty()) {
                        "📱 Dokument wird lokal mit Gemini Nano gelesen…"
                    } else {
                        "📱 Text wird lokal mit Gemini Nano ausgewertet…"
                    }
                )

                val contentBuilder = Content.builder()
                contentBuilder.addPart(TextPart(prompt))
                visuals.take(MAX_VISUALS).forEach { bitmap ->
                    contentBuilder.addPart(ImagePart(bitmap))
                }

                val request = generateContentRequest(contentBuilder.build()) {
                    temperature = 0.1f
                    candidateCount = 1
                    maxOutputTokens = 3000
                }

                val response = generativeModel.generateContent(request)
                val text = response.candidates.firstOrNull()?.text.orEmpty().trim()

                if (text.isEmpty()) {
                    throw IllegalStateException("Gemini Nano hat keine Antwort geliefert.")
                }

                result(
                    safeId,
                    JSONObject()
                        .put("ok", true)
                        .put("text", text)
                        .put(
                            "provider",
                            "Galaxy ${Build.MODEL} · Gemini Nano"
                        )
                )
            } catch (t: Throwable) {
                result(
                    safeId,
                    JSONObject()
                        .put("ok", false)
                        .put(
                            "error",
                            t.message ?: t.javaClass.simpleName
                        )
                )
            } finally {
                visuals.forEach { bitmap ->
                    runCatching {
                        if (!bitmap.isRecycled) bitmap.recycle()
                    }
                }
            }
        }
    }

    fun close() {
        runCatching { generativeModel.close() }
        scope.cancel()
    }

    private suspend fun ensureModelReady(requestId: String) {
        when (generativeModel.checkStatus()) {
            FeatureStatus.AVAILABLE -> return

            FeatureStatus.DOWNLOADABLE,
            FeatureStatus.DOWNLOADING -> {
                progress(
                    requestId,
                    "📱 Gemini Nano wird auf dem Gerät bereitgestellt…"
                )

                var completed = false
                var failed: Throwable? = null

                generativeModel.download().collect { status ->
                    when (status) {
                        is DownloadStatus.DownloadStarted -> {
                            progress(
                                requestId,
                                "📱 Download von Gemini Nano startet…"
                            )
                        }

                        is DownloadStatus.DownloadProgress -> {
                            val mb = status.totalBytesDownloaded / (1024.0 * 1024.0)
                            progress(
                                requestId,
                                "📱 Gemini Nano wird geladen: %.1f MB".format(mb)
                            )
                        }

                        DownloadStatus.DownloadCompleted -> {
                            completed = true
                            progress(
                                requestId,
                                "📱 Gemini Nano ist bereit."
                            )
                        }

                        is DownloadStatus.DownloadFailed -> {
                            failed = status.e
                        }
                    }
                }

                failed?.let { throw it }

                if (!completed && generativeModel.checkStatus() != FeatureStatus.AVAILABLE) {
                    throw IllegalStateException(
                        "Gemini Nano konnte nicht bereitgestellt werden."
                    )
                }
            }

            else -> {
                throw IllegalStateException(
                    "Gemini Nano wird auf diesem Gerät derzeit nicht unterstützt."
                )
            }
        }
    }

    private fun collectVisualPages(
        pages: JSONArray,
        out: MutableList<Bitmap>
    ) {
        for (i in 0 until pages.length()) {
            if (out.size >= MAX_VISUALS) break

            val page = pages.optJSONObject(i) ?: continue
            val mime = page.optString("mimeType").lowercase()
            val name = page.optString("name").lowercase()
            val b64 = page.optString("base64")

            if (b64.isBlank()) continue

            val bytes = Base64.decode(b64, Base64.DEFAULT)

            when {
                mime.startsWith("image/") ||
                    name.endsWith(".jpg") ||
                    name.endsWith(".jpeg") ||
                    name.endsWith(".png") ||
                    name.endsWith(".webp") -> {
                    decodeSampledBitmap(bytes)?.let(out::add)
                }

                mime == "application/pdf" ||
                    name.endsWith(".pdf") -> {
                    out.addAll(
                        renderPdf(bytes, MAX_VISUALS - out.size)
                    )
                }
            }
        }
    }

    private fun decodeSampledBitmap(bytes: ByteArray): Bitmap? {
        val bounds = BitmapFactory.Options().apply {
            inJustDecodeBounds = true
        }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)

        var sample = 1
        var width = bounds.outWidth
        var height = bounds.outHeight

        while (
            width / sample > MAX_IMAGE_DIMENSION ||
            height / sample > MAX_IMAGE_DIMENSION
        ) {
            sample *= 2
        }

        val options = BitmapFactory.Options().apply {
            inSampleSize = max(1, sample)
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }

        return BitmapFactory.decodeByteArray(
            bytes,
            0,
            bytes.size,
            options
        )
    }

    private fun renderPdf(
        bytes: ByteArray,
        maxPages: Int
    ): List<Bitmap> {
        if (maxPages <= 0) return emptyList()

        val dir = File(context.cacheDir, "local_ai_pdf").apply {
            mkdirs()
        }

        val file = File.createTempFile(
            "fa_ai_",
            ".pdf",
            dir
        )

        file.writeBytes(bytes)

        val bitmaps = mutableListOf<Bitmap>()

        try {
            ParcelFileDescriptor.open(
                file,
                ParcelFileDescriptor.MODE_READ_ONLY
            ).use { descriptor ->
                PdfRenderer(descriptor).use { renderer ->
                    val count = minOf(
                        renderer.pageCount,
                        maxPages
                    )

                    for (i in 0 until count) {
                        renderer.openPage(i).use { page ->
                            val scale = minOf(
                                1.8f,
                                MAX_IMAGE_DIMENSION.toFloat() /
                                    max(page.width, page.height).toFloat()
                            )

                            val width = max(
                                1,
                                (page.width * scale).roundToInt()
                            )
                            val height = max(
                                1,
                                (page.height * scale).roundToInt()
                            )

                            val bitmap = Bitmap.createBitmap(
                                width,
                                height,
                                Bitmap.Config.ARGB_8888
                            )

                            bitmap.eraseColor(android.graphics.Color.WHITE)

                            page.render(
                                bitmap,
                                null,
                                null,
                                PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY
                            )

                            bitmaps.add(bitmap)
                        }
                    }
                }
            }
        } finally {
            runCatching { file.delete() }
        }

        return bitmaps
    }

    private fun progress(
        requestId: String,
        message: String
    ) {
        val json = JSONObject()
            .put("message", message)
            .toString()

        dispatchToWeb(
            "progress",
            requestId,
            json
        )
    }

    private fun result(
        requestId: String,
        payload: JSONObject
    ) {
        dispatchToWeb(
            "result",
            requestId,
            payload.toString()
        )
    }

    private fun dispatchToWeb(
        type: String,
        requestId: String,
        payloadJson: String
    ) {
        val callbackName =
            if (type == "progress") {
                "faNativeAiProgress"
            } else {
                "faNativeAiResult"
            }

        val script =
            """
            (function(){
              var requestId=${JSONObject.quote(requestId)};
              var payloadJson=${JSONObject.quote(payloadJson)};
              var message={
                source:"fa-native-ai-response",
                type:${JSONObject.quote(type)},
                requestId:requestId,
                payloadJson:payloadJson
              };

              try {
                if (
                  typeof window[${JSONObject.quote(callbackName)}] === "function"
                ) {
                  window[${JSONObject.quote(callbackName)}](
                    requestId,
                    payloadJson
                  );
                }
              } catch(e) {}

              try {
                window.postMessage(
                  message,
                  "*"
                );
              } catch(e) {}

              try {
                for (
                  var i = 0;
                  i < window.frames.length;
                  i++
                ) {
                  window.frames[i].postMessage(
                    message,
                    "*"
                  );
                }
              } catch(e) {}
            })();
            """.trimIndent()

        evaluate(script)
    }


    private fun evaluate(script: String) {
        webView.post {
            runCatching {
                webView.evaluateJavascript(script, null)
            }
        }
    }

    private companion object {
        const val MAX_VISUALS = 4
        const val MAX_IMAGE_DIMENSION = 1600
    }
}
