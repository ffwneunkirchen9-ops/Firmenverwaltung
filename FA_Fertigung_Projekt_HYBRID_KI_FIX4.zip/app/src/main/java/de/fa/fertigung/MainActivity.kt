package de.fa.fertigung

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.provider.MediaStore
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.content.FileProvider
import de.fa.fertigung.ai.LocalAiBridge
import java.io.File

class MainActivity : Activity() {

    private lateinit var webView: WebView
    private var localAiBridge: LocalAiBridge? = null

    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var cameraUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        setContentView(webView)

        val settings: WebSettings = webView.settings

        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.loadsImagesAutomatically = true
        settings.javaScriptCanOpenWindowsAutomatically = true
        settings.setSupportZoom(false)

        localAiBridge = LocalAiBridge(
            this,
            webView
        )

        webView.addJavascriptInterface(
            localAiBridge!!,
            "FaLocalAI"
        )

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                val target = request?.url ?: return false
                val scheme = target.scheme.orEmpty().lowercase()

                if (
                    scheme == "http" ||
                    scheme == "https"
                ) {
                    return false
                }

                return try {
                    startActivity(
                        Intent(
                            Intent.ACTION_VIEW,
                            target
                        )
                    )
                    true
                } catch (_: Exception) {
                    true
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {

                if (filePathCallback == null) {
                    return false
                }

                fileCallback?.onReceiveValue(null)
                fileCallback = filePathCallback

                val captureOnly =
                    fileChooserParams?.isCaptureEnabled == true

                val camera =
                    createCameraIntent()

                try {
                    if (
                        captureOnly &&
                        camera != null
                    ) {
                        cameraUri = camera.second

                        startActivityForResult(
                            camera.first,
                            FILE_CHOOSER_REQUEST
                        )

                        return true
                    }

                    val contentIntent =
                        try {
                            fileChooserParams?.createIntent()
                        } catch (_: Exception) {
                            null
                        } ?: Intent(
                            Intent.ACTION_GET_CONTENT
                        ).apply {
                            type = "*/*"
                            addCategory(
                                Intent.CATEGORY_OPENABLE
                            )
                        }

                    val chooser =
                        Intent.createChooser(
                            contentIntent,
                            "Dokument auswählen"
                        )

                    if (camera != null) {
                        cameraUri = camera.second

                        chooser.putExtra(
                            Intent.EXTRA_INITIAL_INTENTS,
                            arrayOf(
                                camera.first
                            )
                        )
                    }

                    startActivityForResult(
                        chooser,
                        FILE_CHOOSER_REQUEST
                    )

                    return true

                } catch (_: Exception) {
                    fileCallback = null
                    cameraUri = null
                    return false
                }
            }
        }

        webView.loadUrl(
            WEB_APP_URL
        )

        hideNavigationBar()
    }

    private fun hideNavigationBar() {

        if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.R
        ) {

            window.insetsController?.let {
                controller ->

                controller.hide(
                    WindowInsets.Type.navigationBars()
                )

                controller.systemBarsBehavior =
                    WindowInsetsController
                        .BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }

        } else {

            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE

        }
    }


    override fun onResume() {
        super.onResume()

        webView.postDelayed(
            {
                hideNavigationBar()
            },
            250
        )
    }


    override fun onWindowFocusChanged(
        hasFocus: Boolean
    ) {
        super.onWindowFocusChanged(
            hasFocus
        )

        if (hasFocus) {

            webView.postDelayed(
                {
                    hideNavigationBar()
                },
                150
            )

        }
    }


    private fun createCameraIntent(): Pair<Intent, Uri>? {
        return try {
            val dir =
                File(
                    cacheDir,
                    "camera"
                ).apply {
                    mkdirs()
                }

            val file =
                File.createTempFile(
                    "fa_scan_",
                    ".jpg",
                    dir
                )

            val uri =
                FileProvider.getUriForFile(
                    this,
                    "$packageName.fileprovider",
                    file
                )

            val intent =
                Intent(
                    MediaStore.ACTION_IMAGE_CAPTURE
                ).apply {
                    putExtra(
                        MediaStore.EXTRA_OUTPUT,
                        uri
                    )

                    addFlags(
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )

                    addFlags(
                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    )
                }

            intent to uri

        } catch (_: Exception) {
            null
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        super.onActivityResult(
            requestCode,
            resultCode,
            data
        )

        if (
            requestCode != FILE_CHOOSER_REQUEST
        ) {
            return
        }

        val callback =
            fileCallback ?: return

        var result:
            Array<Uri>? = null

        if (
            resultCode == RESULT_OK
        ) {
            result =
                WebChromeClient
                    .FileChooserParams
                    .parseResult(
                        resultCode,
                        data
                    )

            if (
                result.isNullOrEmpty() &&
                cameraUri != null
            ) {
                result =
                    arrayOf(
                        cameraUri!!
                    )
            }
        }

        callback.onReceiveValue(
            result
        )

        fileCallback = null
        cameraUri = null

        webView.postDelayed(
            {
                hideNavigationBar()
            },
            150
        )
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (
            ::webView.isInitialized &&
            webView.canGoBack()
        ) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        fileCallback?.onReceiveValue(null)
        fileCallback = null

        localAiBridge?.close()
        localAiBridge = null

        if (
            ::webView.isInitialized
        ) {
            webView.removeJavascriptInterface(
                "FaLocalAI"
            )

            webView.stopLoading()
            webView.loadUrl(
                "about:blank"
            )

            webView.destroy()
        }

        super.onDestroy()
    }

    companion object {
        private const val FILE_CHOOSER_REQUEST = 200

        private const val WEB_APP_URL =
            "https://script.google.com/macros/s/AKfycbz_RcPQmoz9OmnjVFr3yxE7d2M8EuORi65yYdm4gRena1Vq0Mr_CMEzAFRlosgv6MQ/exec"
    }
}
