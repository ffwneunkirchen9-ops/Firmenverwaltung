# FA Fertigung FIX39

Wear-OS-Kachel nach dem vom Nutzer freigegebenen Layout.

## Geändert
- FA-Nummer groß oben, FA-Wechsel `⇄` rechts.
- Arbeitsgang separat darunter.
- Schneiden: große Zeilen für Platten und Ausschuss, jeweils `−1 / Wert / +1`.
- Entgraten: große Tagesmenge, `−10 / Wert / +10`.
- Großer Timer unten.
- Mehrfach-FA-Timer, Positionen, Sync und Event-ID-Deduplizierung bleiben erhalten.

## Wichtig
FIX39 führt für Entgraten zusätzlich das Event `quantity_minus_10` ein.
Deshalb muss neben der Watch-App auch `script_FA_FIX39_LAYOUT_FREIGEGEBEN_10ER.html` als `script.html` in Apps Script eingesetzt und neu bereitgestellt werden.

`Code.gs` und die Handy-App müssen nicht geändert werden.
