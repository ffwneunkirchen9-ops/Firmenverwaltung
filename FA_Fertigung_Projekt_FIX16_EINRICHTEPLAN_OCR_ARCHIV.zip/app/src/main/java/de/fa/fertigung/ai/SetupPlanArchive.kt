package de.fa.fertigung.ai

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Base64
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.math.min

object SetupPlanArchive {

    fun saveDataUrlAsPdf(
        context: Context,
        customer: String,
        setupNumber: String,
        dataUrl: String
    ): JSONObject {

        val base64 =
            if (
                dataUrl.contains(
                    "base64,"
                )
            ) {
                dataUrl.substringAfter(
                    "base64,"
                )
            } else {
                dataUrl
            }

        val bytes =
            Base64.decode(
                base64,
                Base64.DEFAULT
            )

        val bitmap =
            BitmapFactory
                .decodeByteArray(
                    bytes,
                    0,
                    bytes.size
                )
                ?: throw IllegalArgumentException(
                    "Einrichteplan-Bild konnte nicht gelesen werden."
                )

        return try {
            saveBitmapAsPdf(
                context,
                customer,
                setupNumber,
                bitmap
            )
        } finally {
            runCatching {
                if (
                    !bitmap.isRecycled
                ) {
                    bitmap.recycle()
                }
            }
        }
    }

    fun saveBitmapAsPdf(
        context: Context,
        customer: String,
        setupNumber: String,
        bitmap: Bitmap
    ): JSONObject {

        val cleanCustomer =
            safePathPart(
                customer
            )
                .ifBlank {
                    "Unbekannter Kunde"
                }

        val cleanNumber =
            safePathPart(
                setupNumber
            )
                .ifBlank {
                    "Ohne Nummer"
                }

        val pdfBytes =
            bitmapToPdf(
                bitmap
            )

        /*
         WICHTIG:
         Es wird IMMER eine echte app-interne PDF gespeichert.
         Darauf stützt sich die Archivansicht.
         Zusätzlich wird eine öffentliche Kopie unter Dokumente
         angelegt, damit sie auch im Dateimanager sichtbar ist.
        */

        val archiveFolder =
            File(
                context.filesDir,
                "Einrichteplaene/" +
                    "$cleanCustomer/$cleanNumber"
            )
                .apply {
                    mkdirs()
                }

        val privatePdf =
            File(
                archiveFolder,
                "Einrichteplan.pdf"
            )

        privatePdf.writeBytes(
            pdfBytes
        )

        val publicPath =
            "Documents/FA Fertigung/Einrichteplaene/" +
                "$cleanCustomer/$cleanNumber/"

        var publicUri =
            ""

        if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.Q
        ) {

            runCatching {
                val resolver =
                    context.contentResolver

                val collection =
                    MediaStore.Files
                        .getContentUri(
                            MediaStore
                                .VOLUME_EXTERNAL_PRIMARY
                        )

                resolver.delete(
                    collection,
                    "${MediaStore.MediaColumns.RELATIVE_PATH}=? AND " +
                        "${MediaStore.MediaColumns.DISPLAY_NAME}=?",
                    arrayOf(
                        publicPath,
                        "Einrichteplan.pdf"
                    )
                )

                val values =
                    ContentValues()
                        .apply {
                            put(
                                MediaStore.MediaColumns.DISPLAY_NAME,
                                "Einrichteplan.pdf"
                            )

                            put(
                                MediaStore.MediaColumns.MIME_TYPE,
                                "application/pdf"
                            )

                            put(
                                MediaStore.MediaColumns.RELATIVE_PATH,
                                publicPath
                            )

                            put(
                                MediaStore.MediaColumns.IS_PENDING,
                                1
                            )
                        }

                val uri =
                    resolver.insert(
                        collection,
                        values
                    )
                        ?: throw IllegalStateException(
                            "Öffentliche PDF konnte nicht angelegt werden."
                        )

                resolver
                    .openOutputStream(
                        uri,
                        "w"
                    )
                    ?.use {
                        stream ->

                        stream.write(
                            pdfBytes
                        )

                        stream.flush()
                    }
                    ?: throw IllegalStateException(
                        "Öffentliche PDF konnte nicht geschrieben werden."
                    )

                resolver.update(
                    uri,
                    ContentValues()
                        .apply {
                            put(
                                MediaStore.MediaColumns.IS_PENDING,
                                0
                            )
                        },
                    null,
                    null
                )

                publicUri =
                    uri.toString()
            }
        }

        val displayPath =
            publicPath +
                "Einrichteplan.pdf"

        val metadata =
            JSONObject()
                .put(
                    "customer",
                    customer.trim()
                )
                .put(
                    "setupNumber",
                    setupNumber.trim()
                )
                .put(
                    "path",
                    displayPath
                )
                .put(
                    "privatePath",
                    privatePdf.absolutePath
                )
                .put(
                    "publicUri",
                    publicUri
                )
                .put(
                    "savedAt",
                    System.currentTimeMillis()
                )

        File(
            archiveFolder,
            "archive.json"
        )
            .writeText(
                metadata.toString(
                    2
                ),
                Charsets.UTF_8
            )

        return JSONObject()
            .put(
                "ok",
                true
            )
            .put(
                "customer",
                customer.trim()
            )
            .put(
                "setupNumber",
                setupNumber.trim()
            )
            .put(
                "path",
                displayPath
            )
    }

    fun listPlans(
        context: Context
    ): JSONObject {

        val items =
            JSONArray()

        val root =
            File(
                context.filesDir,
                "Einrichteplaene"
            )

        if (
            root.exists()
        ) {

            root
                .listFiles()
                ?.filter {
                    it.isDirectory
                }
                ?.sortedBy {
                    it.name.lowercase()
                }
                ?.forEach {
                    customerFolder ->

                    customerFolder
                        .listFiles()
                        ?.filter {
                            it.isDirectory
                        }
                        ?.sortedBy {
                            it.name.lowercase()
                        }
                        ?.forEach {
                            setupFolder ->

                            val metadataFile =
                                File(
                                    setupFolder,
                                    "archive.json"
                                )

                            val data =
                                runCatching {
                                    JSONObject(
                                        metadataFile.readText(
                                            Charsets.UTF_8
                                        )
                                    )
                                }
                                    .getOrDefault(
                                        JSONObject()
                                    )

                            val customer =
                                data
                                    .optString(
                                        "customer"
                                    )
                                    .ifBlank {
                                        customerFolder.name
                                    }

                            val setupNumber =
                                data
                                    .optString(
                                        "setupNumber"
                                    )
                                    .ifBlank {
                                        setupFolder.name
                                    }

                            /*
                             Alte FIX12/FIX15-Einträge hatten teils nur Metadaten.
                             Wir versuchen die öffentliche PDF einmalig in das
                             robuste interne Archiv zu übernehmen.
                            */

                            val privatePdf =
                                ensurePrivateCopy(
                                    context,
                                    customer,
                                    setupNumber,
                                    setupFolder,
                                    data
                                )

                            val path =
                                data
                                    .optString(
                                        "path"
                                    )
                                    .ifBlank {
                                        "Documents/FA Fertigung/Einrichteplaene/" +
                                            "${safePathPart(customer)}/" +
                                            "${safePathPart(setupNumber)}/" +
                                            "Einrichteplan.pdf"
                                    }

                            items.put(
                                JSONObject()
                                    .put(
                                        "customer",
                                        customer
                                    )
                                    .put(
                                        "setupNumber",
                                        setupNumber
                                    )
                                    .put(
                                        "path",
                                        path
                                    )
                                    .put(
                                        "savedAt",
                                        data.optLong(
                                            "savedAt",
                                            metadataFile
                                                .takeIf {
                                                    it.exists()
                                                }
                                                ?.lastModified()
                                                ?: 0L
                                        )
                                    )
                                    .put(
                                        "exists",
                                        privatePdf.exists()
                                    )
                            )
                        }
                }
        }

        return JSONObject()
            .put(
                "ok",
                true
            )
            .put(
                "items",
                items
            )
    }

    fun openPlan(
        context: Context,
        customer: String,
        setupNumber: String
    ): JSONObject {

        val cleanCustomer =
            safePathPart(
                customer
            )
                .ifBlank {
                    "Unbekannter Kunde"
                }

        val cleanNumber =
            safePathPart(
                setupNumber
            )
                .ifBlank {
                    "Ohne Nummer"
                }

        val folder =
            File(
                context.filesDir,
                "Einrichteplaene/" +
                    "$cleanCustomer/$cleanNumber"
            )

        val metadata =
            readMetadata(
                folder
            )

        val privatePdf =
            ensurePrivateCopy(
                context,
                customer,
                setupNumber,
                folder,
                metadata
            )

        if (
            !privatePdf.exists()
        ) {

            throw IllegalStateException(
                "Die gespeicherte PDF-Datei wurde nicht gefunden."
            )
        }

        val uri =
            FileProvider
                .getUriForFile(
                    context,
                    context.packageName +
                        ".fileprovider",
                    privatePdf
                )

        val intent =
            Intent(
                Intent.ACTION_VIEW
            )
                .setDataAndType(
                    uri,
                    "application/pdf"
                )
                .addFlags(
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )

        context.startActivity(
            Intent.createChooser(
                intent,
                "Einrichteplan öffnen"
            )
                .addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK
                )
        )

        return JSONObject()
            .put(
                "ok",
                true
            )
    }

    fun deletePlan(
        context: Context,
        customer: String,
        setupNumber: String
    ): JSONObject {

        val cleanCustomer =
            safePathPart(
                customer
            )
                .ifBlank {
                    "Unbekannter Kunde"
                }

        val cleanNumber =
            safePathPart(
                setupNumber
            )
                .ifBlank {
                    "Ohne Nummer"
                }

        val folder =
            File(
                context.filesDir,
                "Einrichteplaene/" +
                    "$cleanCustomer/$cleanNumber"
            )

        val metadata =
            readMetadata(
                folder
            )

        /*
         Öffentliche Kopie bestmöglich löschen.
        */

        if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.Q
        ) {

            runCatching {
                val resolver =
                    context.contentResolver

                val directUri =
                    metadata
                        .optString(
                            "publicUri"
                        )
                        .takeIf {
                            it.isNotBlank()
                        }
                        ?.let {
                            Uri.parse(
                                it
                            )
                        }

                if (
                    directUri != null
                ) {

                    resolver.delete(
                        directUri,
                        null,
                        null
                    )

                } else {

                    val uri =
                        findPublicPdfUri(
                            context,
                            cleanCustomer,
                            cleanNumber
                        )
                            ?: findPublicPdfUriLoose(
                                context,
                                cleanCustomer,
                                cleanNumber
                            )

                    if (
                        uri != null
                    ) {

                        resolver.delete(
                            uri,
                            null,
                            null
                        )
                    }
                }
            }
        }

        if (
            folder.exists()
        ) {

            folder.deleteRecursively()
        }

        val customerFolder =
            File(
                context.filesDir,
                "Einrichteplaene/$cleanCustomer"
            )

        if (
            customerFolder.exists() &&
            customerFolder
                .listFiles()
                .isNullOrEmpty()
        ) {

            customerFolder.delete()
        }

        return JSONObject()
            .put(
                "ok",
                true
            )
    }

    private fun ensurePrivateCopy(
        context: Context,
        customer: String,
        setupNumber: String,
        folder: File,
        metadata: JSONObject
    ): File {

        folder.mkdirs()

        val privatePdf =
            File(
                folder,
                "Einrichteplan.pdf"
            )

        if (
            privatePdf.exists() &&
            privatePdf.length() > 0
        ) {

            return privatePdf
        }

        if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.Q
        ) {

            val cleanCustomer =
                safePathPart(
                    customer
                )
                    .ifBlank {
                        "Unbekannter Kunde"
                    }

            val cleanNumber =
                safePathPart(
                    setupNumber
                )
                    .ifBlank {
                        "Ohne Nummer"
                    }

            val directUri =
                metadata
                    .optString(
                        "publicUri"
                    )
                    .takeIf {
                        it.isNotBlank()
                    }
                    ?.let {
                        runCatching {
                            Uri.parse(
                                it
                            )
                        }
                            .getOrNull()
                    }

            val uri =
                directUri
                    ?: findPublicPdfUri(
                        context,
                        cleanCustomer,
                        cleanNumber
                    )
                    ?: findPublicPdfUriLoose(
                        context,
                        cleanCustomer,
                        cleanNumber
                    )

            if (
                uri != null
            ) {

                runCatching {
                    context
                        .contentResolver
                        .openInputStream(
                            uri
                        )
                        ?.use {
                            input ->

                            privatePdf
                                .outputStream()
                                .use {
                                    output ->

                                    input.copyTo(
                                        output
                                    )
                                }
                        }
                }
            }
        }

        return privatePdf
    }

    private fun findPublicPdfUri(
        context: Context,
        cleanCustomer: String,
        cleanNumber: String
    ): Uri? {

        if (
            Build.VERSION.SDK_INT <
            Build.VERSION_CODES.Q
        ) {
            return null
        }

        val relativePath =
            "Documents/FA Fertigung/Einrichteplaene/" +
                "$cleanCustomer/$cleanNumber/"

        val collection =
            MediaStore.Files
                .getContentUri(
                    MediaStore
                        .VOLUME_EXTERNAL_PRIMARY
                )

        context
            .contentResolver
            .query(
                collection,
                arrayOf(
                    MediaStore.MediaColumns._ID
                ),
                "${MediaStore.MediaColumns.RELATIVE_PATH}=? AND " +
                    "${MediaStore.MediaColumns.DISPLAY_NAME}=?",
                arrayOf(
                    relativePath,
                    "Einrichteplan.pdf"
                ),
                null
            )
            ?.use {
                cursor ->

                if (
                    cursor.moveToFirst()
                ) {

                    val id =
                        cursor.getLong(
                            cursor.getColumnIndexOrThrow(
                                MediaStore.MediaColumns._ID
                            )
                        )

                    return ContentUris
                        .withAppendedId(
                            collection,
                            id
                        )
                }
            }

        return null
    }

    private fun findPublicPdfUriLoose(
        context: Context,
        cleanCustomer: String,
        cleanNumber: String
    ): Uri? {

        if (
            Build.VERSION.SDK_INT <
            Build.VERSION_CODES.Q
        ) {
            return null
        }

        val collection =
            MediaStore.Files
                .getContentUri(
                    MediaStore
                        .VOLUME_EXTERNAL_PRIMARY
                )

        val expected =
            "/FA Fertigung/Einrichteplaene/" +
                "$cleanCustomer/$cleanNumber/"

        context
            .contentResolver
            .query(
                collection,
                arrayOf(
                    MediaStore.MediaColumns._ID,
                    MediaStore.MediaColumns.RELATIVE_PATH
                ),
                "${MediaStore.MediaColumns.DISPLAY_NAME}=?",
                arrayOf(
                    "Einrichteplan.pdf"
                ),
                null
            )
            ?.use {
                cursor ->

                val idIndex =
                    cursor.getColumnIndexOrThrow(
                        MediaStore.MediaColumns._ID
                    )

                val pathIndex =
                    cursor.getColumnIndexOrThrow(
                        MediaStore.MediaColumns.RELATIVE_PATH
                    )

                while (
                    cursor.moveToNext()
                ) {

                    val path =
                        cursor.getString(
                            pathIndex
                        )
                            ?: ""

                    if (
                        (
                            "/" +
                            path.trim('/')
                        )
                            .endsWith(
                                expected.trimEnd(
                                    '/'
                                )
                            ) ||
                        path.contains(
                            "FA Fertigung/Einrichteplaene/" +
                                "$cleanCustomer/$cleanNumber"
                        )
                    ) {

                        return ContentUris
                            .withAppendedId(
                                collection,
                                cursor.getLong(
                                    idIndex
                                )
                            )
                    }
                }
            }

        return null
    }

    private fun readMetadata(
        folder: File
    ): JSONObject {

        val metadata =
            File(
                folder,
                "archive.json"
            )

        return runCatching {
            JSONObject(
                metadata.readText(
                    Charsets.UTF_8
                )
            )
        }
            .getOrDefault(
                JSONObject()
            )
    }

    private fun bitmapToPdf(
        source: Bitmap
    ): ByteArray {

        val portrait =
            source.height >=
                source.width

        val pageWidth =
            if (
                portrait
            ) {
                1240
            } else {
                1754
            }

        val pageHeight =
            if (
                portrait
            ) {
                1754
            } else {
                1240
            }

        val margin =
            45f

        val maxWidth =
            pageWidth -
                margin *
                2f

        val maxHeight =
            pageHeight -
                margin *
                2f

        val scale =
            min(
                maxWidth /
                    source.width
                        .toFloat(),
                maxHeight /
                    source.height
                        .toFloat()
            )

        val drawWidth =
            source.width *
                scale

        val drawHeight =
            source.height *
                scale

        val left =
            (
                pageWidth -
                    drawWidth
            ) /
                2f

        val top =
            (
                pageHeight -
                    drawHeight
            ) /
                2f

        val document =
            PdfDocument()

        try {
            val pageInfo =
                PdfDocument
                    .PageInfo
                    .Builder(
                        pageWidth,
                        pageHeight,
                        1
                    )
                    .create()

            val page =
                document.startPage(
                    pageInfo
                )

            val canvas:
                Canvas =
                page.canvas

            canvas.drawColor(
                Color.WHITE
            )

            canvas.drawBitmap(
                source,
                null,
                android.graphics.RectF(
                    left,
                    top,
                    left +
                        drawWidth,
                    top +
                        drawHeight
                ),
                Paint(
                    Paint.ANTI_ALIAS_FLAG or
                        Paint.FILTER_BITMAP_FLAG
                )
            )

            document.finishPage(
                page
            )

            val output =
                ByteArrayOutputStream()

            document.writeTo(
                output
            )

            return output
                .toByteArray()

        } finally {
            document.close()
        }
    }

    fun extractSetupNumber(
        text: String
    ): String {

        val direct =
            Regex(
                """Einrichteplan\s*:?\s*([A-Za-z]?\d[\w-]*)""",
                RegexOption.IGNORE_CASE
            )
                .find(
                    text
                )
                ?.groupValues
                ?.getOrNull(
                    1
                )
                .orEmpty()
                .trim()

        if (
            direct.isNotBlank()
        ) {

            return direct
                .uppercase()
        }

        return "Ohne Nummer"
    }

    private fun safePathPart(
        value: String
    ): String {

        return value
            .trim()
            .replace(
                Regex(
                    """[\\/:*?"<>|]"""
                ),
                "_"
            )
            .replace(
                Regex(
                    """\s+"""
                ),
                " "
            )
            .trim(
                '.',
                ' '
            )
            .take(
                100
            )
    }
}
