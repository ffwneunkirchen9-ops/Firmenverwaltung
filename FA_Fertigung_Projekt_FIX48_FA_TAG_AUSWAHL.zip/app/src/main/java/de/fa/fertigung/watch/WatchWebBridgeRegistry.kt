package de.fa.fertigung.watch

import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import java.lang.ref.WeakReference

object WatchWebBridgeRegistry {

    private var webViewRef:
        WeakReference<WebView>? =
        null

    fun register(
        webView: WebView
    ) {
        webViewRef =
            WeakReference(
                webView
            )
    }

    fun unregister(
        webView: WebView
    ) {
        val current =
            webViewRef?.get()

        if (
            current ===
            webView
        ) {
            webViewRef =
                null
        }
    }

    fun notifyWatchEvents() {
        val view =
            webViewRef?.get()
                ?: return

        Handler(
            Looper.getMainLooper()
        ).post {
            runCatching {
                view.evaluateJavascript(
                    "window.faConsumeWatchQueue && window.faConsumeWatchQueue();",
                    null
                )
            }
        }
    }
}
