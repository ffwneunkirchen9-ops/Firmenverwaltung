package de.fa.fertigung.watch

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object WatchEventStore {

    private const val PREFS =
        "fa_watch_events"

    private const val KEY_QUEUE =
        "queue"

    @Synchronized
    fun enqueue(
        context: Context,
        event: JSONObject
    ): Boolean {

        val eventId =
            event.optString(
                "eventId"
            )
                .trim()

        if (
            eventId.isEmpty()
        ) {
            return false
        }

        val queue =
            readQueue(
                context
            )

        for (
            index in
            0 until queue.length()
        ) {
            if (
                queue
                    .optJSONObject(
                        index
                    )
                    ?.optString(
                        "eventId"
                    ) ==
                eventId
            ) {
                return false
            }
        }

        queue.put(
            event
        )

        saveQueue(
            context,
            queue
        )

        return true
    }


    @Synchronized
    fun peekJson(
        context: Context
    ): String {

        return JSONObject()
            .put(
                "ok",
                true
            )
            .put(
                "events",
                readQueue(
                    context
                )
            )
            .toString()
    }


    @Synchronized
    fun acknowledge(
        context: Context,
        ids: Set<String>
    ): List<String> {

        if (
            ids.isEmpty()
        ) {
            return emptyList()
        }

        val oldQueue =
            readQueue(
                context
            )

        val newQueue =
            JSONArray()

        val dataUris =
            mutableListOf<String>()

        for (
            index in
            0 until oldQueue.length()
        ) {
            val event =
                oldQueue.optJSONObject(
                    index
                )
                    ?: continue

            val id =
                event.optString(
                    "eventId"
                )

            if (
                ids.contains(
                    id
                )
            ) {
                val dataUri =
                    event.optString(
                        "dataUri"
                    )

                if (
                    dataUri.isNotBlank()
                ) {
                    dataUris.add(
                        dataUri
                    )
                }
            }
            else {
                newQueue.put(
                    event
                )
            }
        }

        saveQueue(
            context,
            newQueue
        )

        return dataUris
    }


    private fun readQueue(
        context: Context
    ): JSONArray {

        val raw =
            context
                .getSharedPreferences(
                    PREFS,
                    Context.MODE_PRIVATE
                )
                .getString(
                    KEY_QUEUE,
                    "[]"
                )
                .orEmpty()

        return runCatching {
            JSONArray(
                raw
            )
        }.getOrElse {
            JSONArray()
        }
    }


    private fun saveQueue(
        context: Context,
        queue: JSONArray
    ) {

        context
            .getSharedPreferences(
                PREFS,
                Context.MODE_PRIVATE
            )
            .edit()
            .putString(
                KEY_QUEUE,
                queue.toString()
            )
            .apply()
    }
}
