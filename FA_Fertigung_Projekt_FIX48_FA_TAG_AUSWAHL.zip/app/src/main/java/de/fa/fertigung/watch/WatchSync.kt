package de.fa.fertigung.watch

import android.content.Context
import android.net.Uri
import com.google.android.gms.tasks.Tasks
import com.google.android.gms.wearable.DataMapItem
import com.google.android.gms.wearable.PutDataMapRequest
import com.google.android.gms.wearable.Wearable
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object WatchSync {

    const val CONTEXT_PATH =
        "/fa/watch/context"

    const val EVENT_PREFIX =
        "/fa/watch/event/"

    const val ACK_PATH =
        "/fa/watch/ack"

    const val EVENT_MESSAGE_PATH =
        "/fa/watch/action"


    fun publishContext(
        context: Context,
        json: String
    ) {

        val request =
            PutDataMapRequest
                .create(
                    CONTEXT_PATH
                )
                .apply {
                    dataMap.putString(
                        "json",
                        json
                    )

                    dataMap.putLong(
                        "updatedAt",
                        System.currentTimeMillis()
                    )
                }
                .asPutDataRequest()
                .setUrgent()

        Wearable
            .getDataClient(
                context
            )
            .putDataItem(
                request
            )
    }


    fun acknowledgeEvents(
        context: Context,
        eventIds: List<String>,
        eventUris: List<String>
    ) {

        if (
            eventIds.isNotEmpty()
        ) {

            val request =
                PutDataMapRequest
                    .create(
                        ACK_PATH
                    )
                    .apply {
                        dataMap.putStringArrayList(
                            "eventIds",
                            ArrayList(
                                eventIds
                            )
                        )

                        dataMap.putLong(
                            "updatedAt",
                            System.currentTimeMillis()
                        )
                    }
                    .asPutDataRequest()
                    .setUrgent()

            Wearable
                .getDataClient(
                    context
                )
                .putDataItem(
                    request
                )
        }


        /*
         * Bereits sicher in der Web-App bestätigte Event-DataItems
         * können danach entfernt werden.
         */
        eventUris.forEach {
            uriString ->

            runCatching {
                Wearable
                    .getDataClient(
                        context
                    )
                    .deleteDataItems(
                        Uri.parse(
                            uriString
                        )
                    )
            }
        }
    }


    fun importPendingEvents(
        context: Context
    ): Int {

        var imported =
            0

        val buffer =
            Tasks.await(
                Wearable
                    .getDataClient(
                        context
                    )
                    .dataItems,
                5,
                TimeUnit.SECONDS
            )

        try {

            for (
                index in
                0 until buffer.count
            ) {

                val item =
                    buffer.get(
                        index
                    )

                val path =
                    item.uri.path
                        .orEmpty()

                if (
                    !path.startsWith(
                        EVENT_PREFIX
                    )
                ) {
                    continue
                }

                val map =
                    runCatching {
                        DataMapItem
                            .fromDataItem(
                                item
                            )
                            .dataMap
                    }.getOrNull()
                        ?: continue

                val eventId =
                    map.getString(
                        "eventId"
                    )
                        .orEmpty()
                        .trim()

                if (
                    eventId.isEmpty()
                ) {
                    continue
                }

                val json =
                    JSONObject()
                        .put(
                            "eventId",
                            eventId
                        )
                        .put(
                            "type",
                            map.getString(
                                "type"
                            ).orEmpty()
                        )
                        .put(
                            "faId",
                            map.getString(
                                "faId"
                            ).orEmpty()
                        )
                        .put(
                            "faNo",
                            map.getString(
                                "faNo"
                            ).orEmpty()
                        )
                        .put(
                            "date",
                            map.getString(
                                "date"
                            ).orEmpty()
                        )
                        .put(
                            "positionIndex",
                            map.getInt(
                                "positionIndex",
                                0
                            )
                        )
                        .put(
                            "timestamp",
                            map.getLong(
                                "timestamp",
                                System.currentTimeMillis()
                            )
                        )
                        .put(
                            "dataUri",
                            item.uri.toString()
                        )

                if (
                    WatchEventStore.enqueue(
                        context,
                        json
                    )
                ) {
                    imported++
                }
            }

        } finally {

            buffer.release()
        }

        return imported
    }


    fun statusJson(): String {

        return JSONObject()
            .put(
                "ok",
                true
            )
            .put(
                "wearable",
                true
            )
            .toString()
    }
}
