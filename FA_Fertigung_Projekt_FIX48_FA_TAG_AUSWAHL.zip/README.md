# FA Fertigung FIX48

FIX48 erweitert FIX47 um die direkte Auswahl von FA und Arbeitstag auf der Galaxy Watch.

Bedienung:
- FA-Feld oder Wechsel-Symbol antippen: aktiven FA auswählen.
- Arbeitsgang/Datum antippen: Arbeitstag auswählen.
- Heute kann normal inklusive Timer bearbeitet werden.
- Historische Tage können bei Menge/Platten/Ausschuss korrigiert werden; der Timer ist dort bewusst deaktiviert.

Für FIX48 müssen sowohl `script.html` in Apps Script als auch die Watch-APK aktualisiert werden.
