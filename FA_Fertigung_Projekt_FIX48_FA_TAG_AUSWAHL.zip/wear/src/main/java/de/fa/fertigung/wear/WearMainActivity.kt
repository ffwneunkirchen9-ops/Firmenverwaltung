package de.fa.fertigung.wear

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import org.json.JSONObject
import kotlin.math.min

class WearMainActivity : Activity() {

    private lateinit var controlView: FaControlView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        controlView = FaControlView()
        setContentView(controlView)

        // Samsung Wear OS can return a null decor view / insets controller
        // during Activity.onCreate(). Configure fullscreen only after the
        // content view is attached to a window.
        controlView.post {
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                window.setDecorFitsSystemWindows(false)
                controlView.windowInsetsController?.let { controller ->
                    controller.hide(
                        WindowInsets.Type.statusBars() or
                            WindowInsets.Type.navigationBars()
                    )
                    controller.systemBarsBehavior =
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                }
            } else {
                @Suppress("DEPRECATION")
                run {
                    window.decorView.systemUiVisibility =
                        View.SYSTEM_UI_FLAG_FULLSCREEN or
                            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()

        controlView.startRefreshing()

        /*
         * FIX47:
         * Beim Öffnen immer den zuletzt vom Handy veröffentlichten
         * Tagesstand einlesen. Dadurch zeigt die Uhr bei einem bereits
         * vorhandenen Arbeitstag nicht mehr lokal 0 an, sondern z. B.
         * direkt 731.
         */
        WatchDataSync
            .refreshContextFromDataLayer(
                this
            ) {

                controlView.invalidate()
            }
    }

    override fun onPause() {
        controlView.stopRefreshing()
        super.onPause()
    }

    private inner class FaControlView : View(this) {

        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val handler = Handler(Looper.getMainLooper())
        private var scale = 1f

        private val bg = Color.BLACK
        private val panel = Color.rgb(30, 22, 54)
        private val panel2 = Color.rgb(48, 32, 92)
        private val valueBg = Color.rgb(80, 42, 176)
        private val light = Color.rgb(199, 171, 255)
        private val text = Color.WHITE
        private val muted = Color.rgb(220, 210, 240)

        private var faRect = RectF()
        private var switchRect = RectF()
        private var opRect = RectF()
        private var minus1Rect = RectF()
        private var value1Rect = RectF()
        private var plus1Rect = RectF()
        private var minus2Rect = RectF()
        private var value2Rect = RectF()
        private var plus2Rect = RectF()
        private var timerMainRect = RectF()
        private var timerStopRect = RectF()

        private val refresh = object : Runnable {
            override fun run() {
                invalidate()
                handler.postDelayed(this, 500L)
            }
        }

        fun startRefreshing() {
            handler.removeCallbacks(refresh)
            handler.post(refresh)
        }

        fun stopRefreshing() {
            handler.removeCallbacks(refresh)
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)

            val size = min(width, height).toFloat()
            scale = size / 480f

            canvas.drawColor(bg)

            val fa = WatchStateStore.selectedFa(this@WearMainActivity)
            if (fa == null) {
                drawNoFa(canvas)
                return
            }

            val positions = fa.optJSONArray("positions")
            val positionCount = positions?.length() ?: 0
            val selected = WatchStateStore.selectedPosition(
                this@WearMainActivity,
                positionCount
            )
            val position =
                positions?.optJSONObject(selected) ?: JSONObject()

            val faNo = fa.optString("faNo", "?")
            val op = fa.optString("op", "Arbeitsgang")
            val selectedDate = fa.optString(
                "date",
                WatchStateStore.selectedDate(
                    this@WearMainActivity
                )
            )
            val todaySelected =
                WatchStateStore.isTodaySelected(
                    this@WearMainActivity
                )
            val plates = fa.optInt("plates", 0)
            val scrap = position.optInt("scrap", 0)
            val quantityToday = position.optInt("quantity", 0)
            val timerState = fa.optString("timerState", "stopped")
            val timerMinutes = currentTimerMinutes(fa)

            layoutRects()

            drawRoundRect(canvas, faRect, 22f, panel2)
            drawCenteredText(canvas, "FA $faNo", faRect, 30f, text, true)

            drawRoundRect(canvas, switchRect, 22f, panel2)
            drawSwitchIcon(canvas, switchRect)

            drawRoundRect(canvas, opRect, 20f, panel2)
            drawCenteredText(
                canvas,
                "$op · ${formatDateDE(selectedDate)}",
                opRect,
                23f,
                muted,
                true
            )

            if (op == "Schneiden") {
                drawValuePanel(
                    canvas = canvas,
                    panelTop = 164f,
                    label = "Platten",
                    value = plates,
                    minusRect = minus1Rect,
                    valueRect = value1Rect,
                    plusRect = plus1Rect
                )
            } else {
                drawValuePanel(
                    canvas = canvas,
                    panelTop = 164f,
                    label = "Tagesmenge",
                    value = quantityToday,
                    minusRect = minus1Rect,
                    valueRect = value1Rect,
                    plusRect = plus1Rect
                )
            }

            val scrapLabel =
                if (positionCount > 1) {
                    "Ausschuss P${selected + 1}/$positionCount"
                } else {
                    "Ausschuss"
                }

            drawValuePanel(
                canvas = canvas,
                panelTop = 267f,
                label = scrapLabel,
                value = scrap,
                minusRect = minus2Rect,
                valueRect = value2Rect,
                plusRect = plus2Rect
            )

            drawTimer(
                canvas,
                timerState,
                timerMinutes,
                todaySelected
            )
        }

        private fun layoutRects() {
            fun r(l: Float, t: Float, rr: Float, b: Float) =
                RectF(l * scale, t * scale, rr * scale, b * scale)

            faRect = r(72f, 42f, 354f, 102f)
            switchRect = r(365f, 42f, 430f, 102f)
            opRect = r(86f, 108f, 394f, 150f)

            minus1Rect = r(58f, 196f, 126f, 258f)
            value1Rect = r(142f, 192f, 338f, 261f)
            plus1Rect = r(354f, 196f, 422f, 258f)

            minus2Rect = r(58f, 299f, 126f, 361f)
            value2Rect = r(142f, 295f, 338f, 364f)
            plus2Rect = r(354f, 299f, 422f, 361f)

            timerMainRect = r(86f, 378f, 394f, 438f)
            timerStopRect = r(334f, 378f, 414f, 438f)
        }

        private fun drawValuePanel(
            canvas: Canvas,
            panelTop: Float,
            label: String,
            value: Int,
            minusRect: RectF,
            valueRect: RectF,
            plusRect: RectF
        ) {
            val panelRect = RectF(
                42f * scale,
                panelTop * scale,
                438f * scale,
                (panelTop + 101f) * scale
            )
            drawRoundRect(canvas, panelRect, 24f, panel)

            paint.color = muted
            paint.textAlign = Paint.Align.CENTER
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            paint.textSize = 19f * scale
            val labelY = (panelTop + 24f) * scale - (paint.ascent() + paint.descent()) / 2f
            canvas.drawText(label, 240f * scale, labelY, paint)

            drawRoundRect(canvas, minusRect, 28f, panel2)
            drawMinus(canvas, minusRect)

            drawRoundRect(canvas, valueRect, 24f, valueBg)
            drawCenteredText(canvas, value.toString(), valueRect, 38f, text, true)

            drawRoundRect(canvas, plusRect, 28f, light)
            drawPlus(canvas, plusRect)
        }

        private fun drawTimer(
            canvas: Canvas,
            state: String,
            minutes: Int,
            todaySelected: Boolean
        ) {
            if (!todaySelected) {
                drawRoundRect(
                    canvas,
                    timerMainRect,
                    30f,
                    panel2
                )
                drawCenteredText(
                    canvas,
                    "Timer nur heute",
                    timerMainRect,
                    21f,
                    muted,
                    true
                )
                return
            }

            if (state == "stopped") {
                drawRoundRect(canvas, timerMainRect, 30f, light)
                drawTimerPlayIcon(canvas, timerMainRect)
                drawTimerText(canvas, "Start", timerMainRect, offsetX = 26f)
            } else {
                timerMainRect = RectF(
                    66f * scale,
                    378f * scale,
                    326f * scale,
                    438f * scale
                )
                timerStopRect = RectF(
                    336f * scale,
                    378f * scale,
                    414f * scale,
                    438f * scale
                )

                drawRoundRect(canvas, timerMainRect, 30f, light)
                val mainLabel =
                    if (state == "running") {
                        "Pause · ${formatMinutes(minutes)}"
                    } else {
                        "Weiter · ${formatMinutes(minutes)}"
                    }
                drawTimerText(canvas, mainLabel, timerMainRect)

                drawRoundRect(canvas, timerStopRect, 30f, panel2)
                drawStopIcon(canvas, timerStopRect)
            }
        }

        private fun drawNoFa(canvas: Canvas) {
            paint.color = text
            paint.textAlign = Paint.Align.CENTER
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            paint.textSize = 28f * scale
            canvas.drawText(
                "FA Fertigung",
                width / 2f,
                height * 0.42f,
                paint
            )
            paint.color = muted
            paint.typeface = Typeface.DEFAULT
            paint.textSize = 18f * scale
            canvas.drawText(
                "Am Handy einen FA öffnen.",
                width / 2f,
                height * 0.54f,
                paint
            )
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (event.action != MotionEvent.ACTION_UP) {
                return true
            }

            val x = event.x
            val y = event.y

            val fa = WatchStateStore.selectedFa(this@WearMainActivity)
                ?: return true

            val positions = fa.optJSONArray("positions")
            val positionCount = positions?.length() ?: 0

            when {
                faRect.contains(x, y) ||
                    switchRect.contains(x, y) -> {
                    showFaChooser()
                }

                opRect.contains(x, y) -> {
                    showDayChooser()
                }

                minus1Rect.contains(x, y) -> {
                    if (fa.optString("op") == "Schneiden") {
                        act(TileActionReceiver.ACTION_PLATE_MINUS)
                    } else {
                        act(TileActionReceiver.ACTION_QUANTITY_MINUS_10)
                    }
                }

                plus1Rect.contains(x, y) -> {
                    if (fa.optString("op") == "Schneiden") {
                        act(TileActionReceiver.ACTION_PLATE_PLUS)
                    } else {
                        act(TileActionReceiver.ACTION_QUANTITY_PLUS_10)
                    }
                }

                minus2Rect.contains(x, y) -> {
                    act(TileActionReceiver.ACTION_SCRAP_MINUS)
                }

                plus2Rect.contains(x, y) -> {
                    act(TileActionReceiver.ACTION_SCRAP_PLUS)
                }

                value2Rect.contains(x, y) && positionCount > 1 -> {
                    act(TileActionReceiver.ACTION_NEXT_POSITION)
                }

                WatchStateStore.isTodaySelected(
                    this@WearMainActivity
                ) &&
                    timerStopRect.contains(x, y) &&
                    fa.optString("timerState", "stopped") != "stopped" -> {
                    act(TileActionReceiver.ACTION_TIMER_STOP)
                }

                WatchStateStore.isTodaySelected(
                    this@WearMainActivity
                ) &&
                    timerMainRect.contains(x, y) -> {
                    act(TileActionReceiver.ACTION_TIMER_TOGGLE)
                }
            }

            invalidate()
            return true
        }

        private fun showFaChooser() {
            val choices =
                WatchStateStore.faChoices(
                    this@WearMainActivity
                )

            if (choices.length() <= 0) {
                return
            }

            val labels =
                ArrayList<String>()

            val ids =
                ArrayList<String>()

            for (
                index in
                0 until choices.length()
            ) {
                val item =
                    choices.optJSONObject(
                        index
                    )
                        ?: continue

                val id =
                    item.optString(
                        "faId"
                    )

                if (id.isBlank()) {
                    continue
                }

                ids.add(id)

                labels.add(
                    "FA ${item.optString("faNo", "?")} · " +
                        item.optString(
                            "op",
                            "Arbeitsgang"
                        )
                )
            }

            if (labels.isEmpty()) {
                return
            }

            AlertDialog
                .Builder(
                    this@WearMainActivity
                )
                .setTitle(
                    "FA auswählen"
                )
                .setItems(
                    labels.toTypedArray()
                ) {
                    dialog,
                    which ->

                    if (
                        which in
                        ids.indices
                    ) {
                        WatchStateStore.selectFa(
                            this@WearMainActivity,
                            ids[which]
                        )

                        dialog.dismiss()
                        invalidate()
                    }
                }
                .setNegativeButton(
                    "Abbrechen",
                    null
                )
                .show()
        }


        private fun showDayChooser() {
            val dates =
                WatchStateStore.availableDates(
                    this@WearMainActivity
                )

            if (dates.isEmpty()) {
                return
            }

            val today =
                WatchStateStore.currentDateString()

            val labels =
                dates.map {
                    date ->

                    if (date == today) {
                        "Heute · ${formatDateDE(date)}"
                    }
                    else {
                        formatDateDE(date)
                    }
                }

            AlertDialog
                .Builder(
                    this@WearMainActivity
                )
                .setTitle(
                    "Tag auswählen"
                )
                .setItems(
                    labels.toTypedArray()
                ) {
                    dialog,
                    which ->

                    if (
                        which in
                        dates.indices
                    ) {
                        WatchStateStore.selectDate(
                            this@WearMainActivity,
                            dates[which]
                        )

                        dialog.dismiss()
                        invalidate()
                    }
                }
                .setNegativeButton(
                    "Abbrechen",
                    null
                )
                .show()
        }


        private fun formatDateDE(
            value: String
        ): String {
            val parts =
                value.split(
                    "-"
                )

            if (
                parts.size != 3
            ) {
                return value
            }

            return (
                parts[2] +
                    "." +
                    parts[1] +
                    "." +
                    parts[0]
            )
        }


        private fun act(action: String) {
            TileActionReceiver.handleAction(
                this@WearMainActivity,
                action,
                true
            )
        }

        private fun drawSwitchIcon(canvas: Canvas, rect: RectF) {
            paint.color = light
            paint.strokeWidth = 4.5f * scale
            paint.style = Paint.Style.STROKE
            paint.strokeCap = Paint.Cap.ROUND

            val left = rect.left + 17f * scale
            val right = rect.right - 17f * scale
            val y1 = rect.centerY() - 9f * scale
            val y2 = rect.centerY() + 9f * scale

            canvas.drawLine(left, y1, right - 7f * scale, y1, paint)
            canvas.drawLine(right - 7f * scale, y1, right - 14f * scale, y1 - 7f * scale, paint)
            canvas.drawLine(right - 7f * scale, y1, right - 14f * scale, y1 + 7f * scale, paint)

            canvas.drawLine(right, y2, left + 7f * scale, y2, paint)
            canvas.drawLine(left + 7f * scale, y2, left + 14f * scale, y2 - 7f * scale, paint)
            canvas.drawLine(left + 7f * scale, y2, left + 14f * scale, y2 + 7f * scale, paint)

            paint.style = Paint.Style.FILL
        }

        private fun drawMinus(canvas: Canvas, rect: RectF) {
            paint.color = light
            paint.strokeWidth = 5.5f * scale
            paint.strokeCap = Paint.Cap.ROUND
            canvas.drawLine(
                rect.centerX() - 12f * scale,
                rect.centerY(),
                rect.centerX() + 12f * scale,
                rect.centerY(),
                paint
            )
        }

        private fun drawPlus(canvas: Canvas, rect: RectF) {
            paint.color = Color.rgb(35, 20, 55)
            paint.strokeWidth = 5.5f * scale
            paint.strokeCap = Paint.Cap.ROUND
            canvas.drawLine(
                rect.centerX() - 12f * scale,
                rect.centerY(),
                rect.centerX() + 12f * scale,
                rect.centerY(),
                paint
            )
            canvas.drawLine(
                rect.centerX(),
                rect.centerY() - 12f * scale,
                rect.centerX(),
                rect.centerY() + 12f * scale,
                paint
            )
        }

        private fun drawTimerPlayIcon(canvas: Canvas, rect: RectF) {
            paint.color = Color.rgb(35, 20, 55)
            paint.style = Paint.Style.FILL
            val cx = rect.centerX() - 58f * scale
            val cy = rect.centerY()
            val path = android.graphics.Path().apply {
                moveTo(cx - 8f * scale, cy - 12f * scale)
                lineTo(cx + 12f * scale, cy)
                lineTo(cx - 8f * scale, cy + 12f * scale)
                close()
            }
            canvas.drawPath(path, paint)
        }

        private fun drawStopIcon(canvas: Canvas, rect: RectF) {
            paint.color = light
            paint.style = Paint.Style.FILL
            val s = 18f * scale
            canvas.drawRect(
                rect.centerX() - s / 2f,
                rect.centerY() - s / 2f,
                rect.centerX() + s / 2f,
                rect.centerY() + s / 2f,
                paint
            )
        }

        private fun drawTimerText(
            canvas: Canvas,
            label: String,
            rect: RectF,
            offsetX: Float = 0f
        ) {
            paint.color = Color.rgb(35, 20, 55)
            paint.textAlign = Paint.Align.CENTER
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            paint.textSize = 23f * scale
            val y = rect.centerY() - (paint.ascent() + paint.descent()) / 2f
            canvas.drawText(
                label,
                rect.centerX() + offsetX * scale,
                y,
                paint
            )
        }

        private fun drawRoundRect(
            canvas: Canvas,
            rect: RectF,
            radius: Float,
            color: Int
        ) {
            paint.color = color
            paint.style = Paint.Style.FILL
            canvas.drawRoundRect(
                rect,
                radius * scale,
                radius * scale,
                paint
            )
        }

        private fun drawCenteredText(
            canvas: Canvas,
            value: String,
            rect: RectF,
            size: Float,
            color: Int,
            bold: Boolean
        ) {
            paint.color = color
            paint.textAlign = Paint.Align.CENTER
            paint.typeface =
                if (bold) Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                else Typeface.DEFAULT
            paint.textSize = size * scale

            var textSize = paint.textSize
            val maxWidth = rect.width() - 18f * scale
            while (paint.measureText(value) > maxWidth && textSize > 12f * scale) {
                textSize -= 1f * scale
                paint.textSize = textSize
            }

            val y = rect.centerY() - (paint.ascent() + paint.descent()) / 2f
            canvas.drawText(value, rect.centerX(), y, paint)
        }

        private fun currentTimerMinutes(fa: JSONObject): Int {
            var minutes =
                fa.optInt("timerClosedMinutes", 0)
                    .coerceAtLeast(0)

            if (fa.optString("timerState", "stopped") == "running") {
                val since = fa.optLong("runningSince", 0L)
                if (since > 0L) {
                    minutes +=
                        ((System.currentTimeMillis() - since)
                            .coerceAtLeast(0L) / 60000L)
                            .toInt()
                }
            }

            return minutes
        }

        private fun formatMinutes(minutes: Int): String {
            val safe = minutes.coerceAtLeast(0)
            val h = safe / 60
            val m = safe % 60
            return if (h > 0) {
                "$h:${m.toString().padStart(2, '0')}"
            } else {
                "${m}m"
            }
        }
    }
}
