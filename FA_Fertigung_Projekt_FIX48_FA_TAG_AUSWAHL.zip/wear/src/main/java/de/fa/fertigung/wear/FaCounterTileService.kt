package de.fa.fertigung.wear

import android.content.ComponentName
import android.content.Context
import androidx.wear.protolayout.DimensionBuilders.expand
import androidx.wear.protolayout.ProtoLayoutScope
import androidx.wear.protolayout.TimelineBuilders.Timeline
import androidx.wear.protolayout.material3.ButtonDefaults.filledButtonColors
import androidx.wear.protolayout.material3.Typography.BODY_LARGE
import androidx.wear.protolayout.material3.materialScopeWithResources
import androidx.wear.protolayout.material3.primaryLayout
import androidx.wear.protolayout.material3.text
import androidx.wear.protolayout.material3.textButton
import androidx.wear.protolayout.modifiers.clickable
import androidx.wear.protolayout.ActionBuilders.launchAction
import androidx.wear.protolayout.types.layoutString
import androidx.wear.tiles.RequestBuilders
import androidx.wear.tiles.TileService
import androidx.wear.tiles.tile
import com.google.common.util.concurrent.Futures

class FaCounterTileService : TileService() {

    override fun onTileRequest(
        requestParams: RequestBuilders.TileRequest
    ) =
        Futures.immediateFuture(
            tile(
                Timeline.fromLayoutElement(
                    buildTileLayout(
                        this,
                        requestParams.scope,
                        requestParams.deviceConfiguration
                    )
                )
            )
        )

    private fun buildTileLayout(
        context: Context,
        scope: ProtoLayoutScope,
        deviceParameters:
            androidx.wear.protolayout.DeviceParametersBuilders.DeviceParameters
    ) =
        materialScopeWithResources(
            context,
            scope,
            deviceParameters
        ) {
            val fa = WatchStateStore.selectedFa(context)
            val faNo = fa?.optString("faNo", "?") ?: "?"

            val openClick =
                clickable(
                    id = "open_fa_activity",
                    action =
                        launchAction(
                            ComponentName(
                                context.packageName,
                                WearMainActivity::class.java.name
                            )
                        )
                )

            primaryLayout(
                titleSlot = {
                    text(("FA " + faNo).layoutString)
                },
                mainSlot = {
                    textButton(
                        width = expand(),
                        height = expand(),
                        onClick = openClick,
                        colors = filledButtonColors(),
                        labelContent = {
                            text(
                                "FA öffnen".layoutString,
                                typography = BODY_LARGE
                            )
                        }
                    )
                }
            )
        }
}
