package de.fa.fertigung.wear

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object WatchStateStore {

    private const val PREFS =
        "fa_watch_state"

    private const val KEY_CONTEXT =
        "context_json"

    private const val KEY_POSITION =
        "selected_position"

    private const val KEY_SELECTED_FA =
        "selected_fa_id"

    private const val KEY_PENDING =
        "pending_events"

    private const val KEY_SELECTED_DATE =
        "selected_date"

    private const val KEY_DAY_MODE =
        "selected_day_mode"

    private const val DAY_MODE_TODAY =
        "today"

    private const val DAY_MODE_MANUAL =
        "manual"


    fun contextJson(
        context: Context
    ): String {

        return context
            .getSharedPreferences(
                PREFS,
                Context.MODE_PRIVATE
            )
            .getString(
                KEY_CONTEXT,
                "{}"
            )
            .orEmpty()
    }


    fun saveContext(
        context: Context,
        json: String
    ) {

        context
            .getSharedPreferences(
                PREFS,
                Context.MODE_PRIVATE
            )
            .edit()
            .putString(
                KEY_CONTEXT,
                json
            )
            .apply()

        ensureSelectedFa(
            context
        )

        ensureSelectedDay(
            context
        )

        clampSelectedPosition(
            context
        )
    }


    fun selectedFa(
        context: Context
    ): JSONObject? {

        val root =
            rootObject(
                context
            )

        return selectedFaFromRoot(
            context,
            root
        )
    }


    fun currentDateString(): String {

        return SimpleDateFormat(
            "yyyy-MM-dd",
            Locale.US
        ).format(
            Date()
        )
    }


    fun selectedDate(
        context: Context
    ): String {

        val root =
            rootObject(
                context
            )

        val container =
            selectedFaContainerFromRoot(
                context,
                root
            )
                ?: return currentDateString()

        return selectedDateForContainer(
            context,
            container
        )
    }


    fun isTodaySelected(
        context: Context
    ): Boolean {

        return selectedDate(
            context
        ) == currentDateString()
    }


    fun availableDates(
        context: Context
    ): List<String> {

        val root =
            rootObject(
                context
            )

        val container =
            selectedFaContainerFromRoot(
                context,
                root
            )
                ?: return emptyList()

        val result =
            mutableListOf<String>()

        val days =
            container.optJSONArray(
                "days"
            )

        if (
            days != null
        ) {

            for (
                index in
                0 until days.length()
            ) {

                val date =
                    days
                        .optJSONObject(
                            index
                        )
                        ?.optString(
                            "date"
                        )
                        .orEmpty()

                if (
                    date.isNotBlank() &&
                    !result.contains(
                        date
                    )
                ) {
                    result.add(
                        date
                    )
                }
            }
        }

        val today =
            currentDateString()

        if (
            !result.contains(
                today
            )
        ) {
            result.add(
                today
            )
        }

        return result.sortedDescending()
    }


    fun selectDate(
        context: Context,
        date: String
    ): Boolean {

        val clean =
            date.trim()

        if (
            clean.isBlank() ||
            !availableDates(
                context
            ).contains(
                clean
            )
        ) {
            return false
        }

        val today =
            currentDateString()

        context
            .getSharedPreferences(
                PREFS,
                Context.MODE_PRIVATE
            )
            .edit()
            .putString(
                KEY_SELECTED_DATE,
                clean
            )
            .putString(
                KEY_DAY_MODE,
                if (
                    clean == today
                ) {
                    DAY_MODE_TODAY
                }
                else {
                    DAY_MODE_MANUAL
                }
            )
            .putInt(
                KEY_POSITION,
                0
            )
            .apply()

        return true
    }


    fun faChoices(
        context: Context
    ): JSONArray {

        val root =
            rootObject(
                context
            )

        val fas =
            root.optJSONArray(
                "fas"
            )

        if (
            fas != null
        ) {
            return JSONArray(
                fas.toString()
            )
        }

        val result =
            JSONArray()

        if (
            root.optBoolean(
                "active",
                false
            )
        ) {
            result.put(
                JSONObject(
                    root.toString()
                )
            )
        }

        return result
    }


    fun selectFa(
        context: Context,
        faId: String
    ): Boolean {

        val clean =
            faId.trim()

        if (
            clean.isBlank()
        ) {
            return false
        }

        val root =
            rootObject(
                context
            )

        val fas =
            root.optJSONArray(
                "fas"
            )
                ?: return false

        var exists =
            false

        for (
            index in
            0 until fas.length()
        ) {

            if (
                fas
                    .optJSONObject(
                        index
                    )
                    ?.optString(
                        "faId"
                    ) == clean
            ) {
                exists = true
                break
            }
        }

        if (
            !exists
        ) {
            return false
        }

        val today =
            currentDateString()

        context
            .getSharedPreferences(
                PREFS,
                Context.MODE_PRIVATE
            )
            .edit()
            .putString(
                KEY_SELECTED_FA,
                clean
            )
            .putInt(
                KEY_POSITION,
                0
            )
            .putString(
                KEY_SELECTED_DATE,
                today
            )
            .putString(
                KEY_DAY_MODE,
                DAY_MODE_TODAY
            )
            .apply()

        return true
    }


    fun selectedFaCount(
        context: Context
    ): Int {

        val root =
            rootObject(
                context
            )

        val fas =
            root.optJSONArray(
                "fas"
            )

        return if (
            fas != null &&
            fas.length() > 0
        ) {
            fas.length()
        }
        else if (
            root.optBoolean(
                "active",
                false
            )
        ) {
            1
        }
        else {
            0
        }
    }


    fun selectedFaIndex(
        context: Context
    ): Int {

        val root =
            rootObject(
                context
            )

        val fas =
            root.optJSONArray(
                "fas"
            )
                ?: return 0

        val selectedId =
            selectedFaId(
                context,
                root
            )

        for (
            index in
            0 until fas.length()
        ) {

            val item =
                fas.optJSONObject(
                    index
                )
                    ?: continue

            if (
                item.optString(
                    "faId"
                ) ==
                selectedId
            ) {
                return index
            }
        }

        return 0
    }


    fun nextFa(
        context: Context
    ) {

        val root =
            rootObject(
                context
            )

        val fas =
            root.optJSONArray(
                "fas"
            )
                ?: return

        if (
            fas.length() <= 1
        ) {
            return
        }

        val next =
            (
                selectedFaIndex(
                    context
                ) +
                1
            ) %
            fas.length()

        val nextId =
            fas
                .optJSONObject(
                    next
                )
                ?.optString(
                    "faId"
                )
                .orEmpty()

        if (
            nextId.isBlank()
        ) {
            return
        }

        context
            .getSharedPreferences(
                PREFS,
                Context.MODE_PRIVATE
            )
            .edit()
            .putString(
                KEY_SELECTED_FA,
                nextId
            )
            .putInt(
                KEY_POSITION,
                0
            )
            .putString(
                KEY_SELECTED_DATE,
                currentDateString()
            )
            .putString(
                KEY_DAY_MODE,
                DAY_MODE_TODAY
            )
            .apply()
    }


    fun selectedPosition(
        context: Context,
        positionCount: Int
    ): Int {

        if (
            positionCount <= 0
        ) {
            return 0
        }

        val raw =
            context
                .getSharedPreferences(
                    PREFS,
                    Context.MODE_PRIVATE
                )
                .getInt(
                    KEY_POSITION,
                    0
                )

        return raw.coerceIn(
            0,
            positionCount - 1
        )
    }


    fun nextPosition(
        context: Context,
        positionCount: Int
    ) {

        if (
            positionCount <= 1
        ) {
            return
        }

        val next =
            (
                selectedPosition(
                    context,
                    positionCount
                ) +
                1
            ) %
            positionCount

        context
            .getSharedPreferences(
                PREFS,
                Context.MODE_PRIVATE
            )
            .edit()
            .putInt(
                KEY_POSITION,
                next
            )
            .apply()
    }


    fun adjustPlates(
        context: Context,
        delta: Int
    ): Boolean {

        val root =
            rootObject(
                context
            )

        val fa =
            selectedFaFromRoot(
                context,
                root
            )
                ?: return false

        val current =
            fa.optInt(
                "plates",
                0
            )

        val updated =
            (current + delta)
                .coerceAtLeast(
                    0
                )

        if (
            updated == current
        ) {
            return false
        }

        fa.put(
            "plates",
            updated
        )

        val positions =
            fa.optJSONArray(
                "positions"
            )

        if (
            positions != null
        ) {

            for (
                index in
                0 until positions.length()
            ) {

                val position =
                    positions.optJSONObject(
                        index
                    )
                        ?: continue

                val partsPerPlate =
                    position.optInt(
                        "partsPerPlate",
                        0
                    )

                if (
                    partsPerPlate > 0
                ) {

                    val quantity =
                        updated *
                        partsPerPlate

                    position.put(
                        "quantity",
                        quantity
                    )

                    if (
                        position.optInt(
                            "scrap",
                            0
                        ) >
                        quantity
                    ) {

                        position.put(
                            "scrap",
                            quantity
                        )
                    }
                }
            }
        }

        saveRoot(
            context,
            root
        )

        return true
    }


    fun adjustScrap(
        context: Context,
        positionIndex: Int,
        delta: Int
    ): Boolean {

        val root =
            rootObject(
                context
            )

        val fa =
            selectedFaFromRoot(
                context,
                root
            )
                ?: return false

        val positions =
            fa.optJSONArray(
                "positions"
            )
                ?: return false

        if (
            positionIndex !in
            0 until positions.length()
        ) {
            return false
        }

        val position =
            positions.optJSONObject(
                positionIndex
            )
                ?: return false

        val current =
            position.optInt(
                "scrap",
                0
            )

        val maxValue =
            position.optInt(
                "quantity",
                Int.MAX_VALUE
            )
                .coerceAtLeast(
                    0
                )

        val updated =
            (current + delta)
                .coerceIn(
                    0,
                    maxValue
                )

        if (
            updated == current
        ) {
            return false
        }

        position.put(
            "scrap",
            updated
        )

        saveRoot(
            context,
            root
        )

        return true
    }


    fun adjustQuantity(
        context: Context,
        positionIndex: Int,
        delta: Int
    ): Boolean {

        val root =
            rootObject(
                context
            )

        val fa =
            selectedFaFromRoot(
                context,
                root
            )
                ?: return false

        val positions =
            fa.optJSONArray(
                "positions"
            )
                ?: return false

        if (
            positionIndex !in
            0 until positions.length()
        ) {
            return false
        }

        val position =
            positions.optJSONObject(
                positionIndex
            )
                ?: return false

        val current =
            position.optInt(
                "quantity",
                0
            )

        // Overproduction is allowed. The watch quantity must therefore
        // move by the full requested delta and is only clamped at zero.
        val updated =
            (current + delta)
                .coerceAtLeast(0)

        if (
            updated == current
        ) {
            return false
        }

        val processedBefore =
            position.optInt(
                "processedBefore",
                0
            )
                .coerceAtLeast(
                    0
                )

        val target =
            position.optInt(
                "target",
                0
            )
                .coerceAtLeast(
                    0
                )

        position.put(
            "quantity",
            updated
        )

        position.put(
            "processedTotal",
            processedBefore +
            updated
        )

        position.put(
            "remaining",
            (target -
            processedBefore -
            updated)
                .coerceAtLeast(
                    0
                )
        )

        if (
            position.optInt(
                "scrap",
                0
            ) >
            updated
        ) {

            position.put(
                "scrap",
                updated
            )
        }

        saveRoot(
            context,
            root
        )

        return true
    }


    fun timerState(
        context: Context
    ): String {

        if (
            !isTodaySelected(
                context
            )
        ) {
            return "stopped"
        }

        return selectedFa(
            context
        )
            ?.optString(
                "timerState",
                "stopped"
            )
            ?: "stopped"
    }


    fun applyTimerAction(
        context: Context,
        eventType: String,
        timestamp: Long =
            System.currentTimeMillis()
    ): Boolean {

        /* Timer darf nur auf dem heutigen Arbeitstag laufen. */
        if (
            !isTodaySelected(
                context
            )
        ) {
            return false
        }

        val root =
            rootObject(
                context
            )

        val fa =
            selectedFaFromRoot(
                context,
                root
            )
                ?: return false

        val state =
            fa.optString(
                "timerState",
                "stopped"
            )

        var closedMinutes =
            fa.optInt(
                "timerClosedMinutes",
                0
            )
                .coerceAtLeast(
                    0
                )

        val runningSince =
            fa.optLong(
                "runningSince",
                0L
            )

        fun closeRunningBlock() {

            if (
                state == "running" &&
                runningSince > 0L
            ) {

                closedMinutes +=
                    ((timestamp - runningSince)
                        .coerceAtLeast(
                            0L
                        ) /
                    60000L)
                        .toInt()
            }
        }

        when (eventType) {

            "timer_start" -> {

                if (
                    state == "running"
                ) {
                    return false
                }

                fa.put(
                    "timerState",
                    "running"
                )

                fa.put(
                    "runningSince",
                    timestamp
                )
            }

            "timer_pause" -> {

                if (
                    state != "running"
                ) {
                    return false
                }

                closeRunningBlock()

                fa.put(
                    "timerClosedMinutes",
                    closedMinutes
                )

                fa.put(
                    "timerState",
                    "paused"
                )

                fa.put(
                    "runningSince",
                    JSONObject.NULL
                )
            }

            "timer_stop" -> {

                if (
                    state == "stopped"
                ) {
                    return false
                }

                closeRunningBlock()

                fa.put(
                    "timerClosedMinutes",
                    closedMinutes
                )

                fa.put(
                    "timerState",
                    "stopped"
                )

                fa.put(
                    "runningSince",
                    JSONObject.NULL
                )
            }

            else ->
                return false
        }

        saveRoot(
            context,
            root
        )

        return true
    }


    fun addPending(
        context: Context,
        eventId: String,
        type: String
    ) {

        val pending =
            pendingArray(
                context
            )

        pending.put(
            JSONObject()
                .put(
                    "eventId",
                    eventId
                )
                .put(
                    "type",
                    type
                )
        )

        savePending(
            context,
            pending
        )
    }


    fun acknowledge(
        context: Context,
        ids: Set<String>
    ) {

        if (
            ids.isEmpty()
        ) {
            return
        }

        val old =
            pendingArray(
                context
            )

        val fresh =
            JSONArray()

        for (
            index in
            0 until old.length()
        ) {

            val item =
                old.optJSONObject(
                    index
                )
                    ?: continue

            if (
                !ids.contains(
                    item.optString(
                        "eventId"
                    )
                )
            ) {

                fresh.put(
                    item
                )
            }
        }

        savePending(
            context,
            fresh
        )
    }


    fun pendingCount(
        context: Context
    ): Int {

        return pendingArray(
            context
        ).length()
    }


    private fun selectedDateForContainer(
        context: Context,
        container: JSONObject
    ): String {

        val prefs =
            context.getSharedPreferences(
                PREFS,
                Context.MODE_PRIVATE
            )

        val mode =
            prefs.getString(
                KEY_DAY_MODE,
                DAY_MODE_TODAY
            ) ?: DAY_MODE_TODAY

        val today =
            currentDateString()

        if (
            mode != DAY_MODE_MANUAL
        ) {
            return today
        }

        val stored =
            prefs.getString(
                KEY_SELECTED_DATE,
                ""
            ).orEmpty()

        val days =
            container.optJSONArray(
                "days"
            )

        if (
            days != null
        ) {

            for (
                index in
                0 until days.length()
            ) {

                if (
                    days
                        .optJSONObject(
                            index
                        )
                        ?.optString(
                            "date"
                        ) == stored
                ) {
                    return stored
                }
            }
        }

        context
            .getSharedPreferences(
                PREFS,
                Context.MODE_PRIVATE
            )
            .edit()
            .putString(
                KEY_SELECTED_DATE,
                today
            )
            .putString(
                KEY_DAY_MODE,
                DAY_MODE_TODAY
            )
            .apply()

        return today
    }


    private fun selectedDayFromContainer(
        context: Context,
        container: JSONObject
    ): JSONObject {

        val days =
            container.optJSONArray(
                "days"
            )

        if (
            days == null ||
            days.length() == 0
        ) {
            return container
        }

        val wanted =
            selectedDateForContainer(
                context,
                container
            )

        for (
            index in
            0 until days.length()
        ) {

            val day =
                days.optJSONObject(
                    index
                )
                    ?: continue

            if (
                day.optString(
                    "date"
                ) == wanted
            ) {
                return day
            }
        }

        return days.optJSONObject(
            0
        ) ?: container
    }


    private fun rootObject(
        context: Context
    ): JSONObject {

        return runCatching {
            JSONObject(
                contextJson(
                    context
                )
            )
        }.getOrElse {
            JSONObject()
        }
    }


    private fun selectedFaId(
        context: Context,
        root: JSONObject
    ): String {

        val stored =
            context
                .getSharedPreferences(
                    PREFS,
                    Context.MODE_PRIVATE
                )
                .getString(
                    KEY_SELECTED_FA,
                    ""
                )
                .orEmpty()

        if (
            stored.isNotBlank()
        ) {
            return stored
        }

        return root.optString(
            "activeFaId",
            root.optString(
                "faId",
                ""
            )
        )
    }


    private fun selectedFaContainerFromRoot(
        context: Context,
        root: JSONObject
    ): JSONObject? {

        val fas =
            root.optJSONArray(
                "fas"
            )

        if (
            fas != null &&
            fas.length() > 0
        ) {

            val selectedId =
                selectedFaId(
                    context,
                    root
                )

            for (
                index in
                0 until fas.length()
            ) {

                val item =
                    fas.optJSONObject(
                        index
                    )
                        ?: continue

                if (
                    item.optString(
                        "faId"
                    ) == selectedId
                ) {
                    return item
                }
            }

            return fas.optJSONObject(
                0
            )
        }

        return if (
            root.optBoolean(
                "active",
                false
            )
        ) {
            root
        }
        else {
            null
        }
    }


    private fun selectedFaFromRoot(
        context: Context,
        root: JSONObject
    ): JSONObject? {

        val container =
            selectedFaContainerFromRoot(
                context,
                root
            )
                ?: return null

        return selectedDayFromContainer(
            context,
            container
        )
    }


    private fun ensureSelectedFa(
        context: Context
    ) {

        val root =
            rootObject(
                context
            )

        val fas =
            root.optJSONArray(
                "fas"
            )
                ?: return

        if (
            fas.length() <= 0
        ) {
            return
        }

        val currentId =
            selectedFaId(
                context,
                root
            )

        var exists =
            false

        for (
            index in
            0 until fas.length()
        ) {

            if (
                fas
                    .optJSONObject(
                        index
                    )
                    ?.optString(
                        "faId"
                    ) ==
                currentId
            ) {

                exists =
                    true

                break
            }
        }

        if (
            exists
        ) {
            return
        }

        val preferredId =
            root.optString(
                "activeFaId",
                fas
                    .optJSONObject(
                        0
                    )
                    ?.optString(
                        "faId"
                    )
                    .orEmpty()
            )

        context
            .getSharedPreferences(
                PREFS,
                Context.MODE_PRIVATE
            )
            .edit()
            .putString(
                KEY_SELECTED_FA,
                preferredId
            )
            .putInt(
                KEY_POSITION,
                0
            )
            .putString(
                KEY_SELECTED_DATE,
                currentDateString()
            )
            .putString(
                KEY_DAY_MODE,
                DAY_MODE_TODAY
            )
            .apply()
    }


    private fun ensureSelectedDay(
        context: Context
    ) {

        val root =
            rootObject(
                context
            )

        val container =
            selectedFaContainerFromRoot(
                context,
                root
            )
                ?: return

        selectedDateForContainer(
            context,
            container
        )
    }


    private fun clampSelectedPosition(
        context: Context
    ) {

        val fa =
            selectedFa(
                context
            )
                ?: return

        val count =
            fa
                .optJSONArray(
                    "positions"
                )
                ?.length()
                ?: 0

        if (
            count <= 0
        ) {
            return
        }

        val current =
            selectedPosition(
                context,
                count
            )

        context
            .getSharedPreferences(
                PREFS,
                Context.MODE_PRIVATE
            )
            .edit()
            .putInt(
                KEY_POSITION,
                current
            )
            .apply()
    }


    private fun saveRoot(
        context: Context,
        root: JSONObject
    ) {

        context
            .getSharedPreferences(
                PREFS,
                Context.MODE_PRIVATE
            )
            .edit()
            .putString(
                KEY_CONTEXT,
                root.toString()
            )
            .apply()
    }


    private fun pendingArray(
        context: Context
    ): JSONArray {

        val raw =
            context
                .getSharedPreferences(
                    PREFS,
                    Context.MODE_PRIVATE
                )
                .getString(
                    KEY_PENDING,
                    "[]"
                )
                .orEmpty()

        return runCatching {
            JSONArray(
                raw
            )
        }.getOrElse {
            JSONArray()
        }
    }


    private fun savePending(
        context: Context,
        array: JSONArray
    ) {

        context
            .getSharedPreferences(
                PREFS,
                Context.MODE_PRIVATE
            )
            .edit()
            .putString(
                KEY_PENDING,
                array.toString()
            )
            .apply()
    }
}
