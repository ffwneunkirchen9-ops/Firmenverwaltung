package de.fa.fertigung.wear

import androidx.wear.tiles.TileService
import com.google.android.gms.wearable.DataEvent
import com.google.android.gms.wearable.DataEventBuffer
import com.google.android.gms.wearable.DataMapItem
import com.google.android.gms.wearable.WearableListenerService

class PhoneDataListenerService :
    WearableListenerService() {

    override fun onDataChanged(
        dataEvents: DataEventBuffer
    ) {
        var changed =
            false

        dataEvents.forEach {
            event ->

            if (
                event.type !=
                DataEvent.TYPE_CHANGED
            ) {
                return@forEach
            }

            val item =
                event.dataItem

            val path =
                item.uri.path
                    .orEmpty()

            val map =
                runCatching {
                    DataMapItem
                        .fromDataItem(
                            item
                        )
                        .dataMap
                }.getOrNull()
                    ?: return@forEach

            when (path) {

                WatchDataSync.CONTEXT_PATH -> {
                    val json =
                        map.getString(
                            "json"
                        )
                            .orEmpty()

                    if (
                        json.isNotBlank() &&
                        WatchStateStore.pendingCount(
                            this
                        ) == 0
                    ) {
                        WatchStateStore
                            .saveContext(
                                this,
                                json
                            )

                        changed =
                            true
                    }
                }

                WatchDataSync.ACK_PATH -> {
                    val ids =
                        map.getStringArrayList(
                            "eventIds"
                        )
                            ?.toSet()
                            ?: emptySet()

                    WatchStateStore
                        .acknowledge(
                            this,
                            ids
                        )

                    /*
                     * FIX47:
                     * Das Handy kann den bereits korrigierten Tagesstand
                     * (z. B. 731/741) veröffentlicht haben, während auf der
                     * Uhr das gerade gesendete +10 noch als pending galt.
                     * Dieses Kontext-Update wurde absichtlich nicht direkt
                     * übernommen. Sobald die Bestätigung da ist, lesen wir
                     * den aktuellen Handy-Kontext deshalb noch einmal aus
                     * dem Data-Layer ein.
                     */
                    if (
                        WatchStateStore
                            .pendingCount(
                                this
                            ) == 0
                    ) {

                        WatchDataSync
                            .refreshContextFromDataLayer(
                                this
                            ) {

                                TileService
                                    .getUpdater(
                                        this
                                    )
                                    .requestUpdate(
                                        FaCounterTileService::class.java
                                    )
                            }
                    }

                    changed =
                        true
                }
            }
        }

        if (changed) {
            TileService
                .getUpdater(
                    this
                )
                .requestUpdate(
                    FaCounterTileService::class.java
                )
        }
    }
}
