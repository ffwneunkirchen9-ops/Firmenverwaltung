# FA Fertigung FIX41

Rückbau auf das frühe, übersichtliche Wear-OS-Kachel-Layout.

- Schneiden: FA oben, Arbeitsgang + FA-Wechsel, Platten, Ausschuss, Timer.
- Entgraten: FA oben, Arbeitsgang + FA-Wechsel, Tagesmenge, -10/+10, Timer.
- Bestehende Sync-, Mehrfach-FA- und Timerlogik bleibt erhalten.
- Für -10 wird das bereits eingeführte `quantity_minus_10`-Event verwendet.

Für FIX41 nur Watch-Projekt und script.html aus diesem Stand verwenden.
