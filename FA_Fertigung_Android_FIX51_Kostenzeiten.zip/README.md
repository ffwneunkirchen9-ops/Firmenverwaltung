FA Fertigung FIX51: Kostenzeiten & Stillstände.

Basiert auf FIX50.3 (Einrichtepläne-Rettung). Umbenennung aus FIX50.4 ist zurückgestellt.
Neue Android-Klassen unter app/src/main/java/de/fa/fertigung/costs und Wear unter wear/src/main/java/de/fa/fertigung/wear/CostWatchStore.kt.
Der bestehende Speicherschlüssel faFertigung_v2 wird durch diese Erweiterung nicht geändert.
Kotlin/Gradle-Build muss in GitHub Actions geprüft werden.
Vollständige Einbauanleitung separat beigefügt.
