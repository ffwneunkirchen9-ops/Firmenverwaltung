# FA Fertigung FIX37

Wear-OS-Kachel mit großem, übersichtlichem Layout.

## Wichtig
- Handy-App und `script.html` müssen für FIX37 nicht geändert werden.
- Für den Test nur die WATCH-App neu bauen/installieren.
- Beim Entgraten zeigt die große Zahl die Stückzahl des aktuellen Tages.
- FA-Wechsel bleibt über `⇄` verfügbar.

## Build
Der passende GitHub-Actions-Workflow heißt `android-build-FA-FIX37-WEAR.yml`.
