package de.fa.fertigung.wear

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.wear.tiles.TileService
import org.json.JSONObject

class TileActionReceiver :
    BroadcastReceiver() {

    override fun onReceive(
        context: Context,
        intent: Intent
    ) {

        handleAction(
            context,
            intent.action.orEmpty(),
            true
        )
    }


    companion object {

        const val ACTION_PLATE_PLUS =
            "de.fa.fertigung.wear.PLATE_PLUS"

        const val ACTION_PLATE_MINUS =
            "de.fa.fertigung.wear.PLATE_MINUS"

        const val ACTION_SCRAP_PLUS =
            "de.fa.fertigung.wear.SCRAP_PLUS"

        const val ACTION_SCRAP_MINUS =
            "de.fa.fertigung.wear.SCRAP_MINUS"

        const val ACTION_QUANTITY_MINUS_1 =
            "de.fa.fertigung.wear.QUANTITY_MINUS_1"

        const val ACTION_QUANTITY_PLUS_1 =
            "de.fa.fertigung.wear.QUANTITY_PLUS_1"

        const val ACTION_QUANTITY_PLUS_10 =
            "de.fa.fertigung.wear.QUANTITY_PLUS_10"

        const val ACTION_TIMER_TOGGLE =
            "de.fa.fertigung.wear.TIMER_TOGGLE"

        const val ACTION_TIMER_STOP =
            "de.fa.fertigung.wear.TIMER_STOP"

        const val ACTION_NEXT_FA =
            "de.fa.fertigung.wear.NEXT_FA"

        const val ACTION_NEXT_POSITION =
            "de.fa.fertigung.wear.NEXT_POSITION"

        const val ACTION_NOOP =
            "de.fa.fertigung.wear.NOOP"


        fun handleAction(
            context: Context,
            action: String,
            requestTileUpdate: Boolean = true
        ) {

            val fa =
                WatchStateStore
                    .selectedFa(
                        context
                    )

            val positions =
                fa?.optJSONArray(
                    "positions"
                )

            val positionCount =
                positions?.length()
                    ?: 0

            val selected =
                WatchStateStore
                    .selectedPosition(
                        context,
                        positionCount
                    )

            when (action) {

                ACTION_PLATE_PLUS -> {

                    if (
                        fa?.optBoolean(
                            "canAddPlates",
                            false
                        ) == true &&
                        WatchStateStore.adjustPlates(
                            context,
                            1
                        )
                    ) {

                        WatchDataSync.sendEvent(
                            context,
                            "plate_plus",
                            selected
                        )

                        vibrate(context)
                    }
                }

                ACTION_PLATE_MINUS -> {

                    if (
                        fa?.optBoolean(
                            "canAddPlates",
                            false
                        ) == true &&
                        WatchStateStore.adjustPlates(
                            context,
                            -1
                        )
                    ) {

                        WatchDataSync.sendEvent(
                            context,
                            "plate_minus",
                            selected
                        )

                        vibrate(context)
                    }
                }

                ACTION_SCRAP_PLUS -> {

                    if (
                        positionCount > 0 &&
                        WatchStateStore.adjustScrap(
                            context,
                            selected,
                            1
                        )
                    ) {

                        WatchDataSync.sendEvent(
                            context,
                            "scrap_plus",
                            selected
                        )

                        vibrate(context)
                    }
                }

                ACTION_SCRAP_MINUS -> {

                    if (
                        positionCount > 0 &&
                        WatchStateStore.adjustScrap(
                            context,
                            selected,
                            -1
                        )
                    ) {

                        WatchDataSync.sendEvent(
                            context,
                            "scrap_minus",
                            selected
                        )

                        vibrate(context)
                    }
                }

                ACTION_QUANTITY_MINUS_1 -> {

                    if (
                        positionCount > 0 &&
                        WatchStateStore.adjustQuantity(
                            context,
                            selected,
                            -1
                        )
                    ) {

                        WatchDataSync.sendEvent(
                            context,
                            "quantity_minus_1",
                            selected
                        )

                        vibrate(context)
                    }
                }

                ACTION_QUANTITY_PLUS_1 -> {

                    if (
                        positionCount > 0 &&
                        WatchStateStore.adjustQuantity(
                            context,
                            selected,
                            1
                        )
                    ) {

                        WatchDataSync.sendEvent(
                            context,
                            "quantity_plus_1",
                            selected
                        )

                        vibrate(context)
                    }
                }

                ACTION_QUANTITY_PLUS_10 -> {

                    if (
                        positionCount > 0 &&
                        WatchStateStore.adjustQuantity(
                            context,
                            selected,
                            10
                        )
                    ) {

                        WatchDataSync.sendEvent(
                            context,
                            "quantity_plus_10",
                            selected
                        )

                        vibrate(context)
                    }
                }

                ACTION_TIMER_TOGGLE -> {

                    val state =
                        WatchStateStore.timerState(
                            context
                        )

                    val eventType =
                        if (
                            state == "running"
                        ) {
                            "timer_pause"
                        }
                        else {
                            "timer_start"
                        }

                    val timestamp =
                        System.currentTimeMillis()

                    if (
                        WatchStateStore.applyTimerAction(
                            context,
                            eventType,
                            timestamp
                        )
                    ) {

                        WatchDataSync.sendEvent(
                            context,
                            eventType,
                            selected
                        )

                        vibrate(context)
                    }
                }

                ACTION_TIMER_STOP -> {

                    val timestamp =
                        System.currentTimeMillis()

                    if (
                        WatchStateStore.applyTimerAction(
                            context,
                            "timer_stop",
                            timestamp
                        )
                    ) {

                        WatchDataSync.sendEvent(
                            context,
                            "timer_stop",
                            selected
                        )

                        vibrate(context)
                    }
                }

                ACTION_NEXT_FA -> {

                    WatchStateStore.nextFa(
                        context
                    )

                    vibrate(context)
                }

                ACTION_NEXT_POSITION -> {

                    WatchStateStore.nextPosition(
                        context,
                        positionCount
                    )

                    vibrate(context)
                }

                ACTION_NOOP -> {
                    // reine Anzeige
                }
            }

            if (
                requestTileUpdate
            ) {

                TileService
                    .getUpdater(
                        context
                    )
                    .requestUpdate(
                        FaCounterTileService::class.java
                    )
            }
        }


        private fun vibrate(
            context: Context
        ) {

            runCatching {

                val effect =
                    VibrationEffect.createOneShot(
                        35L,
                        VibrationEffect.DEFAULT_AMPLITUDE
                    )

                if (
                    Build.VERSION.SDK_INT >=
                    Build.VERSION_CODES.S
                ) {

                    context
                        .getSystemService(
                            VibratorManager::class.java
                        )
                        ?.defaultVibrator
                        ?.vibrate(effect)
                }
                else {

                    @Suppress("DEPRECATION")
                    val vibrator =
                        context.getSystemService(
                            Context.VIBRATOR_SERVICE
                        ) as? Vibrator

                    vibrator?.vibrate(
                        effect
                    )
                }
            }
        }
    }
}
