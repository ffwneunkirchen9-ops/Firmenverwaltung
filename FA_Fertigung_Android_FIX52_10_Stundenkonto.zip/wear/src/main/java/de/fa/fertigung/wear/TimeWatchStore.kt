package de.fa.fertigung.wear

import android.content.Context
import com.google.android.gms.wearable.DataMapItem
import com.google.android.gms.wearable.PutDataMapRequest
import com.google.android.gms.wearable.Wearable
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** FIX52: Unabhängige Uhr-Arbeitszeiterfassung mit Offline-Warteschlange. */
object TimeWatchStore {
    private const val PREF = "fa_work_watch_52"
    private fun pref(c:Context)=c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
    private fun pending(c:Context)=runCatching{JSONArray(pref(c).getString("pending","[]"))}.getOrDefault(JSONArray())
    private fun send(c:Context,event:JSONObject){
        val id=event.optString("eventId")
        val req=PutDataMapRequest.create("/fa/watch/event/$id")
        req.dataMap.putString("eventId",id)
        req.dataMap.putString("type",event.optString("type"))
        req.dataMap.putString("faId", "")
        req.dataMap.putLong("timestamp",event.optLong("timestamp"))
        Wearable.getDataClient(c).putDataItem(req.asPutDataRequest().setUrgent())
    }
    private fun add(c:Context,type:String,at:Long){
        val id=UUID.randomUUID().toString()
        val event=JSONObject().put("eventId",id).put("type",type).put("timestamp",at)
        val arr=pending(c);arr.put(event)
        // ZUERST dauerhaft speichern, DANACH übertragen.
        pref(c).edit().putString("pending",arr.toString()).commit()
        send(c,event)
    }
    fun refreshPending(c:Context){val arr=pending(c);for(i in 0 until arr.length())arr.optJSONObject(i)?.let{send(c,it)}}
    fun acknowledge(c: Context, ids: Set<String>) {
        if (ids.isEmpty()) return

        val rows = pending(c)
        val left = JSONArray()
        for (i in 0 until rows.length()) {
            val event = rows.optJSONObject(i) ?: continue
            if (event.optString("eventId") !in ids) {
                left.put(event)
            }
        }
        pref(c).edit().putString("pending", left.toString()).commit()
        if(left.length()==0) pref(c).getString("deferredPhoneState",null)?.let { receivePhoneState(c,it) }
    }
    // Read the retained phone DataItem even when no new change event arrives.
    fun refreshPhoneState(c: Context, onUpdated: (() -> Unit)? = null) {
        Wearable.getDataClient(c).dataItems.addOnSuccessListener { buffer ->
            var newest: String? = null
            var newestAt = Long.MIN_VALUE
            try {
                for (i in 0 until buffer.count) {
                    val item = buffer.get(i)
                    if (item.uri.path != "/fa/watch/worktime") continue
                    val map = runCatching { DataMapItem.fromDataItem(item).dataMap }.getOrNull() ?: continue
                    val json = map.getString("json").orEmpty()
                    val at = map.getLong("updatedAt", 0L)
                    if (json.isNotBlank() && at >= newestAt) { newest = json; newestAt = at }
                }
            } finally { buffer.release() }
            newest?.let { receivePhoneState(c, it) }
            onUpdated?.invoke()
        }
    }
    fun balanceMinutes(c:Context): Long? = if(pref(c).contains("balanceMinutes")) pref(c).getLong("balanceMinutes",0L) else null
    fun isWorking(c:Context)=pref(c).getBoolean("working",false)
    fun started(c:Context)=pref(c).getLong("started",0L)
    fun pendingCount(c:Context)=pending(c).length()
    fun clockIn(c:Context):Boolean {if(isWorking(c))return false;val t=System.currentTimeMillis();pref(c).edit().putBoolean("working",true).putLong("started",t).commit();add(c,"time_in",t);return true}
    fun clockOut(c:Context):Boolean {if(!isWorking(c))return false;val t=System.currentTimeMillis();pref(c).edit().putBoolean("working",false).commit();SmokeReminder.schedule(c,0L);pref(c).edit().remove("smokeStartedAt").commit();add(c,"time_out",t);return true}
    /** FIX52.2: Countdown der bereits gebuchten, exakt zehnminütigen Raucherpause.
     * Kein Hintergrundtimer nötig: Das Ende wird aus dem dauerhaft gespeicherten
     * Startzeitpunkt berechnet, auch nach Display-Aus oder App-Neustart.
     * Der bestehende time_smoke-Uhr-Event und die Handy-Berechnung bleiben unverändert.
     */
    private const val SMOKE_DURATION_MS = 10L * 60L * 1000L

    fun smokeRemainingMillis(c: Context): Long {
        val startedAt = pref(c).getLong("smokeStartedAt", 0L)
        if (startedAt <= 0L) return 0L
        val elapsed = System.currentTimeMillis() - startedAt
        if (elapsed < 0L || elapsed >= SMOKE_DURATION_MS) return 0L
        return SMOKE_DURATION_MS - elapsed
    }

    fun smoke(c: Context): Boolean {
        if (!isWorking(c) || smokeRemainingMillis(c) > 0L) return false
        val startedAt = System.currentTimeMillis()
        // Startzeit erst sicher auf der Uhr speichern, dann das bekannte Event buchen.
        if (!pref(c).edit().putLong("smokeStartedAt", startedAt).commit()) return false
        SmokeReminder.schedule(c, startedAt)
        add(c, "time_smoke", startedAt)
        return true
    }
    fun receivePhoneState(c:Context,json:String){
        val state=runCatching{JSONObject(json)}.getOrNull()?:return
        if(state.has("balanceMinutes") && !state.isNull("balanceMinutes")) {
            val value = state.optString("balanceMinutes").toLongOrNull()
            if (value != null) pref(c).edit().putLong("balanceMinutes",value).commit()
        }
        if(pendingCount(c)>0) { pref(c).edit().putString("deferredPhoneState",json).commit(); return }
        val smoke=if(state.optBoolean("active")) state.optLong("smokeStartedAt") else 0L
        pref(c).edit().putBoolean("working",state.optBoolean("active")).putLong("started",state.optLong("started")).putLong("smokeStartedAt",smoke).remove("deferredPhoneState").commit()
        SmokeReminder.schedule(c,smoke)
    }
}
