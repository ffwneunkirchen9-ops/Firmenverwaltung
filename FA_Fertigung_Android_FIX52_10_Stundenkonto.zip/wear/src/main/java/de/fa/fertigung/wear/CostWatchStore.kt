package de.fa.fertigung.wear

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import com.google.android.gms.wearable.PutDataMapRequest
import com.google.android.gms.wearable.Wearable
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** FIX51: Offline-first cost times on Wear OS; unrelated to existing FA counters. */
object CostWatchStore {
    private const val PREFS="fa_cost_watch_51"
    private val defaults=listOf("Maschinenstillstand", "Wartung / Reparatur", "Betriebsversammlung", "Materialmangel", "Werkzeug fehlt", "Sonstiges")
    private fun preferences(c:Context)=c.getSharedPreferences(PREFS,Context.MODE_PRIVATE)
    private fun timers(c:Context):JSONArray = runCatching { JSONArray(preferences(c).getString("timers", "[]")) }.getOrDefault(JSONArray())
    private fun reasons(c:Context):JSONArray = runCatching { JSONArray(preferences(c).getString("reasons","[]")) }.getOrDefault(JSONArray())
    fun saveReasons(c:Context, json:String){
        if(runCatching{JSONArray(json)}.isSuccess)preferences(c).edit().putString("reasons",json).apply()
    }
    private fun send(c:Context,item:JSONObject,action:String){
        val id=UUID.randomUUID().toString()
        val req=PutDataMapRequest.create("/fa/watch/event/$id")
        req.dataMap.putString("eventId",id)
        req.dataMap.putString("type","cost_$action")
        req.dataMap.putString("faId", "")
        req.dataMap.putString("costId",item.optString("id"))
        req.dataMap.putString("reasonId",item.optString("reasonId"))
        req.dataMap.putString("reasonName",item.optString("name"))
        req.dataMap.putLong("timestamp",System.currentTimeMillis())
        // DataItems survive loss of connection and remain pending until phone ACK.
        Wearable.getDataClient(c).putDataItem(req.asPutDataRequest().setUrgent())
    }
    private fun persist(c:Context,arr:JSONArray){preferences(c).edit().putString("timers",arr.toString()).commit()}
    private fun start(c:Context,reasonId:String,name:String){
        val item=JSONObject().put("id",UUID.randomUUID().toString()).put("reasonId",reasonId)
            .put("name",name).put("state","running").put("startedAt",System.currentTimeMillis())
        val arr=timers(c);arr.put(item);persist(c,arr);send(c,item,"start")
    }
    private fun change(c:Context,id:String,action:String){
        val arr=timers(c);for(i in 0 until arr.length()){
            val t=arr.optJSONObject(i)?:continue
            if(t.optString("id")!=id)continue
            t.put("state",when(action){"pause"->"paused";"resume"->"running";else->"stopped"})
            persist(c,arr);send(c,t,action);return
        }
    }
    fun showMenu(activity:Activity){
        val list=timers(activity)
        val ongoing=(0 until list.length()).mapNotNull{list.optJSONObject(it)}.filter{it.optString("state")!="stopped"}
        val labels=ArrayList<String>();val actions=ArrayList<()->Unit>()
        ongoing.forEach { t ->
            val running=t.optString("state")=="running"
            labels.add((if(running)"⏸" else "▶")+" ${t.optString("name")}")
            actions.add { change(activity,t.optString("id"),if(running)"pause" else "resume") }
            labels.add("⏹ Stoppen: ${t.optString("name")}")
            actions.add {
                AlertDialog.Builder(activity).setMessage("Kostenzeit wirklich beenden?")
                    .setPositiveButton("Stopp"){_,_->change(activity,t.optString("id"),"stop")}
                    .setNegativeButton("Abbrechen",null).show()
            }
        }
        labels.add("＋ Neue Kostenzeit starten");actions.add { showReasons(activity) }
        AlertDialog.Builder(activity).setTitle("Kostenzeiten & Stillstände")
            .setItems(labels.toTypedArray()){_,which->actions.getOrNull(which)?.invoke()}
            .setNegativeButton("Schließen",null).show()
    }
    private fun showReasons(activity:Activity){
        val incoming=reasons(activity)
        val rs=if(incoming.length()>0)(0 until incoming.length()).mapNotNull { incoming.optJSONObject(it) }
          else defaults.map { JSONObject().put("id","").put("name",it) }
        AlertDialog.Builder(activity).setTitle("Grund auswählen")
            .setItems(rs.map{it.optString("name")}.toTypedArray()){_,which ->
                val r=rs[which];start(activity,r.optString("id"),r.optString("name"))
            }.setNegativeButton("Abbrechen",null).show()
    }
}
