FA Fertigung FIX52.2 · Galaxy Watch Countdown

Basis: funktionierende FIX52.1. Die bestehende Handy-App wird NICHT geändert.

Neu: Im bisherigen Raucherpause-Button des Uhr-Bereichs „Zeit“ wird nach
dem Start die verbleibende Zeit 10:00 bis 00:00 live angezeigt.
Nach Ablauf zeigt der Button wieder „Raucherpause 10 Min.“.
Bei ausgeschaltetem Display/Verlassen der Uhr-App wird der gespeicherte
Startzeitpunkt weiter berücksichtigt und beim Öffnen korrekt angezeigt.
Während der aktiven Raucherpause wird mehrfaches Antippen nicht erneut
gebucht. Bestehende FA-Timer und der FA-Bereich bleiben unverändert.

Nur geändert:
 - wear/src/main/java/de/fa/fertigung/wear/TimeWatchStore.kt
 - wear/src/main/java/de/fa/fertigung/wear/WearMainActivity.kt
 - wear/build.gradle.kts (Versionstext)

Wichtig: Die Uhr-App als Update installieren. Handy-App nicht deinstallieren.
