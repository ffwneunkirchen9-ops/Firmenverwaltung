package de.fa.fertigung.costs

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max

/** Foreground service: active cost timers are based on persisted wall-clock timestamps. */
class CostTimerService : Service() {
    companion object {
        const val ACTION_SYNC = "de.fa.fertigung.costs.SYNC"
        const val ACTION_PAUSE = "de.fa.fertigung.costs.PAUSE"
        const val ACTION_RESUME = "de.fa.fertigung.costs.RESUME"
        const val EXTRA_TIMERS = "cost_timers_json"
        const val EXTRA_ID = "cost_entry_id"
        val ACTION_LOCK = Any()
        private const val CHANNEL = "fa_cost_timers_51"
        private const val NOTIFICATION = 51051
    }
    private var timers=JSONArray()
    private val handler=Handler(Looper.getMainLooper())
    private var foreground=false
    private val refresher=object:Runnable {
        override fun run() {
            if(foreground) {
                showNotification()
                handler.postDelayed(this, 60000)
            }
        }
    }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() {
        super.onCreate()
        if(Build.VERSION.SDK_INT>=26){
            val manager=getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(CHANNEL,"FA Kostenzeiten",NotificationManager.IMPORTANCE_LOW))
        }
    }
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int {
        val prefs=getSharedPreferences("fa_cost_native_51",Context.MODE_PRIVATE)
        when(intent?.action){
            ACTION_SYNC -> {
                val incoming=intent.getStringExtra(EXTRA_TIMERS) ?: "[]"
                timers=runCatching {JSONArray(incoming)}.getOrDefault(JSONArray())
                prefs.edit().putString("timers",timers.toString()).apply()
            }
            ACTION_PAUSE, ACTION_RESUME -> {
                timers=runCatching {JSONArray(prefs.getString("timers","[]"))}.getOrDefault(JSONArray())
                val id=intent.getStringExtra(EXTRA_ID).orEmpty()
                val action=if(intent.action==ACTION_PAUSE)"pause" else "resume"
                for(i in 0 until timers.length()){
                    val item=timers.optJSONObject(i)?:continue
                    if(item.optString("id")==id){
                        item.put("state",if(action=="pause")"paused" else "running")
                        item.put("since",System.currentTimeMillis())
                        appendAction(id,action)
                        break
                    }
                }
                prefs.edit().putString("timers",timers.toString()).apply()
            }
            else -> timers=runCatching{JSONArray(prefs.getString("timers","[]"))}.getOrDefault(JSONArray())
        }
        if(timers.length()==0){
            handler.removeCallbacks(refresher)
            if(foreground)stopForeground(STOP_FOREGROUND_REMOVE)
            foreground=false
            stopSelf()
            return START_NOT_STICKY
        }
        val note=buildNotification()
        if(!foreground){
            if(Build.VERSION.SDK_INT>=34){
                startForeground(NOTIFICATION,note,ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            }else startForeground(NOTIFICATION,note)
            foreground=true
        }else showNotification()
        handler.removeCallbacks(refresher)
        handler.postDelayed(refresher,60000)
        return START_STICKY
    }
    private fun appendAction(id:String,action:String){
        val prefs=getSharedPreferences("fa_cost_native_51",Context.MODE_PRIVATE)
        synchronized(ACTION_LOCK){
            val old=runCatching{JSONArray(prefs.getString("pending","[]"))}.getOrDefault(JSONArray())
            old.put(JSONObject().put("actionId",java.util.UUID.randomUUID().toString()).put("id",id).put("action",action).put("at",System.currentTimeMillis()))
            prefs.edit().putString("pending",old.toString()).commit()
        }
    }
    private fun actionIntent(action:String,id:String,code:Int):PendingIntent{
        val i=Intent(this,CostTimerService::class.java).apply {this.action=action;putExtra(EXTRA_ID,id)}
        return PendingIntent.getService(this,code,i,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
    private fun openIntent(confirmId:String?=null):PendingIntent{
        val i=Intent(this,de.fa.fertigung.MainActivity::class.java).apply {
            flags=Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            if(confirmId!=null)putExtra("fa_cost_confirm_stop",confirmId)
        }
        return PendingIntent.getActivity(this,if(confirmId==null)1 else confirmId.hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
    private fun buildNotification():Notification {
        val title="⏱️ Kostenzeiten · ${timers.length()} aktiv"
        val content=if(timers.length()==1){val e=timers.optJSONObject(0);"${e?.optString("name") ?: "Kostenzeit"} · ${e?.optString("state") ?: ""}"}else "Antippen, um einzelne Timer zu steuern"
        val builder=Notification.Builder(this,CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title).setContentText(content)
            .setContentIntent(openIntent()).setOngoing(true).setOnlyAlertOnce(true)
        val style=Notification.InboxStyle()
        for(i in 0 until minOf(timers.length(),7)){
            val e=timers.optJSONObject(i)?:continue
            style.addLine("${e.optString("name")} · ${if(e.optString("state")=="paused") "⏸" else "▶"}")
        }
        builder.setStyle(style)
        if(timers.length()==1){
            val e=timers.optJSONObject(0)!!;val id=e.optString("id")
            if(e.optString("state")=="running"){
                builder.addAction(Notification.Action.Builder(null,"Pause",actionIntent(ACTION_PAUSE,id,101)).build())
            }else{
                builder.addAction(Notification.Action.Builder(null,"Fortsetzen",actionIntent(ACTION_RESUME,id,102)).build())
            }
            builder.addAction(Notification.Action.Builder(null,"Stopp (bestätigen)",openIntent(id)).build())
        }
        return builder.build()
    }
    private fun showNotification(){
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION,buildNotification())
    }
    override fun onDestroy(){handler.removeCallbacks(refresher);super.onDestroy()}
}
