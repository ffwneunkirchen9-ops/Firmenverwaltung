package de.fa.fertigung.worktime
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator

class SmokeReminder : BroadcastReceiver() {
    companion object {
        private fun prefs(c: Context) = c.getSharedPreferences("fa_smoke_reminder_53", Context.MODE_PRIVATE)
        private fun intent(c: Context) = PendingIntent.getBroadcast(c, 5253, Intent(c, SmokeReminder::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        @Synchronized fun schedule(c: Context, start: Long) {
            val p = prefs(c)
            if (p.getLong("start", 0L) == start) return
            val a = c.getSystemService(AlarmManager::class.java)
            a.cancel(intent(c))
            p.edit().putLong("start", start).commit()
            val now = System.currentTimeMillis()
            if (start <= 0L || now >= start + 600000L || p.getLong("alerted", 0L) == start) return
            val at = maxOf(now + 100L, start + 480000L)
            try { a.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, intent(c)) }
            catch (e: SecurityException) { a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, intent(c)) }
        }
    }
    override fun onReceive(c: Context, i: Intent) {
        val p = prefs(c)
        val start = p.getLong("start", 0L)
        val now = System.currentTimeMillis()
        if (start <= 0L || now < start + 480000L || now >= start + 600000L || p.getLong("alerted", 0L) == start) return
        p.edit().putLong("alerted", start).commit()
        val v = c.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(450L, VibrationEffect.DEFAULT_AMPLITUDE))
        else { @Suppress("DEPRECATION") v.vibrate(450L) }
    }
}
