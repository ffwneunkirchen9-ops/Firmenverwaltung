package de.fa.fertigung.costs

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.core.content.FileProvider
import com.google.android.gms.wearable.PutDataMapRequest
import com.google.android.gms.wearable.Wearable
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** FIX51 – separate native file storage / notification / read-only Time Recording bridge. */
class CostTimeNativeBridge(private val activity: Activity, private val web: WebView) {

    private fun attachmentDir(): File = File(activity.filesDir, "Kostenzeiten_Anhaenge").apply { mkdirs() }
    private fun validated(id: String): String {
        require(id.matches(Regex("[a-zA-Z0-9_-]{6,160}"))) { "Ungültige Anhang-ID" }
        return id
    }

    @JavascriptInterface
    fun saveCostAttachment(id: String, name: String, dataUrl: String): String = try {
        val bytes = Base64.decode(dataUrl.substringAfter(',', ""), Base64.DEFAULT)
        require(bytes.size <= 8 * 1024 * 1024) { "Datei zu groß (maximal 8 MB)" }
        val target = File(attachmentDir(), validated(id))
        require(!target.exists()) { "Anhang existiert bereits; nicht überschrieben" }
        target.writeBytes(bytes)
        JSONObject().put("ok", true).put("name", name).toString()
    } catch (e: Exception) {
        JSONObject().put("ok", false).put("error", e.message).toString()
    }

    @JavascriptInterface
    fun getCostAttachmentData(id: String): String = try {
        val file = File(attachmentDir(), validated(id))
        require(file.isFile) { "Datei auf diesem Gerät nicht gefunden" }
        require(file.length() <= 8 * 1024 * 1024) { "Datei zu groß" }
        JSONObject().put("ok", true).put("data", Base64.encodeToString(file.readBytes(), Base64.NO_WRAP)).toString()
    } catch (e: Exception) {
        JSONObject().put("ok", false).put("error", e.message).toString()
    }

    @JavascriptInterface
    fun openCostAttachment(id: String, name: String, mime: String) {
        activity.runOnUiThread {
            try {
                val target = File(attachmentDir(), validated(id))
                require(target.isFile) { "Datei nicht gefunden" }
                val uri = FileProvider.getUriForFile(
                    activity,
                    "${activity.packageName}.fileprovider",
                    target
                )
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, mime.ifBlank { "application/octet-stream" })
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                activity.startActivity(Intent.createChooser(intent, "Anhang öffnen: $name"))
            } catch (e: Exception) {
                sendJavascript("window.faCosts && window.alert(${JSONObject.quote("Anhang kann nicht geöffnet werden: ${e.message}")});")
            }
        }
    }

    @JavascriptInterface
    fun setCostTimers(json: String) {
        activity.runOnUiThread {
            val intent = Intent(activity, CostTimerService::class.java).apply {
                action = CostTimerService.ACTION_SYNC
                putExtra(CostTimerService.EXTRA_TIMERS, json)
            }
            if (json == "[]") {
                activity.startService(intent)
            } else if (Build.VERSION.SDK_INT >= 26) {
                activity.startForegroundService(intent)
            } else {
                activity.startService(intent)
            }
        }
    }

    @JavascriptInterface
    fun consumeCostActions(): String {
        val prefs = activity.getSharedPreferences("fa_cost_native_51", Context.MODE_PRIVATE)
        synchronized(CostTimerService.ACTION_LOCK) {
            val saved = prefs.getString("pending", "[]") ?: "[]"
            return saved
        }
    }

    @JavascriptInterface
    fun ackCostAction(actionId: String) {
        if (actionId.isBlank()) return
        val prefs=activity.getSharedPreferences("fa_cost_native_51",Context.MODE_PRIVATE)
        synchronized(CostTimerService.ACTION_LOCK) {
            val old=runCatching { JSONArray(prefs.getString("pending","[]")) }.getOrDefault(JSONArray())
            val keep=JSONArray()
            for(i in 0 until old.length()) {
                val row=old.optJSONObject(i)?:continue
                if(row.optString("actionId")!=actionId)keep.put(row)
            }
            prefs.edit().putString("pending",keep.toString()).commit()
        }
    }

    private fun sendJavascript(script: String) {
        web.post { web.evaluateJavascript(script, null) }
    }

    @JavascriptInterface
    fun requestTimeRecordingExport(date: String) {
        if (!date.matches(Regex("20[0-9]{2}-[0-9]{2}-[0-9]{2}"))) return
        activity.runOnUiThread {
            val packageName = listOf("com.dynamicg.timerecording.pro", "com.dynamicg.timerecording")
                .firstOrNull { pkg ->
                    try {
                        @Suppress("DEPRECATION")
                        activity.packageManager.getPackageInfo(pkg, 0)
                        true
                    } catch (_: PackageManager.NameNotFoundException) { false }
                }
            if (packageName == null) {
                reportTimeRecording(JSONObject().put("ok", false).put("error", "Zeiterfassung nicht installiert oder nicht erkennbar"))
                return@runOnUiThread
            }
            val intent = Intent("com.dynamicg.timerecording.DATA_EXPORT").apply {
                setPackage(packageName)
                putExtra("com.dynamicg.timerecording.DATE_FROM", date)
                putExtra("com.dynamicg.timerecording.DATE_TO", date)
                putExtra("com.dynamicg.timerecording.EXPORT_TYPE", "e3")
                putExtra("com.dynamicg.timerecording.EXPORT_FORMAT", "csv")
                putExtra("com.dynamicg.timerecording.CALLED_BY_PKG", activity.packageName)
            }
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(context: Context?, intent: Intent?) {
                    val uriValue = getResultExtras(true)?.getString("com.dynamicg.timerecording.FILE_URI")
                    if (uriValue.isNullOrBlank()) {
                        reportTimeRecording(JSONObject().put("ok", false).put("error", "Zeiterfassung hat keinen CSV-Bericht geliefert"))
                        return
                    }
                    Thread {
                        try {
                            val fileUri = Uri.parse(uriValue)
                            val csv = activity.contentResolver.openInputStream(fileUri)?.bufferedReader()?.use { it.readText() }
                                ?: error("CSV-Datei nicht lesbar")
                            require(csv.length <= 800000) { "CSV zu groß" }
                            reportTimeRecording(JSONObject().put("ok", true).put("csv", csv))
                        } catch (e: Exception) {
                            reportTimeRecording(JSONObject().put("ok", false).put("error", e.message))
                        }
                    }.start()
                }
            }
            try {
                activity.sendOrderedBroadcast(intent, null, receiver, null, Activity.RESULT_OK, null, null)
            } catch (e: Exception) {
                reportTimeRecording(JSONObject().put("ok", false).put("error", e.message))
            }
        }
    }

    private fun reportTimeRecording(json: JSONObject) {
        sendJavascript("window.faCosts && window.faCosts.receiveTimeRecording(${JSONObject.quote(json.toString())});")
    }

    @JavascriptInterface
    fun setCostWatchReasons(json: String) {
        try {
            val req=PutDataMapRequest.create("/fa/cost/reasons").apply {
                dataMap.putString("json", json)
                dataMap.putLong("updatedAt", System.currentTimeMillis())
            }.asPutDataRequest().setUrgent()
            Wearable.getDataClient(activity).putDataItem(req)
        } catch (_: Exception) { /* Uhr kann vorübergehend nicht verbunden sein. */ }
    }
}
