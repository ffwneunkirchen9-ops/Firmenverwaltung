package de.fa.fertigung.worktime

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Persistente Benutzer-Benachrichtigung während eingestempelter Arbeitszeit. */
class WorkTimeService : Service() {
    companion object {
        const val ACTION_UPDATE = "de.fa.fertigung.worktime.UPDATE"
        const val ACTION_PAUSE = "de.fa.fertigung.worktime.PAUSE"
        const val ACTION_RESUME = "de.fa.fertigung.worktime.RESUME"
        val LOCK = Any()
        private const val CHANNEL = "fa_worktime_52"
        private const val NOTIFICATION = 52052
    }
    private val handler = Handler(Looper.getMainLooper())
    private val prefs get() = getSharedPreferences("fa_work_native_52", Context.MODE_PRIVATE)
    private var foreground = false
    private var state = JSONObject()
    private val refresh = object : Runnable {
        override fun run() {
            if (foreground) {
                getSystemService(NotificationManager::class.java).notify(NOTIFICATION, notification())
                handler.postDelayed(this, refreshDelay())
            }
        }
    }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL, "FA Fertigung Arbeitszeit", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }
    private fun queueAction(type: String) = synchronized(LOCK) {
        val rows = runCatching { JSONArray(prefs.getString("pending", "[]")) }.getOrDefault(JSONArray())
        rows.put(JSONObject().put("id", UUID.randomUUID().toString()).put("type", type).put("at", System.currentTimeMillis()))
        prefs.edit().putString("pending", rows.toString()).commit()
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        state = runCatching { JSONObject(prefs.getString("state", "{}")) }.getOrDefault(JSONObject())
        when (intent?.action) {
            ACTION_UPDATE -> state = runCatching { JSONObject(intent.getStringExtra("state") ?: "{}") }.getOrDefault(JSONObject())
            ACTION_PAUSE -> if (state.optBoolean("active") && !state.optBoolean("paused")) {
                queueAction("pause")
                state.put("paused", true)
            }
            ACTION_RESUME -> if (state.optBoolean("active") && state.optBoolean("paused")) {
                queueAction("resume")
                state.put("paused", false)
            }
        }
        prefs.edit().putString("state", state.toString()).commit()
        if (!state.optBoolean("active")) {
            handler.removeCallbacks(refresh)
            if (foreground) stopForeground(STOP_FOREGROUND_REMOVE)
            foreground = false
            stopSelf()
            return START_NOT_STICKY
        }
        val note = notification()
        if (!foreground) {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIFICATION, note, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else startForeground(NOTIFICATION, note)
            foreground = true
        } else getSystemService(NotificationManager::class.java).notify(NOTIFICATION, note)
        handler.removeCallbacks(refresh)
        handler.postDelayed(refresh, refreshDelay())
        return START_STICKY
    }
    private fun pending(action: String, request: Int): PendingIntent {
        val intent = Intent(this, WorkTimeService::class.java).apply { this.action = action }
        return PendingIntent.getService(this, request, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
    private fun open(confirm: Boolean): PendingIntent {
        val intent = Intent(this, de.fa.fertigung.MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            if (confirm) putExtra("fa_work_confirm_end", true)
        }
        return PendingIntent.getActivity(this, if (confirm) 5202 else 5201, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
    private fun smokeLeft(): Long = (getSharedPreferences("fa_smoke_reminder_53", MODE_PRIVATE).getLong("start", 0L) + 600000L - System.currentTimeMillis()).coerceAtLeast(0L)
    private fun refreshDelay(): Long { val left = smokeLeft(); return if (left > 120000L) minOf(60000L, left - 120000L) else if (left > 0L) left else 60000L }
    private fun notification(): Notification {
        val started = state.optLong("started", System.currentTimeMillis())
        val elapsed = ((System.currentTimeMillis() - started).coerceAtLeast(0L) / 60000L)
        val hours = elapsed / 60L
        val mins = elapsed % 60L
        val paused = state.optBoolean("paused")
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("🕘 Anwesenheit · ${hours}:${mins.toString().padStart(2, '0')} Std.")
            .setContentText(if (paused) "Pause läuft" else "Eingestempelt · Tippen für Arbeitszeit")
            .setContentIntent(open(false))
            .setOnlyAlertOnce(true)
            .setOngoing(true)
        val left = smokeLeft()
        if (left > 0L) {
            n.setContentTitle("🚬 Raucherpause läuft")
                .setContentText(if (left <= 120000L) "Noch 2 Minuten Raucherpause" else "Verbleibende Pausenzeit")
                .setWhen(System.currentTimeMillis() + left).setShowWhen(true).setUsesChronometer(true).setChronometerCountDown(true)
        }
        if (paused) n.addAction(Notification.Action.Builder(null, "Fortsetzen", pending(ACTION_RESUME, 5203)).build())
        else n.addAction(Notification.Action.Builder(null, "Pause", pending(ACTION_PAUSE, 5204)).build())
        n.addAction(Notification.Action.Builder(null, "Arbeitsende bestätigen", open(true)).build())
        return n.build()
    }
    override fun onDestroy() { handler.removeCallbacks(refresh); super.onDestroy() }
}
