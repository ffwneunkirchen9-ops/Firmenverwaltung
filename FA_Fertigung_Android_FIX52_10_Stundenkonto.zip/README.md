FA Fertigung FIX52 – Meine Arbeitszeit / Galaxy Watch Zeit + FA.

Basiert auf FIX51 (Kostenzeiten) mit den ursprünglichen FA-Funktionen.
Die App-ID de.fa.fertigung und der produktive lokale FA-Schlüssel faFertigung_v2 bleiben unverändert.
Die neue Arbeitszeiterfassung verwendet faFertigung_arbeitszeit_v1 separat.

Uhr: Beim Öffnen Auswahl Zeit / FA. FA-Bildschirm, Mengenbedienung und Timer bleiben erhalten.
Zeit: Einstempeln, Ausstempeln mit Rückfrage, Raucherpause genau 10 Minuten.
Raucherpause verändert laufende FA-Timer nicht. Arbeitszeit-Ereignisse werden offline gepuffert.

ACHTUNG: Urlaubskonto in Familienverwaltung ist nicht angeschlossen, bis die echte Datenquelle vorliegt.
Für die neue Arbeitszeit benötigte Apps-Script-Datei: Arbeitszeit.gs (separat).
APK erst als signiertes Update installieren, nie deinstallieren.
Android-/Wear-Build nicht lokal verifiziert, vor Installation GitHub Actions prüfen.
