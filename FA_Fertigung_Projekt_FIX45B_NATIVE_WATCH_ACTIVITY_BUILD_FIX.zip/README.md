# FA Fertigung FIX45B

Build-Reparatur für FIX45.

Die native Watch-Activity und das Layout bleiben unverändert.
Es wurde nur der falsche `launchAction`-Import in der Kachel korrigiert.

Für FIX45B nur Watch-Projekt neu bauen. Das FIX45-script.html bleibt kompatibel.
