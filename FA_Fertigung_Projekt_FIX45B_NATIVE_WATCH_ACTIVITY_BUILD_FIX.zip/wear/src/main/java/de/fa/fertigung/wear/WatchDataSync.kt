package de.fa.fertigung.wear

import android.content.Context
import com.google.android.gms.wearable.PutDataMapRequest
import com.google.android.gms.wearable.Wearable
import org.json.JSONObject
import java.util.UUID

object WatchDataSync {

    const val CONTEXT_PATH =
        "/fa/watch/context"

    const val ACK_PATH =
        "/fa/watch/ack"

    const val EVENT_PREFIX =
        "/fa/watch/event/"

    const val EVENT_MESSAGE_PATH =
        "/fa/watch/action"


    fun sendEvent(
        context: Context,
        type: String,
        positionIndex: Int
    ): Boolean {

        val current =
            WatchStateStore
                .selectedFa(
                    context
                )
                ?: return false

        if (
            !current.optBoolean(
                "active",
                true
            )
        ) {
            return false
        }

        val faId =
            current.optString(
                "faId"
            )
                .trim()

        if (
            faId.isEmpty()
        ) {
            return false
        }

        val eventId =
            UUID.randomUUID()
                .toString()

        val timestamp =
            System.currentTimeMillis()

        val eventJson =
            JSONObject()
                .put(
                    "eventId",
                    eventId
                )
                .put(
                    "type",
                    type
                )
                .put(
                    "faId",
                    faId
                )
                .put(
                    "faNo",
                    current.optString(
                        "faNo"
                    )
                )
                .put(
                    "date",
                    current.optString(
                        "date"
                    )
                )
                .put(
                    "positionIndex",
                    positionIndex
                )
                .put(
                    "timestamp",
                    timestamp
                )

        Wearable
            .getNodeClient(
                context
            )
            .connectedNodes
            .addOnSuccessListener {
                nodes ->

                val payload =
                    eventJson
                        .toString()
                        .toByteArray(
                            Charsets.UTF_8
                        )

                nodes.forEach {
                    node ->

                    Wearable
                        .getMessageClient(
                            context
                        )
                        .sendMessage(
                            node.id,
                            EVENT_MESSAGE_PATH,
                            payload
                        )
                }
            }

        val request =
            PutDataMapRequest
                .create(
                    EVENT_PREFIX +
                    eventId
                )
                .apply {

                    dataMap.putString(
                        "eventId",
                        eventId
                    )

                    dataMap.putString(
                        "type",
                        type
                    )

                    dataMap.putString(
                        "faId",
                        faId
                    )

                    dataMap.putString(
                        "faNo",
                        current.optString(
                            "faNo"
                        )
                    )

                    dataMap.putString(
                        "date",
                        current.optString(
                            "date"
                        )
                    )

                    dataMap.putInt(
                        "positionIndex",
                        positionIndex
                    )

                    dataMap.putLong(
                        "timestamp",
                        timestamp
                    )
                }
                .asPutDataRequest()
                .setUrgent()

        WatchStateStore.addPending(
            context,
            eventId,
            type
        )

        Wearable
            .getDataClient(
                context
            )
            .putDataItem(
                request
            )

        return true
    }
}
