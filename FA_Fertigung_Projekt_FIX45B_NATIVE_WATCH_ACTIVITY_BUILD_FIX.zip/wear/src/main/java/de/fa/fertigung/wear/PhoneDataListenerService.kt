package de.fa.fertigung.wear

import androidx.wear.tiles.TileService
import com.google.android.gms.wearable.DataEvent
import com.google.android.gms.wearable.DataEventBuffer
import com.google.android.gms.wearable.DataMapItem
import com.google.android.gms.wearable.WearableListenerService

class PhoneDataListenerService :
    WearableListenerService() {

    override fun onDataChanged(
        dataEvents: DataEventBuffer
    ) {
        var changed =
            false

        dataEvents.forEach {
            event ->

            if (
                event.type !=
                DataEvent.TYPE_CHANGED
            ) {
                return@forEach
            }

            val item =
                event.dataItem

            val path =
                item.uri.path
                    .orEmpty()

            val map =
                runCatching {
                    DataMapItem
                        .fromDataItem(
                            item
                        )
                        .dataMap
                }.getOrNull()
                    ?: return@forEach

            when (path) {

                WatchDataSync.CONTEXT_PATH -> {
                    val json =
                        map.getString(
                            "json"
                        )
                            .orEmpty()

                    if (
                        json.isNotBlank() &&
                        WatchStateStore.pendingCount(
                            this
                        ) == 0
                    ) {
                        WatchStateStore
                            .saveContext(
                                this,
                                json
                            )

                        changed =
                            true
                    }
                }

                WatchDataSync.ACK_PATH -> {
                    val ids =
                        map.getStringArrayList(
                            "eventIds"
                        )
                            ?.toSet()
                            ?: emptySet()

                    WatchStateStore
                        .acknowledge(
                            this,
                            ids
                        )

                    changed =
                        true
                }
            }
        }

        if (changed) {
            TileService
                .getUpdater(
                    this
                )
                .requestUpdate(
                    FaCounterTileService::class.java
                )
        }
    }
}
