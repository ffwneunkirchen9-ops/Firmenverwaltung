# FA Fertigung FIX45

FIX45 ersetzt die eigentliche Bedienung in der Wear-Kachel durch eine native,
skalierende Vollbild-Oberfläche.

## Bedienung
1. Kachel `FA Fertigung` öffnen.
2. Auf `FA öffnen` tippen.
3. Die native FA-Oberfläche bleibt im Vordergrund und hält das Display aktiv.

## Zählung
- Schneiden: Platten ±1, Ausschuss ±1
- Entgraten: Tagesmenge ±10, Ausschuss ±1
- FA-Wechsel über das gezeichnete Doppelpfeil-Symbol
- Timer: Start/Pause/Weiter, Stop erscheint bei aktivem Timer

## Dateien
Für FIX45 nur die Watch-App neu bauen/installieren.
Das bestehende FIX44-script.html bleibt kompatibel.
