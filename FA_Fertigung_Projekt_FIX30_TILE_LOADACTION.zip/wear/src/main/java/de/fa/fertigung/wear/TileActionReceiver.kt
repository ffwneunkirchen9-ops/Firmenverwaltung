package de.fa.fertigung.wear

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.wear.tiles.TileService
import org.json.JSONObject

class TileActionReceiver :
    BroadcastReceiver() {

    override fun onReceive(
        context: Context,
        intent: Intent
    ) {

        handleAction(
            context,
            intent.action.orEmpty(),
            true
        )
    }


    companion object {

        const val ACTION_PLATE_PLUS =
            "de.fa.fertigung.wear.PLATE_PLUS"

        const val ACTION_PLATE_MINUS =
            "de.fa.fertigung.wear.PLATE_MINUS"

        const val ACTION_SCRAP_PLUS =
            "de.fa.fertigung.wear.SCRAP_PLUS"

        const val ACTION_SCRAP_MINUS =
            "de.fa.fertigung.wear.SCRAP_MINUS"

        const val ACTION_UNDO =
            "de.fa.fertigung.wear.UNDO"

        const val ACTION_NEXT_POSITION =
            "de.fa.fertigung.wear.NEXT_POSITION"

        const val ACTION_NOOP =
            "de.fa.fertigung.wear.NOOP"


        fun handleAction(
            context: Context,
            action: String,
            requestTileUpdate: Boolean = true
        ) {

            val json =
                runCatching {
                    JSONObject(
                        WatchStateStore
                            .contextJson(
                                context
                            )
                    )
                }.getOrNull()
                    ?: JSONObject()

            val positions =
                json.optJSONArray(
                    "positions"
                )

            val positionCount =
                positions?.length()
                    ?: 0

            val selected =
                WatchStateStore
                    .selectedPosition(
                        context,
                        positionCount
                    )

            when (action) {

                ACTION_PLATE_PLUS -> {

                    if (
                        json.optBoolean(
                            "canAddPlates",
                            false
                        ) &&
                        WatchStateStore.adjustPlates(
                            context,
                            1
                        )
                    ) {

                        WatchDataSync.sendEvent(
                            context,
                            "plate_plus",
                            selected
                        )

                        vibrate(
                            context
                        )
                    }
                }

                ACTION_PLATE_MINUS -> {

                    if (
                        json.optBoolean(
                            "canAddPlates",
                            false
                        ) &&
                        WatchStateStore.adjustPlates(
                            context,
                            -1
                        )
                    ) {

                        WatchDataSync.sendEvent(
                            context,
                            "plate_minus",
                            selected
                        )

                        vibrate(
                            context
                        )
                    }
                }

                ACTION_SCRAP_PLUS -> {

                    if (
                        positionCount > 0 &&
                        WatchStateStore.adjustScrap(
                            context,
                            selected,
                            1
                        )
                    ) {

                        WatchDataSync.sendEvent(
                            context,
                            "scrap_plus",
                            selected
                        )

                        vibrate(
                            context
                        )
                    }
                }

                ACTION_SCRAP_MINUS -> {

                    if (
                        positionCount > 0 &&
                        WatchStateStore.adjustScrap(
                            context,
                            selected,
                            -1
                        )
                    ) {

                        WatchDataSync.sendEvent(
                            context,
                            "scrap_minus",
                            selected
                        )

                        vibrate(
                            context
                        )
                    }
                }

                ACTION_UNDO -> {

                    if (
                        WatchDataSync.sendEvent(
                            context,
                            "undo",
                            selected
                        )
                    ) {

                        vibrate(
                            context
                        )
                    }
                }

                ACTION_NEXT_POSITION -> {

                    WatchStateStore.nextPosition(
                        context,
                        positionCount
                    )

                    vibrate(
                        context
                    )
                }

                ACTION_NOOP -> {
                    // reine Anzeige
                }
            }

            if (
                requestTileUpdate
            ) {

                TileService
                    .getUpdater(
                        context
                    )
                    .requestUpdate(
                        FaCounterTileService::class.java
                    )
            }
        }


        private fun vibrate(
            context: Context
        ) {

            runCatching {

                val effect =
                    VibrationEffect
                        .createOneShot(
                            35L,
                            VibrationEffect
                                .DEFAULT_AMPLITUDE
                        )

                if (
                    Build.VERSION.SDK_INT >=
                    Build.VERSION_CODES.S
                ) {

                    val manager =
                        context.getSystemService(
                            VibratorManager::class.java
                        )

                    manager
                        ?.defaultVibrator
                        ?.vibrate(
                            effect
                        )
                }
                else {

                    @Suppress("DEPRECATION")
                    val vibrator =
                        context.getSystemService(
                            Context.VIBRATOR_SERVICE
                        ) as? Vibrator

                    vibrator?.vibrate(
                        effect
                    )
                }
            }
        }
    }
}
