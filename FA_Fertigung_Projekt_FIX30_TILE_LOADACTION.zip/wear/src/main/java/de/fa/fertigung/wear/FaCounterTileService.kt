package de.fa.fertigung.wear

import android.content.Context
import androidx.wear.protolayout.DimensionBuilders.expand
import androidx.wear.protolayout.DimensionBuilders.weight
import androidx.wear.protolayout.ProtoLayoutScope
import androidx.wear.protolayout.TimelineBuilders.Timeline
import androidx.wear.protolayout.layout.column
import androidx.wear.protolayout.material3.ButtonDefaults.filledButtonColors
import androidx.wear.protolayout.material3.ButtonDefaults.filledTonalButtonColors
import androidx.wear.protolayout.material3.CardDefaults.filledVariantCardColors
import androidx.wear.protolayout.material3.ButtonGroupDefaults.DEFAULT_SPACER_BETWEEN_BUTTON_GROUPS
import androidx.wear.protolayout.material3.Typography.BODY_SMALL
import androidx.wear.protolayout.material3.Typography.NUMERAL_SMALL
import androidx.wear.protolayout.material3.buttonGroup
import androidx.wear.protolayout.material3.materialScopeWithResources
import androidx.wear.protolayout.material3.primaryLayout
import androidx.wear.protolayout.material3.text
import androidx.wear.protolayout.material3.textButton
import androidx.wear.protolayout.material3.textDataCard
import androidx.wear.protolayout.modifiers.clickable
import androidx.wear.protolayout.modifiers.loadAction
import androidx.wear.protolayout.types.layoutString
import androidx.wear.tiles.RequestBuilders
import androidx.wear.tiles.TileService
import androidx.wear.tiles.tile
import com.google.common.util.concurrent.Futures
import org.json.JSONObject

class FaCounterTileService :
    TileService() {

    override fun onTileRequest(
        requestParams:
            RequestBuilders.TileRequest
    ) =
        Futures.immediateFuture(

            run {

                /*
                 * FIX30:
                 * Offizieller Tile-Interaktionsweg.
                 *
                 * loadAction() löst onTileRequest() aus und liefert
                 * lastClickableId. Damit hängt die Bedienung nicht mehr
                 * davon ab, ob der konkrete Watch-Renderer PendingIntent
                 * Clickables unterstützt.
                 */
                val action =
                    when (
                        requestParams
                            .currentState
                            .lastClickableId
                    ) {

                        CLICK_PLATE_MINUS ->
                            TileActionReceiver
                                .ACTION_PLATE_MINUS

                        CLICK_PLATE_PLUS ->
                            TileActionReceiver
                                .ACTION_PLATE_PLUS

                        CLICK_SCRAP_MINUS ->
                            TileActionReceiver
                                .ACTION_SCRAP_MINUS

                        CLICK_SCRAP_PLUS ->
                            TileActionReceiver
                                .ACTION_SCRAP_PLUS

                        CLICK_UNDO ->
                            TileActionReceiver
                                .ACTION_UNDO

                        CLICK_NEXT_POSITION ->
                            TileActionReceiver
                                .ACTION_NEXT_POSITION

                        CLICK_DISPLAY ->
                            TileActionReceiver
                                .ACTION_NOOP

                        else ->
                            null
                    }


                if (
                    action != null
                ) {

                    TileActionReceiver
                        .handleAction(
                            this,
                            action,
                            false
                        )
                }


                tile(
                    Timeline.fromLayoutElement(
                        buildTileLayout(
                            this,
                            requestParams.scope,
                            requestParams
                                .deviceConfiguration
                        )
                    )
                )
            }
        )


    private fun buildTileLayout(
        context: Context,
        scope: ProtoLayoutScope,
        deviceParameters:
            androidx.wear.protolayout.DeviceParametersBuilders.DeviceParameters
    ) =
        materialScopeWithResources(
            context,
            scope,
            deviceParameters
        ) {

            val json =
                runCatching {
                    JSONObject(
                        WatchStateStore
                            .contextJson(
                                context
                            )
                    )
                }.getOrElse {
                    JSONObject()
                }


            if (
                !json.optBoolean(
                    "active",
                    false
                )
            ) {

                return@materialScopeWithResources primaryLayout(
                    titleSlot = {
                        text(
                            "FA Fertigung"
                                .layoutString
                        )
                    },

                    mainSlot = {
                        text(
                            "Am Handy einen FA öffnen."
                                .layoutString,
                            typography =
                                BODY_SMALL
                        )
                    }
                )
            }


            val positions =
                json.optJSONArray(
                    "positions"
                )

            val positionCount =
                positions?.length()
                    ?: 0

            val selected =
                WatchStateStore
                    .selectedPosition(
                        context,
                        positionCount
                    )

            val selectedPosition =
                positions
                    ?.optJSONObject(
                        selected
                    )
                    ?: JSONObject()

            val plates =
                json.optInt(
                    "plates",
                    0
                )

            val scrap =
                selectedPosition
                    .optInt(
                        "scrap",
                        0
                    )

            val faNo =
                json.optString(
                    "faNo",
                    "?"
                )

            val op =
                json.optString(
                    "op",
                    ""
                )

            val article =
                selectedPosition
                    .optString(
                        "article",
                        ""
                    )

            val pending =
                WatchStateStore
                    .pendingCount(
                        context
                    )


            val title =
                buildString {

                    append(
                        "FA "
                    )

                    append(
                        faNo
                    )

                    if (
                        op.isNotBlank()
                    ) {

                        append(
                            " · "
                        )

                        append(
                            op
                        )
                    }

                    if (
                        pending > 0
                    ) {

                        append(
                            " · ⏳"
                        )

                        append(
                            pending
                        )
                    }
                }


            val plateMinusClick =
                clickable(
                    id =
                        CLICK_PLATE_MINUS,
                    action =
                        loadAction()
                )

            val platePlusClick =
                clickable(
                    id =
                        CLICK_PLATE_PLUS,
                    action =
                        loadAction()
                )

            val scrapMinusClick =
                clickable(
                    id =
                        CLICK_SCRAP_MINUS,
                    action =
                        loadAction()
                )

            val scrapPlusClick =
                clickable(
                    id =
                        CLICK_SCRAP_PLUS,
                    action =
                        loadAction()
                )

            val displayClick =
                clickable(
                    id =
                        CLICK_DISPLAY,
                    action =
                        loadAction()
                )

            val nextPositionClick =
                clickable(
                    id =
                        CLICK_NEXT_POSITION,
                    action =
                        loadAction()
                )

            val undoClick =
                clickable(
                    id =
                        CLICK_UNDO,
                    action =
                        loadAction()
                )


            primaryLayout(
                titleSlot = {
                    text(
                        title.layoutString
                    )
                },

                mainSlot = {

                    column(
                        buttonGroup {

                            buttonGroupItem {

                                textButton(
                                    width =
                                        weight(
                                            1f
                                        ),
                                    height =
                                        expand(),
                                    onClick =
                                        plateMinusClick,
                                    colors =
                                        filledTonalButtonColors(),
                                    labelContent = {
                                        text(
                                            "−".layoutString,
                                            typography =
                                                NUMERAL_SMALL
                                        )
                                    }
                                )
                            }

                            buttonGroupItem {

                                textDataCard(
                                    onClick =
                                        displayClick,
                                    width =
                                        weight(
                                            2f
                                        ),
                                    height =
                                        expand(),
                                    colors =
                                        filledVariantCardColors(),
                                    title = {
                                        text(
                                            plates
                                                .toString()
                                                .layoutString,
                                            typography =
                                                NUMERAL_SMALL
                                        )
                                    },
                                    content = {
                                        text(
                                            "Platten"
                                                .layoutString,
                                            typography =
                                                BODY_SMALL
                                        )
                                    }
                                )
                            }

                            buttonGroupItem {

                                textButton(
                                    width =
                                        weight(
                                            1f
                                        ),
                                    height =
                                        expand(),
                                    onClick =
                                        platePlusClick,
                                    colors =
                                        filledButtonColors(),
                                    labelContent = {
                                        text(
                                            "+".layoutString,
                                            typography =
                                                NUMERAL_SMALL
                                        )
                                    }
                                )
                            }
                        },

                        DEFAULT_SPACER_BETWEEN_BUTTON_GROUPS,

                        buttonGroup {

                            buttonGroupItem {

                                textButton(
                                    width =
                                        weight(
                                            1f
                                        ),
                                    height =
                                        expand(),
                                    onClick =
                                        scrapMinusClick,
                                    colors =
                                        filledTonalButtonColors(),
                                    labelContent = {
                                        text(
                                            "−".layoutString,
                                            typography =
                                                NUMERAL_SMALL
                                        )
                                    }
                                )
                            }

                            buttonGroupItem {

                                textDataCard(
                                    onClick =
                                        displayClick,
                                    width =
                                        weight(
                                            2f
                                        ),
                                    height =
                                        expand(),
                                    colors =
                                        filledVariantCardColors(),
                                    title = {
                                        text(
                                            scrap
                                                .toString()
                                                .layoutString,
                                            typography =
                                                NUMERAL_SMALL
                                        )
                                    },
                                    content = {
                                        text(
                                            "Ausschuss"
                                                .layoutString,
                                            typography =
                                                BODY_SMALL
                                        )
                                    }
                                )
                            }

                            buttonGroupItem {

                                textButton(
                                    width =
                                        weight(
                                            1f
                                        ),
                                    height =
                                        expand(),
                                    onClick =
                                        scrapPlusClick,
                                    colors =
                                        filledButtonColors(),
                                    labelContent = {
                                        text(
                                            "+".layoutString,
                                            typography =
                                                NUMERAL_SMALL
                                        )
                                    }
                                )
                            }
                        },

                        width =
                            expand(),

                        height =
                            expand()
                    )
                },

                bottomSlot = {

                    buttonGroup {

                        if (
                            positionCount > 1
                        ) {

                            buttonGroupItem {

                                textButton(
                                    width =
                                        weight(
                                            2f
                                        ),
                                    height =
                                        expand(),
                                    onClick =
                                        nextPositionClick,
                                    colors =
                                        filledTonalButtonColors(),
                                    labelContent = {
                                        text(
                                            (
                                                "Pos " +
                                                (
                                                    selected +
                                                    1
                                                ) +
                                                "/" +
                                                positionCount +
                                                (
                                                    if (
                                                        article.isNotBlank()
                                                    ) {

                                                        " · " +
                                                        article.take(
                                                            10
                                                        )
                                                    }
                                                    else {

                                                        ""
                                                    }
                                                )
                                            )
                                                .layoutString,
                                            typography =
                                                BODY_SMALL
                                        )
                                    }
                                )
                            }
                        }

                        buttonGroupItem {

                            textButton(
                                width =
                                    weight(
                                        if (
                                            positionCount > 1
                                        ) {

                                            1f
                                        }
                                        else {

                                            3f
                                        }
                                    ),
                                height =
                                    expand(),
                                onClick =
                                    undoClick,
                                colors =
                                    filledTonalButtonColors(),
                                labelContent = {
                                    text(
                                        "↶".layoutString,
                                        typography =
                                            NUMERAL_SMALL
                                    )
                                }
                            )
                        }
                    }
                }
            )
        }


    companion object {

        private const val CLICK_PLATE_MINUS =
            "plate_minus"

        private const val CLICK_PLATE_PLUS =
            "plate_plus"

        private const val CLICK_SCRAP_MINUS =
            "scrap_minus"

        private const val CLICK_SCRAP_PLUS =
            "scrap_plus"

        private const val CLICK_UNDO =
            "undo"

        private const val CLICK_NEXT_POSITION =
            "next_position"

        private const val CLICK_DISPLAY =
            "display"
    }
}
