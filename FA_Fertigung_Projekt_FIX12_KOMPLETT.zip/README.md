# FA Fertigung – Hybrid-Handy-KI

Diese Android-App öffnet die bestehende Google-Apps-Script-Web-App in einem WebView und stellt der Web-App die lokale Geräte-KI über `FaLocalAI` bereit.

Standard-Web-App:
https://script.google.com/macros/s/AKfycbz_RcPQmoz9OmnjVFr3yxE7d2M8EuORi65yYdm4gRena1Vq0Mr_CMEzAFRlosgv6MQ/exec

KI-Verhalten:
- Automatisch: Gemini Nano/AICore auf dem Handy zuerst, Online-KI nur Fallback.
- Nur lokal: keine Online-KI.
- Online: bisherige Apps-Script/Gemini-Auswertung.
- Kamera und Galerie funktionieren direkt im WebView.

Technik:
- Google ML Kit GenAI Prompt API
- Gemini Nano / AICore
- max. 4 Bild-/PDF-Seiten für eine lokale Anfrage
- Bilder werden geräteseitig auf max. 1600 px dekodiert
