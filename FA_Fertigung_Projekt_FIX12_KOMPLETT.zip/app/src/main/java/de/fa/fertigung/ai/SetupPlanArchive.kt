package de.fa.fertigung.ai

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.math.min
import kotlin.math.roundToInt

object SetupPlanArchive {

    fun saveDataUrlAsPdf(
        context: Context,
        customer: String,
        setupNumber: String,
        dataUrl: String
    ): JSONObject {
        val base64 =
            if (
                dataUrl.contains(
                    "base64,"
                )
            ) {
                dataUrl.substringAfter(
                    "base64,"
                )
            } else {
                dataUrl
            }

        val bytes =
            Base64.decode(
                base64,
                Base64.DEFAULT
            )

        val bitmap =
            BitmapFactory
                .decodeByteArray(
                    bytes,
                    0,
                    bytes.size
                )
                ?: throw IllegalArgumentException(
                    "Einrichteplan-Bild konnte nicht gelesen werden."
                )

        return try {
            saveBitmapAsPdf(
                context,
                customer,
                setupNumber,
                bitmap
            )
        } finally {
            runCatching {
                if (
                    !bitmap.isRecycled
                ) {
                    bitmap.recycle()
                }
            }
        }
    }

    fun saveBitmapAsPdf(
        context: Context,
        customer: String,
        setupNumber: String,
        bitmap: Bitmap
    ): JSONObject {

        val cleanCustomer =
            safePathPart(
                customer
            )
                .ifBlank {
                    "Unbekannter Kunde"
                }

        val cleanNumber =
            safePathPart(
                setupNumber
            )
                .ifBlank {
                    "Ohne Nummer"
                }

        val relativePath =
            "Documents/FA Fertigung/Einrichteplaene/" +
            "$cleanCustomer/$cleanNumber/"

        val displayName =
            "Einrichteplan.pdf"

        val pdfBytes =
            bitmapToPdf(
                bitmap
            )

        val savedPath =
            if (
                Build.VERSION.SDK_INT >=
                Build.VERSION_CODES.Q
            ) {
                val resolver =
                    context.contentResolver

                val collection =
                    MediaStore.Files
                        .getContentUri(
                            MediaStore
                                .VOLUME_EXTERNAL_PRIMARY
                        )

                resolver.delete(
                    collection,
                    "${MediaStore.MediaColumns.RELATIVE_PATH}=? AND " +
                        "${MediaStore.MediaColumns.DISPLAY_NAME}=?",
                    arrayOf(
                        relativePath,
                        displayName
                    )
                )

                val values =
                    ContentValues()
                        .apply {
                            put(
                                MediaStore.MediaColumns.DISPLAY_NAME,
                                displayName
                            )

                            put(
                                MediaStore.MediaColumns.MIME_TYPE,
                                "application/pdf"
                            )

                            put(
                                MediaStore.MediaColumns.RELATIVE_PATH,
                                relativePath
                            )

                            put(
                                MediaStore.MediaColumns.IS_PENDING,
                                1
                            )
                        }

                val uri =
                    resolver.insert(
                        collection,
                        values
                    )
                        ?: throw IllegalStateException(
                            "PDF-Speicher konnte nicht angelegt werden."
                        )

                resolver
                    .openOutputStream(
                        uri,
                        "w"
                    )
                    ?.use {
                        stream ->

                        stream.write(
                            pdfBytes
                        )

                        stream.flush()
                    }
                    ?: throw IllegalStateException(
                        "Einrichteplan-PDF konnte nicht geschrieben werden."
                    )

                val finished =
                    ContentValues()
                        .apply {
                            put(
                                MediaStore.MediaColumns.IS_PENDING,
                                0
                            )
                        }

                resolver.update(
                    uri,
                    finished,
                    null,
                    null
                )

                relativePath +
                    displayName

            } else {
                val root =
                    context.getExternalFilesDir(
                        Environment
                            .DIRECTORY_DOCUMENTS
                    )
                        ?: context.filesDir

                val folder =
                    File(
                        root,
                        "FA Fertigung/Einrichteplaene/" +
                            "$cleanCustomer/$cleanNumber"
                    )
                        .apply {
                            mkdirs()
                        }

                val file =
                    File(
                        folder,
                        displayName
                    )

                file.writeBytes(
                    pdfBytes
                )

                file.absolutePath
            }

        val metadataFolder =
            File(
                context.filesDir,
                "Einrichteplaene/" +
                    "$cleanCustomer/$cleanNumber"
            )
                .apply {
                    mkdirs()
                }

        File(
            metadataFolder,
            "archive.json"
        )
            .writeText(
                JSONObject()
                    .put(
                        "customer",
                        customer.trim()
                    )
                    .put(
                        "setupNumber",
                        setupNumber.trim()
                    )
                    .put(
                        "path",
                        savedPath
                    )
                    .put(
                        "savedAt",
                        System.currentTimeMillis()
                    )
                    .toString(
                        2
                    ),
                Charsets.UTF_8
            )

        return JSONObject()
            .put(
                "ok",
                true
            )
            .put(
                "customer",
                customer.trim()
            )
            .put(
                "setupNumber",
                setupNumber.trim()
            )
            .put(
                "path",
                savedPath
            )
    }

    private fun bitmapToPdf(
        source: Bitmap
    ): ByteArray {

        val portrait =
            source.height >=
            source.width

        val pageWidth =
            if (portrait) {
                1240
            } else {
                1754
            }

        val pageHeight =
            if (portrait) {
                1754
            } else {
                1240
            }

        val margin =
            45f

        val maxWidth =
            pageWidth -
            margin *
            2f

        val maxHeight =
            pageHeight -
            margin *
            2f

        val scale =
            min(
                maxWidth /
                    source.width
                        .toFloat(),
                maxHeight /
                    source.height
                        .toFloat()
            )

        val drawWidth =
            source.width *
            scale

        val drawHeight =
            source.height *
            scale

        val left =
            (
                pageWidth -
                drawWidth
            ) /
            2f

        val top =
            (
                pageHeight -
                drawHeight
            ) /
            2f

        val document =
            PdfDocument()

        try {
            val pageInfo =
                PdfDocument
                    .PageInfo
                    .Builder(
                        pageWidth,
                        pageHeight,
                        1
                    )
                    .create()

            val page =
                document.startPage(
                    pageInfo
                )

            val canvas:
                Canvas =
                page.canvas

            canvas.drawColor(
                Color.WHITE
            )

            val destination =
                android.graphics.RectF(
                    left,
                    top,
                    left +
                        drawWidth,
                    top +
                        drawHeight
                )

            canvas.drawBitmap(
                source,
                null,
                destination,
                Paint(
                    Paint.ANTI_ALIAS_FLAG or
                        Paint.FILTER_BITMAP_FLAG
                )
            )

            document.finishPage(
                page
            )

            val output =
                ByteArrayOutputStream()

            document.writeTo(
                output
            )

            return output
                .toByteArray()

        } finally {
            document.close()
        }
    }

    fun extractSetupNumber(
        aiText: String
    ): String {

        val cleaned =
            aiText
                .trim()
                .removePrefix(
                    "```json"
                )
                .removePrefix(
                    "```"
                )
                .removeSuffix(
                    "```"
                )
                .trim()

        return runCatching {
            JSONObject(
                cleaned
            )
                .optString(
                    "setupNumber"
                )
                .trim()
        }
            .getOrDefault(
                ""
            )
    }

    private fun safePathPart(
        value: String
    ): String {

        return value
            .trim()
            .replace(
                Regex(
                    """[\\/:*?"<>|]"""
                ),
                "_"
            )
            .replace(
                Regex(
                    """\s+"""
                ),
                " "
            )
            .trim(
                '.',
                ' '
            )
            .take(
                100
            )
    }
}
