package de.fa.fertigung.ai

import android.content.Context
import org.json.JSONObject

object AiJobStore {

    private const val PREFS =
        "fa_background_ai"

    private const val LATEST_COMPLETED =
        "latest_completed"

    private fun prefs(context: Context) =
        context.getSharedPreferences(
            PREFS,
            Context.MODE_PRIVATE
        )

    fun setState(
        context: Context,
        requestId: String,
        type: String,
        payloadJson: String,
        documentType: String,
        jobKind: String
    ) {
        val state =
            JSONObject()
                .put(
                    "requestId",
                    requestId
                )
                .put(
                    "type",
                    type
                )
                .put(
                    "payloadJson",
                    payloadJson
                )
                .put(
                    "documentType",
                    documentType
                )
                .put(
                    "jobKind",
                    jobKind
                )
                .put(
                    "updatedAt",
                    System.currentTimeMillis()
                )
                .toString()

        prefs(context)
            .edit()
            .putString(
                stateKey(requestId),
                state
            )
            .apply()
    }

    fun complete(
        context: Context,
        requestId: String,
        payloadJson: String,
        documentType: String,
        jobKind: String
    ) {
        val completed =
            JSONObject()
                .put(
                    "requestId",
                    requestId
                )
                .put(
                    "type",
                    "result"
                )
                .put(
                    "payloadJson",
                    payloadJson
                )
                .put(
                    "documentType",
                    documentType
                )
                .put(
                    "jobKind",
                    jobKind
                )
                .put(
                    "completedAt",
                    System.currentTimeMillis()
                )
                .toString()

        prefs(context)
            .edit()
            .putString(
                stateKey(requestId),
                completed
            )
            .putString(
                LATEST_COMPLETED,
                completed
            )
            .apply()
    }

    fun poll(
        context: Context,
        requestId: String
    ): String {
        val id =
            requestId.trim()

        if (id.isEmpty()) {
            return ""
        }

        val p =
            prefs(context)

        val state =
            p.getString(
                stateKey(id),
                ""
            ).orEmpty()

        if (state.isEmpty()) {
            return ""
        }

        return try {
            val obj =
                JSONObject(state)

            if (
                obj.optString(
                    "type"
                ) == "result"
            ) {
                val editor =
                    p.edit()
                        .remove(
                            stateKey(id)
                        )

                val latest =
                    p.getString(
                        LATEST_COMPLETED,
                        ""
                    ).orEmpty()

                if (latest.isNotEmpty()) {
                    val latestId =
                        runCatching {
                            JSONObject(
                                latest
                            )
                                .optString(
                                    "requestId"
                                )
                        }
                            .getOrDefault(
                                ""
                            )

                    if (
                        latestId == id
                    ) {
                        editor.remove(
                            LATEST_COMPLETED
                        )
                    }
                }

                editor.apply()
            }

            state

        } catch (_: Throwable) {
            p.edit()
                .remove(
                    stateKey(id)
                )
                .apply()

            ""
        }
    }

    fun takeCompleted(
        context: Context
    ): String {
        val p =
            prefs(context)

        val result =
            p.getString(
                LATEST_COMPLETED,
                ""
            ).orEmpty()

        if (result.isEmpty()) {
            return ""
        }

        p.edit()
            .remove(
                LATEST_COMPLETED
            )
            .apply()

        return result
    }

    private fun stateKey(
        requestId: String
    ): String {
        return (
            "state_" +
            requestId
        )
    }
}
