package de.fa.fertigung.wear

import android.content.Context
import com.google.android.gms.tasks.Tasks
import com.google.android.gms.wearable.PutDataMapRequest
import com.google.android.gms.wearable.Wearable
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.TimeUnit

object WatchDataSync {

    const val CONTEXT_PATH =
        "/fa/watch/context"

    const val ACK_PATH =
        "/fa/watch/ack"

    const val EVENT_PREFIX =
        "/fa/watch/event/"

    const val EVENT_MESSAGE_PATH =
        "/fa/watch/action"


    fun sendEvent(
        context: Context,
        type: String,
        positionIndex: Int
    ): Boolean {

        val current =
            runCatching {
                JSONObject(
                    WatchStateStore
                        .contextJson(
                            context
                        )
                )
            }.getOrNull()
                ?: return false

        if (
            !current.optBoolean(
                "active",
                false
            )
        ) {
            return false
        }

        val faId =
            current.optString(
                "faId"
            )
                .trim()

        if (
            faId.isEmpty()
        ) {
            return false
        }

        val eventId =
            UUID.randomUUID()
                .toString()

        val timestamp =
            System.currentTimeMillis()

        val eventJson =
            JSONObject()
                .put(
                    "eventId",
                    eventId
                )
                .put(
                    "type",
                    type
                )
                .put(
                    "faId",
                    faId
                )
                .put(
                    "faNo",
                    current.optString(
                        "faNo"
                    )
                )
                .put(
                    "date",
                    current.optString(
                        "date"
                    )
                )
                .put(
                    "positionIndex",
                    positionIndex
                )
                .put(
                    "timestamp",
                    timestamp
                )

        /*
         * 1. Sofortkanal:
         * MessageClient ist für einzelne Aktionen gedacht und
         * wesentlich direkter als auf DataItem-Synchronisierung zu warten.
         */
        runCatching {
            val nodes =
                Tasks.await(
                    Wearable
                        .getNodeClient(
                            context
                        )
                        .connectedNodes,
                    2,
                    TimeUnit.SECONDS
                )

            nodes.forEach {
                node ->

                Wearable
                    .getMessageClient(
                        context
                    )
                    .sendMessage(
                        node.id,
                        EVENT_MESSAGE_PATH,
                        eventJson
                            .toString()
                            .toByteArray(
                                Charsets.UTF_8
                            )
                    )
            }
        }

        /*
         * 2. Persistenter Fallback:
         * DataItem bleibt bestehen, bis das Handy die Aktion bestätigt.
         * Damit geht ein Tipp auch bei kurzzeitig fehlender Verbindung
         * nicht verloren.
         */
        val request =
            PutDataMapRequest
                .create(
                    EVENT_PREFIX +
                    eventId
                )
                .apply {
                    dataMap.putString(
                        "eventId",
                        eventId
                    )

                    dataMap.putString(
                        "type",
                        type
                    )

                    dataMap.putString(
                        "faId",
                        faId
                    )

                    dataMap.putString(
                        "faNo",
                        current.optString(
                            "faNo"
                        )
                    )

                    dataMap.putString(
                        "date",
                        current.optString(
                            "date"
                        )
                    )

                    dataMap.putInt(
                        "positionIndex",
                        positionIndex
                    )

                    dataMap.putLong(
                        "timestamp",
                        timestamp
                    )
                }
                .asPutDataRequest()
                .setUrgent()

        WatchStateStore
            .addPending(
                context,
                eventId,
                type
            )

        Wearable
            .getDataClient(
                context
            )
            .putDataItem(
                request
            )

        return true
    }

}
